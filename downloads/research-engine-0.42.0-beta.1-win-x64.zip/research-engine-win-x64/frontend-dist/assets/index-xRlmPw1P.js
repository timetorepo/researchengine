import{eM as e,eN as a,eO as t}from"./index-Co3l2-ke.js";const n={renderer:t,...a,...e};var o=n;export{o as default};
