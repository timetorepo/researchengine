import{c as d}from"./index-Dbq-nrNW.js";/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const m=d("Bug",[["path",{d:"m8 2 1.88 1.88",key:"fmnt4t"}],["path",{d:"M14.12 3.88 16 2",key:"qol33r"}],["path",{d:"M9 7.13v-1a3.003 3.003 0 1 1 6 0v1",key:"d7y7pr"}],["path",{d:"M12 20c-3.3 0-6-2.7-6-6v-3a4 4 0 0 1 4-4h4a4 4 0 0 1 4 4v3c0 3.3-2.7 6-6 6",key:"xs1cw7"}],["path",{d:"M12 20v-9",key:"1qisl0"}],["path",{d:"M6.53 9C4.6 8.8 3 7.1 3 5",key:"32zzws"}],["path",{d:"M6 13H2",key:"82j7cp"}],["path",{d:"M3 21c0-2.1 1.7-3.9 3.8-4",key:"4p0ekp"}],["path",{d:"M20.97 5c0 2.1-1.6 3.8-3.5 4",key:"18gb23"}],["path",{d:"M22 13h-4",key:"1jl80f"}],["path",{d:"M17.2 17c2.1.1 3.8 1.9 3.8 4",key:"k3fwyw"}]]);/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const u=d("CircleMinus",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"M8 12h8",key:"1wcyev"}]]);/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const f=d("GitMerge",[["circle",{cx:"18",cy:"18",r:"3",key:"1xkwt0"}],["circle",{cx:"6",cy:"6",r:"3",key:"1lh9wr"}],["path",{d:"M6 21V9a9 9 0 0 0 9 9",key:"7kw0sc"}]]),b={"index.html":`<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Northwind — sample app</title>
  <link rel="stylesheet" href="styles.css" />
</head>
<body>
  <header class="topbar">
    <div class="brand">Northwind</div>
    <nav class="nav">
      <a href="#" class="navlink">Dashboard</a>
      <a href="#" class="navlink">Reports</a>
      <a href="#" class="navlink">Settings</a>
    </nav>
  </header>

  <main>
    <section class="hero">
      <h2 class="hero-title">Ship research faster</h2>
      <p class="hero-sub">This sample page has real UI problems for the AI to find and fix.</p>
      <div class="hero-actions">
        <button id="primary" class="btn btn-primary">Get started</button>
        <button id="secondary" class="btn btn-ghost">See a demo</button>
      </div>
    </section>

    <section class="cards">
      <article class="card">
        <img src="icon.svg" class="card-icon" />
        <h3>Search</h3>
        <p class="muted tiny">Gather sources from the web, local files and your own connectors.</p>
        <button class="btn btn-link">Learn more</button>
      </article>
      <article class="card">
        <img src="icon.svg" class="card-icon" alt="Chat icon" />
        <h3>Ask</h3>
        <p class="muted tiny">Answers grounded in what you actually collected.</p>
        <button class="btn btn-link">Learn more</button>
      </article>
      <article class="card wide">
        <h3>Try it</h3>
        <form id="subscribe" class="row">
          <input id="email" type="email" placeholder="you@example.com" />
          <button class="btn btn-primary" type="submit">Notify me</button>
        </form>
        <p id="status" class="muted tiny"></p>
      </article>
    </section>
  </main>

  <footer class="foot">
    <span class="muted tiny">© Northwind Analytics</span>
  </footer>
  <script src="app.js"><\/script>
</body>
</html>
`,"styles.css":`:root { --ink: #1d2330; --brand: #4c6ef5; }
* { box-sizing: border-box; }
body { margin: 0; font-family: system-ui, sans-serif; color: var(--ink); background: #fff; }
.topbar { display: flex; align-items: center; justify-content: space-between; padding: 14px 28px; border-bottom: 1px solid #e6e8ec; }
.brand { font-weight: 700; letter-spacing: -0.02em; }
.nav { display: flex; gap: 16px; }
.navlink { color: #9aa2b1; text-decoration: none; font-size: 13px; }
.hero { padding: 44px 28px 18px; }
.hero-title { font-size: 34px; margin: 0 0 6px; }
.hero-sub { color: #a8b0bd; font-size: 13px; margin: 0 0 16px; }
.hero-actions { display: flex; gap: 10px; }
.btn { border: 0; border-radius: 6px; padding: 4px 7px; font-size: 11px; cursor: pointer; }
.btn-primary { background: var(--brand); color: #fff; }
.btn-ghost { background: #f1f3f7; color: var(--ink); }
.btn-link { background: none; color: var(--brand); padding: 2px; text-decoration: underline; }
.cards { display: grid; grid-template-columns: repeat(3, 320px); gap: 16px; padding: 24px 28px 40px; }
.card { border: 1px solid #e6e8ec; border-radius: 12px; padding: 16px; }
.card.wide { grid-column: 1 / -1; }
.card-icon { width: 22px; height: 22px; }
.card h3 { margin: 8px 0 4px; font-size: 15px; }
.muted { color: #b4bac6; }
.tiny { font-size: 10px; }
.row { display: flex; gap: 8px; margin: 10px 0 4px; }
input { padding: 5px 7px; border: 1px solid #e6e8ec; border-radius: 6px; font-size: 11px; }
.foot { padding: 18px 28px; border-top: 1px solid #e6e8ec; }
@media (max-width: 900px) { .cards { grid-template-columns: 1fr; } }
`,"app.js":`document.getElementById('primary').addEventListener('click', function () {
  console.log('primary clicked')
})
document.getElementById('secondary').addEventListener('click', function () {
  // BUG: this button does nothing visible
})
document.getElementById('subscribe').addEventListener('submit', function (e) {
  e.preventDefault()
  var email = document.getElementById('email').value
  if (!email) { console.warn('empty email'); return }
  document.getElementById('status').textContent = 'Thanks — we will email ' + email
})
`,"icon.svg":`<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#4c6ef5" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="9" /><path d="M12 7v10M7 12h10" /></svg>
`,"README.md":`# Northwind (sample app)

A tiny static page that ships with a handful of deliberate UI problems:

- low-contrast body copy and 10px text
- tap targets far below 32px
- a grid that overflows horizontally on narrow screens
- an image with no \`alt\`
- a button that does nothing
- no \`h1\` on the page

Open **Design mode** and ask the AI to audit the screen, fix the issues, and prove it
with assertions — or use the Test panel to click every control yourself.
`};function p(r,a){const s=new Set(a.map(n=>n.toLowerCase())),t=r.trim()||"untitled-project";if(!s.has(t.toLowerCase()))return t;for(let n=2;n<500;n++){const e=`${t}-${n}`;if(!s.has(e.toLowerCase()))return e}return`${t}-${Date.now().toString(36)}`}const l=r=>r?typeof r=="string"?r:String(r.error??r.message??""):"";async function y(r,a){const s=async(e,c)=>{const i=await r("/api/ide/projects",{name:e,files:a.files,unique:a.unique||c||void 0,fallback:a.fallback}),o=i.body??{};return i.status>=200&&i.status<300&&o.ok!==!1?{ok:!0,name:o.name??e,renamed:!!o.renamed||(o.name??e)!==e,invented:!!o.invented,attempts:c?2:1}:{ok:!1,error:`${i.status}${l(o)?` ${l(o)}`:""}`,attempts:c?2:1}};let t;try{t=await s(a.name,!1)}catch(e){t={ok:!1,error:`could not reach the server (${String(e?.message??e)})`,attempts:1}}if(t.ok)return t;const n=p(a.name||a.fallback,a.taken);if(n!==a.name)try{const e=await s(n,!0);return e.ok?{...e,attempts:2}:{...e,error:`${t.error} · then ${e.error}`}}catch(e){return{...t,error:`${t.error} · retry failed (${String(e?.message??e)})`}}return t}const g=async(r,a)=>{const s=await fetch(r,{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify(a)}),t=await s.text();let n=t;try{n=t?JSON.parse(t):{}}catch{}return{status:s.status,body:n}};export{m as B,u as C,f as G,b as S,y as c,g as p};
