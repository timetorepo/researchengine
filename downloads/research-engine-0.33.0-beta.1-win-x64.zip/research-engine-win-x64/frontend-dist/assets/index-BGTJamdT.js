import{dG as a,dH as e,dI as t}from"./index-Cp05s5Ff.js";const n={renderer:t,...e,...a};var o=n;export{o as default};
