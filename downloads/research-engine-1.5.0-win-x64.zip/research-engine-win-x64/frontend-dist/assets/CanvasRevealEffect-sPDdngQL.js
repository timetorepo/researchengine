import{r as c,u as j,i0 as z,j as o,a as w,aj as C}from"./index-959tl7qB.js";import{C as S,a as $,u as k}from"./react-three-fiber.esm-dKhaS6xP.js";import{i as E,l as F,m as I,n as M,G as R,a as x,V as g}from"./three.module-DxRDZTKK.js";const G=({animationSpeed:e=.4,opacities:r=[.3,.3,.3,.5,.5,.5,.8,.8,.8,1],colors:i=[[0,255,255]],containerClassName:s,dotSize:u,showGradient:f=!0,paused:d})=>{const p=c.useRef(null),[l,t]=c.useState(!1),[a,n]=c.useState(()=>typeof document>"u"||document.visibilityState==="visible"),m=j();c.useEffect(()=>{const v=p.current;if(!v||typeof IntersectionObserver>"u"){t(!0);return}const y=new IntersectionObserver(([h])=>t(h.isIntersecting),{rootMargin:"120px"});return y.observe(v),()=>y.disconnect()},[]),c.useEffect(()=>{const v=()=>n(document.visibilityState==="visible");return document.addEventListener("visibilitychange",v),()=>document.removeEventListener("visibilitychange",v)},[]);const _=z()==="minimal",b=!m&&a&&!_&&!(d??!l);return o.jsxs("div",{ref:p,className:w("relative h-full w-full bg-transparent",s),children:[m||_||!a?o.jsx("div",{className:"h-full w-full",style:{backgroundImage:`radial-gradient(${`rgba(${i[0][0]},${i[0][1]},${i[0][2]},0.35)`} ${u??3}px, transparent ${u??3}px)`,backgroundSize:"14px 14px"}}):o.jsx("div",{className:"h-full w-full",children:o.jsx(L,{colors:i??[[0,255,255]],dotSize:u??3,opacities:r??[.3,.3,.3,.5,.5,.5,.8,.8,.8,1],shader:`
              float animation_speed_factor = ${e.toFixed(1)};
              float intro_offset = distance(u_resolution / 2.0 / u_total_size, st2) * 0.01 + (random(st2) * 0.15);
              opacity *= step(intro_offset, u_time * animation_speed_factor);
              opacity *= clamp((1.0 - step(intro_offset + 0.1, u_time * animation_speed_factor)) * 1.25, 1.0, 1.25);
            `,center:["x","y"],paused:!b})}),f&&!m&&o.jsx("div",{className:"absolute inset-0 bg-gradient-to-t from-gray-950 to-[84%]"})]})},L=({colors:e=[[0,0,0]],opacities:r=[.04,.04,.04,.04,.04,.08,.08,.08,.08,.14],totalSize:i=4,dotSize:s=2,shader:u="",center:f=["x","y"],paused:d=!1})=>{const p=C.useMemo(()=>{let l=[e[0],e[0],e[0],e[0],e[0],e[0]];return e.length===2?l=[e[0],e[0],e[0],e[1],e[1],e[1]]:e.length===3&&(l=[e[0],e[0],e[1],e[1],e[2],e[2]]),{u_colors:{value:l.map(t=>[t[0]/255,t[1]/255,t[2]/255]),type:"uniform3fv"},u_opacities:{value:r,type:"uniform1fv"},u_total_size:{value:i,type:"uniform1f"},u_dot_size:{value:s,type:"uniform1f"}}},[e,r,i,s]);return o.jsx(O,{source:`
        precision mediump float;
        in vec2 fragCoord;

        uniform float u_time;
        uniform float u_opacities[10];
        uniform vec3 u_colors[6];
        uniform float u_total_size;
        uniform float u_dot_size;
        uniform vec2 u_resolution;
        out vec4 fragColor;
        float PHI = 1.61803398874989484820459;
        float random(vec2 xy) {
            return fract(tan(distance(xy * PHI, xy) * 0.5) * xy.x);
        }
        float map(float value, float min1, float max1, float min2, float max2) {
            return min2 + (value - min1) * (max2 - min2) / (max1 - min1);
        }
        void main() {
            vec2 st = fragCoord.xy;
            ${f.includes("x")?"st.x -= abs(floor((mod(u_resolution.x, u_total_size) - u_dot_size) * 0.5));":""}
            ${f.includes("y")?"st.y -= abs(floor((mod(u_resolution.y, u_total_size) - u_dot_size) * 0.5));":""}
      float opacity = step(0.0, st.x);
      opacity *= step(0.0, st.y);

      vec2 st2 = vec2(int(st.x / u_total_size), int(st.y / u_total_size));

      float frequency = 5.0;
      float show_offset = random(st2);
      float rand = random(st2 * floor((u_time / frequency) + show_offset + frequency) + 1.0);
      opacity *= u_opacities[int(rand * 10.0)];
      opacity *= 1.0 - step(u_dot_size / u_total_size, fract(st.x / u_total_size));
      opacity *= 1.0 - step(u_dot_size / u_total_size, fract(st.y / u_total_size));

      vec3 color = u_colors[int(show_offset * 6.0)];

      ${u}

      fragColor = vec4(color, opacity);
      fragColor.rgb *= fragColor.a;
        }`,uniforms:p,maxFps:d?0:60})},N=({source:e,uniforms:r,maxFps:i=60,paused:s=!1})=>{const{size:u}=$(),f=c.useRef(null);let d=0;k(({clock:t})=>{if(!f.current||s)return;const a=t.getElapsedTime();if(a-d<1/i)return;d=a;const m=f.current.material.uniforms.u_time;m.value=a});const p=()=>{const t={};for(const a in r){const n=r[a];switch(n.type){case"uniform1f":t[a]={value:n.value,type:"1f"};break;case"uniform3f":t[a]={value:new g().fromArray(n.value),type:"3f"};break;case"uniform1fv":t[a]={value:n.value,type:"1fv"};break;case"uniform3fv":t[a]={value:n.value.map(m=>new g().fromArray(m)),type:"3fv"};break;case"uniform2f":t[a]={value:new x().fromArray(n.value),type:"2f"};break;default:console.error(`Invalid uniform type for '${a}'.`);break}}return t.u_time={value:0,type:"1f"},t.u_resolution={value:new x(u.width*2,u.height*2)},t},l=c.useMemo(()=>new E({vertexShader:`
      precision mediump float;
      in vec2 coordinates;
      uniform vec2 u_resolution;
      out vec2 fragCoord;
      void main(){
        float x = position.x;
        float y = position.y;
        gl_Position = vec4(x, y, 0.0, 1.0);
        fragCoord = (position.xy + vec2(1.0)) * 0.5 * u_resolution;
        fragCoord.y = u_resolution.y - fragCoord.y;
      }
      `,fragmentShader:e,uniforms:p(),glslVersion:R,blending:M,blendSrc:I,blendDst:F}),[e]);return o.jsxs("mesh",{ref:f,children:[o.jsx("planeGeometry",{args:[2,2]}),o.jsx("primitive",{object:l,attach:"material"})]})},O=({source:e,uniforms:r,maxFps:i=60,paused:s=!1})=>o.jsx(S,{className:"absolute inset-0 h-full w-full",children:o.jsx(N,{source:e,uniforms:r,maxFps:i,paused:s})});export{G as CanvasRevealEffect};
