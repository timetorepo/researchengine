import{g$ as $,r as u,hu as l}from"./index-959tl7qB.js";function o(f,r,a,e){let c=$(a),t=a==null;u.useEffect(()=>{if(!(t||f.current==null))return l(f.current,r,c,e)},[f,r,e,t])}export{o as $};
