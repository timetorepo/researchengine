import{r as d,j as A}from"./index-959tl7qB.js";const S=`
  attribute vec2 a_position;
  varying vec2 v_uv;

  void main() {
    v_uv = a_position * 0.5 + 0.5;
    gl_Position = vec4(a_position, 0.0, 1.0);
  }
`,w=`
  #ifdef GL_FRAGMENT_PRECISION_HIGH
  precision highp float;
  #else
  precision mediump float;
  #endif

  varying vec2 v_uv;
  uniform float u_time;
  uniform vec2 u_resolution;

  #define TWO_PI 6.28318530718
  #define PI 3.14159265358979323846

  float random(vec2 st) {
    return fract(sin(dot(st.xy, vec2(12.9898, 78.233))) * 43758.5453123);
  }

  float noise(vec2 st) {
    vec2 i = floor(st);
    vec2 f = fract(st);
    float a = random(i);
    float b = random(i + vec2(1.0, 0.0));
    float c = random(i + vec2(0.0, 1.0));
    float d = random(i + vec2(1.0, 1.0));

    vec2 u = f * f * (3.0 - 2.0 * f);

    float x1 = mix(a, b, u.x);
    float x2 = mix(c, d, u.x);
    return mix(x1, x2, u.y);
  }

  void main() {
      vec2 uv = v_uv;

      // Mist preset timing parameters: speed = 39, offset = -235
      float t = u_time * 0.975 - 1.175;

      // Mist preset scale parameter: scale = 0.48
      float noise_scale = 0.00338; // .0005 + .006 * 0.48

      uv -= 0.5;
      uv *= (noise_scale * u_resolution);
      uv /= 1.5; // pixel ratio normalization
      uv += 0.5;

      // Distortion: distortion = 4 (u_distortion = 0.08)
      float n1 = noise(uv * 1.0 + t);
      float n2 = noise(uv * 2.0 - t);
      float angle = n1 * TWO_PI;
      uv.x += 0.32 * n2 * cos(angle);
      uv.y += 0.32 * n2 * sin(angle);

      // Swirl: swirl = 65, swirlIterations = 5
      for (int i = 1; i <= 5; i++) {
          float fi = float(i);
          uv.x += 0.65 / fi * cos(t + fi * 1.5 * uv.y);
          uv.y += 0.65 / fi * cos(t + fi * 1.0 * uv.x);
      }

      // Edge shape shape-mixer calculation (shapeSize = 48, proportion = 33)
      float sh = 1.0 - uv.y;
      sh -= 0.5;
      sh /= (noise_scale * u_resolution.y);
      sh += 0.5;

      float shape_scaling = 0.104; // 0.2 * (1.0 - 0.48)
      float shape = smoothstep(0.45 - shape_scaling, 0.55 + shape_scaling, sh + 0.3 * (0.33 - 0.5));
      float mixer = shape;

      vec3 bg = vec3(0.0196, 0.0196, 0.0196);          // Obsidian background (#050505)
      vec3 pink = vec3(1.0, 0.4, 0.7215);              // Pure elegant magenta core (#FF66B8)

      // Exponent-sine bell curve to isolate mist into a centre ribbon
      float mistFocus = pow(sin(mixer * PI), 4.2);

      // Double-layer parallax mist density
      float fineMist = noise(uv * 3.5 - t * 1.3) * 0.4 + noise(uv * 1.5 + t * 0.85) * 0.6;
      float combinedDensity = mix(mixer, fineMist, 0.28) * mistFocus;

      // Smooth constant-color gradient mapping
      vec3 col = mix(bg, pink, smoothstep(0.0, 0.85, combinedDensity));

      // Foreground parallax highlight glow, bounded by the mist focus ribbon
      float highlight = smoothstep(0.42, 0.88, fineMist) * smoothstep(0.12, 0.9, mixer) * mistFocus;
      col = mix(col, pink * 1.15, highlight * 0.35);

      // Crepuscular light shafts through the moving fog ribbon
      vec2 raySource = vec2(0.2, 1.25);
      vec2 rayDir = normalize(v_uv - raySource);
      float rayAngle = atan(rayDir.y, rayDir.x);

      float rays = sin(rayAngle * 6.5 + t * 0.35) * 0.35 +
                   sin(rayAngle * 12.0 - t * 0.22) * 0.25 +
                   sin(rayAngle * 24.0 + t * 0.15) * 0.15;
      rays = smoothstep(0.15, 0.82, rays * 0.5 + 0.5);

      float rayGlow = rays * smoothstep(0.15, 0.9, combinedDensity) * (1.1 - v_uv.y) * mistFocus * 0.7;
      col += pink * rayGlow * 0.38;

      // Fine glowing dust in the lit centre
      float grain = random(gl_FragCoord.xy * 0.15 + t * 0.05);
      float particles = step(0.988, grain) * smoothstep(0.2, 0.9, combinedDensity);
      col += pink * particles * 0.32;

      // Final contrast optimization
      col = pow(col, vec3(0.92));

      gl_FragColor = vec4(col, 1.0);
  }
`;function R({speed:l=.6,opacity:g=.8,className:p}){const c=d.useRef(null);return d.useEffect(()=>{const t=c.current;if(!t)return;const e=t.getContext("webgl",{antialias:!1,alpha:!1,preserveDrawingBuffer:!1});if(!e)return;const r=()=>{const a=Math.min(window.devicePixelRatio||1,2);t.width=Math.max(1,Math.round(t.clientWidth*a)),t.height=Math.max(1,Math.round(t.clientHeight*a)),e.viewport(0,0,t.width,t.height)},f=(a,b)=>{const i=e.createShader(a);return i?(e.shaderSource(i,b),e.compileShader(i),e.getShaderParameter(i,e.COMPILE_STATUS)?i:(console.error(e.getShaderInfoLog(i)),e.deleteShader(i),null)):null},n=f(e.VERTEX_SHADER,S),s=f(e.FRAGMENT_SHADER,w);if(!n||!s)return;const o=e.createProgram();if(!o||(e.attachShader(o,n),e.attachShader(o,s),e.linkProgram(o),!e.getProgramParameter(o,e.LINK_STATUS)))return;e.useProgram(o);const u=e.createBuffer();e.bindBuffer(e.ARRAY_BUFFER,u),e.bufferData(e.ARRAY_BUFFER,new Float32Array([-1,-1,1,-1,-1,1,1,1]),e.STATIC_DRAW);const m=e.getAttribLocation(o,"a_position");e.enableVertexAttribArray(m),e.vertexAttribPointer(m,2,e.FLOAT,!1,0,0);const _=e.getUniformLocation(o,"u_time"),x=e.getUniformLocation(o,"u_resolution");r(),window.addEventListener("resize",r);const y=Date.now();let h=0;const v=()=>{e.uniform1f(_,(Date.now()-y)/1e3*l),e.uniform2f(x,t.width,t.height),e.drawArrays(e.TRIANGLE_STRIP,0,4),h=requestAnimationFrame(v)};return v(),()=>{window.removeEventListener("resize",r),cancelAnimationFrame(h),e.deleteShader(n),e.deleteShader(s),e.deleteProgram(o),e.deleteBuffer(u)}},[l]),A.jsx("canvas",{ref:c,"aria-hidden":"true",className:`absolute inset-0 w-full h-full ${p??""}`,style:{opacity:g,pointerEvents:"none"}})}export{R as AnimatedGradient,R as default};
