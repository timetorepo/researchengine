import{hT as a,hU as e,hV as t}from"./index-959tl7qB.js";const n={renderer:t,...e,...a};var o=n;export{o as default};
