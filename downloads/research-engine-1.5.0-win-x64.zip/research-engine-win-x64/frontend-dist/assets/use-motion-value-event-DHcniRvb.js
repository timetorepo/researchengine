import{r as n}from"./index-959tl7qB.js";function e(o,t,r){n.useInsertionEffect(()=>o.on(t,r),[o,t,r])}export{e as u};
