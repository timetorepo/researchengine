import{r as E,j as P}from"./index-959tl7qB.js";const q=`
  attribute vec2 a_position;
  varying vec2 v_uv;
  void main() {
    v_uv = a_position * 0.5 + 0.5;
    gl_Position = vec4(a_position, 0.0, 1.0);
  }
`,M=`
  #ifdef GL_FRAGMENT_PRECISION_HIGH
  precision highp float;
  #else
  precision mediump float;
  #endif
  varying vec2 v_uv;
  uniform float u_time;
  uniform vec2 u_resolution;
  uniform vec2 u_mouse;
  uniform float u_flare;

  float hash(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
  float noise(vec2 p) {
    vec2 i = floor(p); vec2 f = fract(p);
    vec2 u = f * f * (3.0 - 2.0 * f);
    return mix(mix(hash(i), hash(i + vec2(1.0, 0.0)), u.x),
               mix(hash(i + vec2(0.0, 1.0)), hash(i + vec2(1.0, 1.0)), u.x), u.y);
  }
  float fbm(vec2 p) {
    float v = 0.0; float a = 0.5;
    for (int i = 0; i < 4; i++) { v += a * noise(p); p = p * 2.03 + vec2(17.1, 9.2); a *= 0.5; }
    return v;
  }

  void main() {
    float aspect = u_resolution.x / u_resolution.y;
    vec2 uv = v_uv - 0.5;
    uv.x *= aspect;
    // the hole drifts a little toward the pointer
    vec2 drift = (u_mouse - 0.5) * vec2(aspect, 1.0) * 0.12;
    vec2 p = uv - drift;
    float t = u_time * 0.12;

    float r = length(p);
    float a = atan(p.y, p.x);

    // the disc is tilted: squash the y axis so the ring reads as a plane
    vec2 q = vec2(p.x, p.y * 2.6);
    float rq = length(q);
    float ring = smoothstep(0.52, 0.2, abs(rq - 0.42));
    float inner = smoothstep(0.27, 0.23, rq);       // event horizon: black
    float photon = exp(-pow((rq - 0.27) * 16.0, 2.0)) * 0.9;  // bright photon ring

    // engraved line work: contour lines of a swirling field, following the disc
    float swirl = a * 2.0 + 6.0 * rq - t * 3.0;
    float field = fbm(vec2(cos(swirl), sin(swirl)) * 1.4 + vec2(rq * 3.0, t));
    float lines = smoothstep(0.96, 0.99, abs(sin(field * 46.0)));

    // light jets along the pole
    float jet = exp(-pow(p.x * 9.0, 2.0)) * smoothstep(0.1, 0.9, abs(p.y)) * (0.5 + 0.5 * sin(p.y * 12.0 - t * 8.0));

    // contour nebula, faint, drifting
    float neb = fbm(p * 2.2 + vec2(t, -t * 0.7));
    float nebLines = smoothstep(0.97, 0.995, abs(sin(neb * 30.0)));

    vec3 crimson = vec3(0.86, 0.12, 0.16);
    vec3 silver = vec3(0.82, 0.84, 0.88);

    vec3 col = vec3(0.0);
    col += crimson * ring * (0.25 + 0.75 * lines);
    col += silver * ring * lines * 0.55;
    col += crimson * photon * (1.0 + u_flare * 0.8);
    col += silver * jet * 0.18 * (1.0 + u_flare);
    col += silver * nebLines * 0.12 * smoothstep(0.9, 0.2, rq);
    col += crimson * 0.05 * neb * smoothstep(1.0, 0.1, rq);
    col *= (1.0 - inner);

    // vignette and grain
    col *= smoothstep(1.1, 0.35, length(v_uv - 0.5) * 1.3);
    col += (hash(gl_FragCoord.xy + t) - 0.5) * 0.025;

    gl_FragColor = vec4(max(col, vec3(0.0)), 1.0);
  }
`;function U({speed:u=1,opacity:b=1,className:A}){const v=E.useRef(null);return E.useEffect(()=>{const t=v.current;if(!t)return;const e=t.getContext("webgl",{antialias:!1,alpha:!1});if(!e)return;const h=(i,a)=>{const s=e.createShader(i);return s?(e.shaderSource(s,a),e.compileShader(s),e.getShaderParameter(s,e.COMPILE_STATUS)?s:(e.deleteShader(s),null)):null},l=h(e.VERTEX_SHADER,q),c=h(e.FRAGMENT_SHADER,M);if(!l||!c)return;const o=e.createProgram();if(!o||(e.attachShader(o,l),e.attachShader(o,c),e.linkProgram(o),!e.getProgramParameter(o,e.LINK_STATUS)))return;e.useProgram(o);const m=e.createBuffer();e.bindBuffer(e.ARRAY_BUFFER,m),e.bufferData(e.ARRAY_BUFFER,new Float32Array([-1,-1,1,-1,-1,1,1,1]),e.STATIC_DRAW);const d=e.getAttribLocation(o,"a_position");e.enableVertexAttribArray(d),e.vertexAttribPointer(d,2,e.FLOAT,!1,0,0);const L=e.getUniformLocation(o,"u_time"),R=e.getUniformLocation(o,"u_resolution"),y=e.getUniformLocation(o,"u_mouse"),S=e.getUniformLocation(o,"u_flare"),f=()=>{const i=Math.min(window.devicePixelRatio||1,1.5);t.width=Math.max(1,Math.round(t.clientWidth*i)),t.height=Math.max(1,Math.round(t.clientHeight*i)),e.viewport(0,0,t.width,t.height)};f(),window.addEventListener("resize",f);const n={x:.5,y:.5,flare:0},r={x:.5,y:.5,flare:0},T=t.parentElement??t,p=i=>{const a=T.getBoundingClientRect();n.x=(i.clientX-a.left)/Math.max(1,a.width),n.y=1-(i.clientY-a.top)/Math.max(1,a.height)},g=()=>{n.flare=1},w=()=>{n.flare=0};window.addEventListener("pointermove",p),window.addEventListener("pointerdown",g),window.addEventListener("pointerup",w);const F=Date.now();let _=0;const x=()=>{r.x+=(n.x-r.x)*.04,r.y+=(n.y-r.y)*.04,r.flare+=(n.flare-r.flare)*.06,e.uniform1f(L,(Date.now()-F)/1e3*u),e.uniform2f(R,t.width,t.height),e.uniform2f(y,r.x,r.y),e.uniform1f(S,r.flare),e.drawArrays(e.TRIANGLE_STRIP,0,4),_=requestAnimationFrame(x)};return x(),()=>{window.removeEventListener("resize",f),window.removeEventListener("pointermove",p),window.removeEventListener("pointerdown",g),window.removeEventListener("pointerup",w),cancelAnimationFrame(_),e.deleteShader(l),e.deleteShader(c),e.deleteProgram(o),e.deleteBuffer(m)}},[u]),P.jsx("canvas",{ref:v,"aria-hidden":"true",className:`absolute inset-0 w-full h-full ${A??""}`,style:{opacity:b,pointerEvents:"none"}})}export{U as EtchedAccretion,U as default};
