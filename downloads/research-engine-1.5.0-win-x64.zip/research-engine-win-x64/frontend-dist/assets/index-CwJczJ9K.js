import{eV as o,eW as t}from"./index-959tl7qB.js";const a=Object.assign(o,{Root:o,Separator:t});export{a as B};
