import{e1 as e,e2 as a,e3 as t}from"./index-B-DkcAV1.js";const n={renderer:t,...a,...e};var o=n;export{o as default};
