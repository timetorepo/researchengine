import{r as u,bq as p,bp as h,j as t}from"./index-Dg20easP.js";import{C as v,V as d,u as m}from"./react-three-fiber.esm-BWjSsEx7.js";const x=`
varying vec2 vUv;
void main() {
  vUv = uv;
  gl_Position = vec4(position.xy, 0.0, 1.0);
}
`,g=`
precision highp float;
varying vec2 vUv;
uniform vec3 uColor;
uniform float uAlpha;
uniform float uSoftness;

void main() {
  // fade at both horizontal ends and soften vertically
  float fx = smoothstep(0.0, uSoftness, vUv.x) * smoothstep(1.0, 1.0 - uSoftness, vUv.x);
  float fy = smoothstep(0.0, 0.5, vUv.y) * smoothstep(1.0, 0.5, vUv.y);
  gl_FragColor = vec4(uColor, uAlpha * fx * fy);
}
`;function y({spec:o}){const e=u.useRef(null),a=u.useMemo(()=>({uColor:{value:new d(...o.color)},uAlpha:{value:o.alpha},uSoftness:{value:o.softness}}),[o]);return m(r=>{if(!e.current)return;const i=r.clock.elapsedTime,s=3.2;let n=((o.x0+i*o.speed)%s+s)%s;e.current.position.x=n-s/2}),t.jsxs("mesh",{ref:e,position:[0,o.y,0],children:[t.jsx("planeGeometry",{args:[2.6,o.h]}),t.jsx("shaderMaterial",{vertexShader:x,fragmentShader:g,uniforms:a,transparent:!0,depthTest:!1,depthWrite:!1})]})}function b({specs:o}){return t.jsx(t.Fragment,{children:o.map((e,a)=>t.jsx(y,{spec:e},a))})}function S({theme:o,intensity:e=.55}){const a=u.useMemo(()=>{const i=[];for(let s=0;s<15;s++){const n=Math.abs(Math.sin(s*12.9898)*43758.5453)%1,l=Math.abs(Math.sin(s*78.233)*12543.21)%1,c=n,f=p(o.primary,o.secondary,l);i.push({y:-1+2*(s+.5)/15+(l-.5)*.06,h:.006+c*.02,speed:(.04+n*.12)*(l>.5?1:-1),x0:n*3.2,color:o.isLight?p(f,h(o.bg,.4),.25):f,alpha:(.08+c*.3)*e,softness:.25+n*.2})}return i},[o,e]);return t.jsx("div",{className:"absolute inset-0",style:{background:`rgb(${o.bg.map(r=>Math.round(r*255)).join(",")})`},"aria-hidden":"true",children:t.jsx(v,{gl:{antialias:!1,alpha:!0,powerPreference:"low-power"},camera:{position:[0,0,1]},dpr:[1,1.5],style:{position:"absolute",inset:0},children:t.jsx(b,{specs:a})})})}export{S as default};
