var __defProp = Object.defineProperty;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// src/build-info.ts
import { existsSync, readFileSync, statSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
function moduleDir() {
  return dirname(fileURLToPath(import.meta.url));
}
function repoRoot() {
  return join(moduleDir(), "..", "..");
}
function resolveDistDir() {
  const candidates = [
    join(moduleDir(), "..", "frontend-dist"),
    // portable: <dir>/server → <dir>/frontend-dist
    join(repoRoot(), "frontend", "dist")
    // checkout: <repo>/frontend/dist
  ];
  return candidates.find((d) => existsSync(join(d, "index.html"))) ?? null;
}
function webBuild(distDir) {
  const dir = distDir ?? resolveDistDir() ?? join(repoRoot(), "frontend", "dist");
  const file = join(dir, "build-info.json");
  try {
    if (!existsSync(file)) return null;
    const mtime = statSync(file).mtimeMs;
    if (cache && cache.at === mtime) return cache.value;
    const parsed = JSON.parse(readFileSync(file, "utf8"));
    const value = {
      version: String(parsed.version ?? ""),
      buildId: String(parsed.buildId ?? ""),
      builtAt: String(parsed.builtAt ?? "")
    };
    cache = { at: mtime, value };
    return value;
  } catch {
    cache = { at: -1, value: null };
    return null;
  }
}
function installMode() {
  try {
    const pkg = JSON.parse(readFileSync(join(moduleDir(), "package.json"), "utf8"));
    return pkg.name === "research-engine-server" ? "portable" : "checkout";
  } catch {
    return "checkout";
  }
}
function sourceVersion() {
  const candidates = [
    join(moduleDir(), "package.json"),
    // portable build: <dir>/server/package.json
    join(repoRoot(), "package.json")
    // source checkout: <repo>/package.json
  ];
  for (const file of candidates) {
    try {
      const pkg = JSON.parse(readFileSync(file, "utf8"));
      if (pkg.version && (pkg.name === "research-engine" || pkg.name === "research-engine-server")) return pkg.version;
    } catch {
    }
  }
  return "";
}
function buildInfoReport(frontendDist) {
  const served = webBuild(frontendDist);
  const source = sourceVersion();
  const mode = installMode();
  const lines = [
    `Research Engine ${source || "(unknown version)"}  [${mode}]`,
    served ? `  built frontend : ${served.version} (${served.builtAt})` : "  built frontend : not found \u2014 run `npm run build` in frontend/ (or unpack a release archive)"
  ];
  if (served && source && served.version !== source) {
    lines.push(
      `  STATUS         : STALE \u2014 the served build is ${served.version} but this code is ${source}`,
      mode === "checkout" ? "                   fix: npm run build   (then restart the server)" : "                   fix: unpack the current release archive over this folder",
      '                   or press "Clear cache & reload" on Settings \u2192 About if the page itself is cached'
    );
  } else if (served) {
    lines.push("  STATUS         : up to date");
  }
  return lines.join("\n");
}
var cache;
var init_build_info = __esm({
  "src/build-info.ts"() {
    "use strict";
    cache = null;
  }
});

// src/runtime.ts
import { existsSync as existsSync2, mkdirSync, readFileSync as readFileSync2, writeFileSync, statSync as statSync2, readdirSync } from "node:fs";
import { join as join2, resolve } from "node:path";
import { homedir } from "node:os";
import { createServer } from "node:net";
function parseFlags(argv) {
  const f = { serve: argv[0] !== "serve" ? true : true };
  const args2 = argv.filter((a) => a !== "serve");
  if (args2.includes("version") || args2.includes("--version") || args2.includes("-v")) {
    console.log(buildInfoReport(f.frontendDist));
    process.exit(0);
  }
  for (let i = 0; i < args2.length; i++) {
    const a = args2[i];
    const val = () => args2[++i];
    if (a === "--port") f.port = Number(val());
    else if (a === "--host") f.host = val();
    else if (a === "--data-dir") f.dataDir = val();
    else if (a === "--profile") {
      const p = val();
      if (p in PROFILES) f.profile = p;
    } else if (a === "--frontend-dist") f.frontendDist = val();
    else if (a === "--help" || a === "-h") {
      console.log(`Research Engine \u2014 single-process server

Usage: research-engine serve [options]
       research-engine version            Show the build fingerprint and exit
  --port <n>          HTTP port (default 3847; auto-picks next free if busy)
  --host <addr>       Bind address (default 127.0.0.1)
  --data-dir <path>   Data directory (default ~/.research-engine)
  --profile <p>       eco | balanced | performance (default balanced)
  --frontend-dist <p> Path to built frontend (default ../frontend/dist)

Environment: RE_PORT, RE_HOST, RESEARCH_ENGINE_DATA_DIR, RE_PROFILE, FRONTEND_DIST`);
      process.exit(0);
    }
  }
  return f;
}
function configPath(dataDir) {
  return join2(dataDir, "config.json");
}
function loadConfig(dataDir) {
  try {
    return JSON.parse(readFileSync2(configPath(dataDir), "utf8"));
  } catch {
    return {};
  }
}
function saveConfig(dataDir, patch) {
  const merged = { ...loadConfig(dataDir), ...patch };
  writeFileSync(configPath(dataDir), JSON.stringify(merged, null, 2));
  return merged;
}
function ensureDataDir(dataDir) {
  for (const sub of ["", "media", "notebooks", "cache"]) {
    mkdirSync(join2(dataDir, sub), { recursive: true });
  }
  if (!existsSync2(configPath(dataDir))) writeFileSync(configPath(dataDir), "{}\n");
}
function dirSize(dir) {
  try {
    let total = 0;
    for (const entry of readdirSync(dir, { withFileTypes: true })) {
      const p = join2(dir, entry.name);
      if (entry.isDirectory()) total += dirSize(p);
      else if (entry.isFile()) total += statSync2(p).size;
    }
    return total;
  } catch {
    return 0;
  }
}
function portFree(port, host) {
  return new Promise((res) => {
    const srv = createServer();
    srv.once("error", () => res(false));
    srv.listen({ port, host, exclusive: true }, () => {
      srv.close(() => res(true));
    });
  });
}
async function pickPort(preferred, host) {
  for (let i = 0; i < 20; i++) {
    if (await portFree(preferred + i, host)) return preferred + i;
  }
  return preferred;
}
async function resolveRuntime(argv) {
  const flags = parseFlags(argv);
  const dataDir = resolve(flags.dataDir ?? process.env.RESEARCH_ENGINE_DATA_DIR ?? join2(homedir(), ".research-engine"));
  ensureDataDir(dataDir);
  const saved = loadConfig(dataDir);
  const host = flags.host ?? process.env.RE_HOST ?? "127.0.0.1";
  const envPort = Number(process.env.RE_PORT ?? process.env.PORT ?? "");
  const isDev = import.meta.url.includes("/src/");
  const preferredPort = flags.port ?? (envPort || (isDev ? 8787 : saved.port || 3847));
  const port = await pickPort(preferredPort, host);
  const rememberedPort = port !== preferredPort;
  const profileRaw = flags.profile ?? process.env.RE_PROFILE ?? saved.profile ?? "balanced";
  const profile = profileRaw in PROFILES ? profileRaw : "balanced";
  const candidates = [
    flags.frontendDist,
    process.env.FRONTEND_DIST,
    resolve(import.meta.dirname, "../../frontend/dist"),
    resolve(process.cwd(), "frontend/dist")
  ].filter(Boolean);
  const frontendDist = candidates.find((d) => existsSync2(join2(d, "index.html"))) ?? null;
  const dbPath2 = process.env.DB_PATH ?? join2(dataDir, "db.sqlite");
  process.env.DB_PATH = dbPath2;
  if (rememberedPort && !isDev) saveConfig(dataDir, { port });
  return { port, host, dataDir, profile, caps: PROFILES[profile], frontendDist, dbPath: dbPath2, rememberedPort };
}
var PROFILES;
var init_runtime = __esm({
  "src/runtime.ts"() {
    "use strict";
    init_build_info();
    PROFILES = {
      eco: {
        floodWorkers: 1,
        searchResults: 5,
        concurrentStreams: 1,
        backgroundIndexing: false,
        description: "1 concurrent stream, smaller retrieval, no background work. Best on \u22648 GB RAM."
      },
      balanced: {
        floodWorkers: 2,
        searchResults: 7,
        concurrentStreams: 2,
        backgroundIndexing: true,
        description: "Normal multi-tab use. Background indexing allowed."
      },
      performance: {
        floodWorkers: 4,
        searchResults: 9,
        concurrentStreams: 4,
        backgroundIndexing: true,
        description: "Parallel agents, faster preloading, larger caches."
      }
    };
  }
});

// src/db/schema.ts
var schema_exports = {};
__export(schema_exports, {
  chats: () => chats,
  citations: () => citations,
  documents: () => documents,
  messages: () => messages,
  skills: () => skills
});
import { sqliteTable, text, integer } from "drizzle-orm/sqlite-core";
var chats, messages, documents, skills, citations;
var init_schema = __esm({
  "src/db/schema.ts"() {
    "use strict";
    chats = sqliteTable("chats", {
      id: text("id").primaryKey(),
      title: text("title").notNull(),
      spaceId: text("space_id"),
      createdAt: integer("created_at").notNull(),
      updatedAt: integer("updated_at").notNull()
    });
    messages = sqliteTable("messages", {
      id: text("id").primaryKey(),
      chatId: text("chat_id").notNull(),
      role: text("role").notNull(),
      content: text("content").notNull(),
      model: text("model"),
      createdAt: integer("created_at").notNull()
    });
    documents = sqliteTable("documents", {
      id: text("id").primaryKey(),
      name: text("name").notNull(),
      kind: text("kind").notNull(),
      text: text("text").notNull(),
      addedAt: integer("added_at").notNull()
    });
    skills = sqliteTable("skills", {
      id: text("id").primaryKey(),
      name: text("name").notNull(),
      json: text("json").notNull()
    });
    citations = sqliteTable("citations", {
      id: text("id").primaryKey(),
      title: text("title").notNull(),
      url: text("url").notNull(),
      collection: text("collection"),
      savedAt: integer("saved_at").notNull()
    });
  }
});

// src/db/index.ts
function dbStats() {
  return sqlite ? { engine, file: process.env.DB_PATH ?? "./research-engine.db" } : { engine: "memory" };
}
var MIGRATION, sqlite, engine, dbPath, mem, db;
var init_db = __esm({
  async "src/db/index.ts"() {
    "use strict";
    init_schema();
    MIGRATION = `
CREATE TABLE IF NOT EXISTS chats (id TEXT PRIMARY KEY, title TEXT, space_id TEXT, created_at INTEGER, updated_at INTEGER);
CREATE TABLE IF NOT EXISTS messages (id TEXT PRIMARY KEY, chat_id TEXT, role TEXT, content TEXT, model TEXT, created_at INTEGER);
CREATE TABLE IF NOT EXISTS documents (id TEXT PRIMARY KEY, name TEXT, kind TEXT, text TEXT, added_at INTEGER);
CREATE TABLE IF NOT EXISTS skills (id TEXT PRIMARY KEY, name TEXT, json TEXT);
CREATE TABLE IF NOT EXISTS citations (id TEXT PRIMARY KEY, title TEXT, url TEXT, collection TEXT, saved_at INTEGER);
`;
    sqlite = null;
    engine = "memory";
    dbPath = process.env.DB_PATH ?? "./research-engine.db";
    try {
      const specifier = "better-sqlite3";
      const Database = (await import(specifier)).default;
      sqlite = new Database(dbPath);
      sqlite.pragma("journal_mode = WAL");
      sqlite.exec(MIGRATION);
      engine = "sqlite (better-sqlite3)";
    } catch {
      try {
        const { DatabaseSync } = await import("node:sqlite");
        sqlite = new DatabaseSync(dbPath);
        sqlite.exec("PRAGMA journal_mode = WAL");
        sqlite.exec(MIGRATION);
        engine = "sqlite (node:sqlite)";
      } catch (e2) {
        console.warn("[re] no SQLite driver available \u2014 using in-memory fallback (data will not survive a restart). (" + e2.message + ")");
      }
    }
    mem = {
      chats: /* @__PURE__ */ new Map(),
      documents: /* @__PURE__ */ new Map()
    };
    db = {
      schema: schema_exports,
      insertChat(chat) {
        if (sqlite) sqlite.prepare("INSERT OR REPLACE INTO chats VALUES (?,?,?,?,?)").run(chat.id, chat.title, chat.spaceId ?? null, chat.createdAt, chat.updatedAt);
        else mem.chats.set(chat.id, chat);
      },
      insertDocument(doc) {
        if (sqlite) sqlite.prepare("INSERT OR REPLACE INTO documents VALUES (?,?,?,?,?)").run(doc.id, doc.name, doc.kind, doc.text, doc.addedAt);
        else mem.documents.set(doc.id, doc);
      },
      listDocuments() {
        if (sqlite) return sqlite.prepare("SELECT id, name, kind, added_at as addedAt FROM documents ORDER BY added_at DESC").all();
        return [...mem.documents.values()];
      }
    };
  }
});

// src/routes/health.ts
var health_exports = {};
__export(health_exports, {
  healthRoutes: () => healthRoutes,
  installMode: () => installMode,
  sourceVersion: () => sourceVersion,
  webBuild: () => webBuild
});
import { Hono } from "hono";
function healthRoutes(frontendDist) {
  const app = new Hono();
  app.get(
    "/health",
    (c) => c.json({
      ok: true,
      service: "research-engine-backend",
      time: (/* @__PURE__ */ new Date()).toISOString(),
      db: dbStats(),
      // Frontend fingerprint, so the UI can warn about a stale self-hosted copy.
      web: { served: webBuild(frontendDist), source: sourceVersion(), mode: installMode() },
      // Which OS and Node this server actually runs on. Platform-specific bugs
      // (a Windows path separator, a missing POSIX binary) are invisible until
      // someone names the platform, so the diagnostics report carries it.
      runtime: {
        platform: process.platform,
        arch: process.arch,
        node: process.version,
        pathSep: process.platform === "win32" ? "\\" : "/"
      }
    })
  );
  return app;
}
var init_health = __esm({
  async "src/routes/health.ts"() {
    "use strict";
    await init_db();
    init_build_info();
    init_build_info();
  }
});

// src/services/search/adapters.ts
async function searchSearxng(base, q) {
  const res = await fetch(`${base.replace(/\/$/, "")}/search?q=${encodeURIComponent(q)}&format=json`);
  if (!res.ok) throw new Error(`SearXNG responded ${res.status}`);
  const json = await res.json();
  return (json.results ?? []).slice(0, 8).map((r) => ({
    title: r.title,
    url: r.url,
    snippet: r.content ?? "",
    domain: new URL(r.url).hostname
  }));
}
async function searchBrave(q) {
  const key = process.env.BRAVE_API_KEY;
  if (!key) throw new Error("BRAVE_API_KEY is not set on the backend");
  const res = await fetch(`https://api.search.brave.com/res/v1/web/search?q=${encodeURIComponent(q)}`, {
    headers: { "X-Subscription-Token": key, accept: "application/json" }
  });
  if (!res.ok) throw new Error(`Brave responded ${res.status}`);
  const json = await res.json();
  return (json.web?.results ?? []).slice(0, 8).map((r) => ({
    title: r.title,
    url: r.url,
    snippet: r.description ?? "",
    domain: new URL(r.url).hostname
  }));
}
async function searchSerper(q) {
  const key = process.env.SERPER_API_KEY;
  if (!key) throw new Error("SERPER_API_KEY is not set on the backend");
  const res = await fetch("https://google.serper.dev/search", {
    method: "POST",
    headers: { "X-API-KEY": key, "content-type": "application/json" },
    body: JSON.stringify({ q })
  });
  if (!res.ok) throw new Error(`Serper responded ${res.status}`);
  const json = await res.json();
  return (json.organic ?? []).slice(0, 8).map((r) => ({
    title: r.title,
    url: r.link,
    snippet: r.snippet ?? "",
    domain: new URL(r.link).hostname
  }));
}
async function searchTavily(q) {
  const key = process.env.TAVILY_API_KEY;
  if (!key) throw new Error("TAVILY_API_KEY is not set on the backend");
  const res = await fetch("https://api.tavily.com/search", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ api_key: key, query: q, max_results: 8 })
  });
  if (!res.ok) throw new Error(`Tavily responded ${res.status}`);
  const json = await res.json();
  return (json.results ?? []).map((r) => ({
    title: r.title,
    url: r.url,
    snippet: r.content ?? "",
    domain: new URL(r.url).hostname
  }));
}
async function searchDdg(q) {
  const res = await fetch(`https://html.duckduckgo.com/html/?q=${encodeURIComponent(q)}`, {
    headers: { "user-agent": "Mozilla/5.0 (Research Engine)" }
  });
  if (!res.ok) throw new Error(`DuckDuckGo responded ${res.status}`);
  const html = await res.text();
  const out = [];
  const re = /<a[^>]+class="result__a"[^>]+href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/g;
  let m;
  while ((m = re.exec(html)) && out.length < 8) {
    const url = decodeURIComponent(m[1].replace(/^.*uddg=/, "").replace(/&rut=.*$/, ""));
    const title = m[2].replace(/<[^>]+>/g, "").trim();
    if (url.startsWith("http")) out.push({ title, url, snippet: "", domain: new URL(url).hostname });
  }
  return out;
}
function searchDemo(q) {
  const domains = ["arxiv.org", "nature.com", "wikipedia.org", "acm.org", "ncbi.nlm.nih.gov"];
  return domains.map((d, i) => ({
    title: `${q} \u2014 result ${i + 1}`,
    url: `https://${d}/${encodeURIComponent(q.toLowerCase().replace(/\s+/g, "-"))}`,
    snippet: `Demo result for "${q}" (configure a real backend in .env).`,
    domain: d
  }));
}
var init_adapters = __esm({
  "src/services/search/adapters.ts"() {
    "use strict";
  }
});

// src/routes/search.ts
var search_exports = {};
__export(search_exports, {
  searchRoutes: () => searchRoutes
});
import { Hono as Hono2 } from "hono";
var searchRoutes;
var init_search = __esm({
  "src/routes/search.ts"() {
    "use strict";
    init_adapters();
    searchRoutes = new Hono2();
    searchRoutes.get("/", async (c) => {
      const q = c.req.query("q");
      if (!q) return c.json({ error: "Missing ?q=" }, 400);
      if (c.req.query("offline") === "1") {
        return c.json({ backend: "demo", results: searchDemo(q) });
      }
      const requested = c.req.query("backend") ?? process.env.SEARCH_BACKEND ?? "searxng";
      const run = async (backend) => {
        switch (backend) {
          case "searxng":
            return searchSearxng(process.env.SEARXNG_URL ?? "http://localhost:8080", q);
          case "brave":
            return searchBrave(q);
          case "serper":
            return searchSerper(q);
          case "tavily":
            return searchTavily(q);
          case "ddg":
            return searchDdg(q);
          default:
            return searchDemo(q);
        }
      };
      try {
        const results = await run(requested);
        if (results.length) return c.json({ backend: requested, results });
      } catch {
      }
      if (requested !== "ddg") {
        try {
          const results = await searchDdg(q);
          if (results.length) return c.json({ backend: "ddg", results });
        } catch {
        }
      }
      return c.json({ backend: "demo", results: searchDemo(q) });
    });
  }
});

// src/routes/secrets.ts
function maskSecrets(text2) {
  let out = String(text2 ?? "");
  for (const re of PATTERNS) out = out.replace(re, "[REDACTED]");
  return out;
}
var PATTERNS;
var init_secrets = __esm({
  "src/routes/secrets.ts"() {
    "use strict";
    PATTERNS = [
      /\bsk-[A-Za-z0-9_-]{16,}\b/g,
      // OpenAI-style
      /\bsk-ant-[A-Za-z0-9_-]{16,}\b/g,
      // Anthropic
      /\bsk-proj-[A-Za-z0-9_-]{16,}\b/g,
      /\bAIza[0-9A-Za-z_-]{30,}\b/g,
      // Google / Gemini
      /\bghp_[A-Za-z0-9]{30,}\b/g,
      // GitHub PAT
      /\bgho_[A-Za-z0-9]{30,}\b/g,
      /\bgithub_pat_[A-Za-z0-9_]{30,}\b/g,
      /\bxox[baprs]-[A-Za-z0-9-]{10,}\b/g,
      // Slack
      /\bAKIA[0-9A-Z]{16}\b/g,
      // AWS
      /\bhf_[A-Za-z0-9]{20,}\b/g,
      // HuggingFace
      /\bnvapi-[A-Za-z0-9_-]{16,}\b/g,
      // NVIDIA NIM
      /\beyJ[A-Za-z0-9_-]{12,}\.[A-Za-z0-9_-]{12,}\.[A-Za-z0-9_-]{6,}\b/g,
      // JWT
      /-----BEGIN [A-Z ]*PRIVATE KEY-----[\s\S]{20,}?-----END [A-Z ]*PRIVATE KEY-----/g,
      /\bkey-[A-Za-z0-9]{20,}\b/g
    ];
  }
});

// src/routes/chat.ts
var chat_exports = {};
__export(chat_exports, {
  chatRoutes: () => chatRoutes,
  toGeminiContents: () => toGeminiContents
});
import { Hono as Hono3 } from "hono";
import { streamSSE } from "hono/streaming";
function toOpenAIMessages(system, messages2) {
  const out = system ? [{ role: "system", content: system }] : [];
  for (const m of messages2) {
    if (m.role === "tool") {
      out.push({ role: "tool", tool_call_id: m.toolCallId, content: typeof m.content === "string" ? m.content : JSON.stringify(m.content) });
      continue;
    }
    const msg = { role: m.role };
    if (Array.isArray(m.content)) {
      msg.content = m.content.map((p) => p.type === "image" ? { type: "image_url", image_url: { url: p.dataUrl } } : { type: "text", text: p.text });
    } else {
      msg.content = m.content ?? "";
    }
    if (m.toolCalls?.length) {
      msg.tool_calls = m.toolCalls.map((t) => {
        const out2 = { id: t.id, type: "function", function: { name: t.name, arguments: typeof t.arguments === "string" ? t.arguments : JSON.stringify(t.arguments ?? {}) } };
        const sig = t.thoughtSignature ?? t.thought_signature ?? t.extraContent?.google?.thought_signature ?? t.extra_content?.google?.thought_signature;
        if (sig) out2.extra_content = { google: { thought_signature: sig } };
        return out2;
      });
    }
    out.push(msg);
  }
  return out;
}
function toGeminiContents(messages2) {
  const out = [];
  for (const m of messages2) {
    if (m.role === "tool") {
      out.push({ role: "user", parts: [{ functionResponse: { name: m.name ?? "tool", id: m.toolCallId, response: { result: typeof m.content === "string" ? m.content : JSON.stringify(m.content) } } }] });
      continue;
    }
    const role = m.role === "assistant" ? "model" : "user";
    const parts = [];
    if (Array.isArray(m.content)) {
      for (const p of m.content) {
        if (p.type === "image") {
          const { mime, data } = splitDataUrl(p.dataUrl);
          parts.push({ inline_data: { mime_type: mime, data } });
        } else if (p.text) parts.push({ text: p.text });
      }
    } else if (typeof m.content === "string" && m.content) {
      parts.push({ text: m.content });
    }
    if (m.toolCalls?.length) {
      for (const t of m.toolCalls) {
        let args2 = t.arguments;
        if (typeof args2 === "string") {
          try {
            args2 = JSON.parse(args2);
          } catch {
            args2 = { input: args2 };
          }
        }
        const part = { functionCall: { name: t.name, args: args2 ?? {}, ...t.id ? { id: t.id } : {} } };
        const sig = t.thoughtSignature ?? t.thought_signature ?? t.extraContent?.google?.thought_signature ?? t.extra_content?.google?.thought_signature;
        if (sig) part.thoughtSignature = sig;
        parts.push(part);
      }
    }
    if (parts.length) out.push({ role, parts });
  }
  return out;
}
function toAnthropicBody(system, messages2) {
  const out = [];
  for (const m of messages2) {
    if (m.role === "tool") {
      out.push({ role: "user", content: [{ type: "tool_result", tool_use_id: m.toolCallId, content: typeof m.content === "string" ? m.content : JSON.stringify(m.content) }] });
      continue;
    }
    const content = [];
    if (Array.isArray(m.content)) {
      for (const p of m.content) {
        if (p.type === "image") {
          const { mime, data } = splitDataUrl(p.dataUrl);
          content.push({ type: "image", source: { type: "base64", media_type: mime, data } });
        } else if (p.text) content.push({ type: "text", text: p.text });
      }
    } else if (typeof m.content === "string" && m.content) {
      content.push({ type: "text", text: m.content });
    }
    if (m.role === "assistant" && m.toolCalls?.length) {
      for (const t of m.toolCalls) {
        let input = t.arguments;
        if (typeof input === "string") {
          try {
            input = JSON.parse(input);
          } catch {
            input = {};
          }
        }
        content.push({ type: "tool_use", id: t.id, name: t.name, input: input ?? {} });
      }
    }
    if (content.length) out.push({ role: m.role === "assistant" ? "assistant" : "user", content });
  }
  const merged = [];
  for (const m of out) {
    const last = merged[merged.length - 1];
    if (last && last.role === m.role) last.content = [...last.content, ...m.content];
    else merged.push(m);
  }
  return { system: system || void 0, messages: merged.filter((m) => m.role === "user" || merged.indexOf(m) > 0) };
}
var chatRoutes, splitDataUrl;
var init_chat = __esm({
  "src/routes/chat.ts"() {
    "use strict";
    init_secrets();
    chatRoutes = new Hono3();
    splitDataUrl = (dataUrl) => {
      const m = /^data:([^;]+);base64,(.*)$/s.exec(dataUrl ?? "");
      return m ? { mime: m[1], data: m[2] } : { mime: "image/png", data: dataUrl ?? "" };
    };
    chatRoutes.post("/", async (c) => {
      const body = await c.req.json();
      const kind = body.kind ?? "openai";
      const model = body.model;
      const key = body.key ?? body.apiKey ?? "";
      const base = String(body.base ?? body.baseUrl ?? "").replace(/\/+$/, "");
      const system = body.system ?? "";
      const messages2 = body.messages ?? [];
      const maxTokens = body.maxTokens ?? 1024;
      const temperature = body.temperature ?? 0.7;
      const tools = Array.isArray(body.tools) && body.tools.length ? body.tools : null;
      if (!model) return c.json({ error: "model is required" }, 400);
      if (!base) return c.json({ error: "base is required" }, 400);
      let url;
      let headers;
      let payload;
      const isNvidia = base.includes("api.nvidia.com") || kind === "nim";
      const isOpenRouter = base.includes("openrouter.ai");
      const browserish = {
        "user-agent": isNvidia ? "NVIDIA-NIM-Client/1.0" : "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
        accept: "text/event-stream"
      };
      if (kind === "anthropic") {
        url = `${base}/messages`;
        headers = {
          ...browserish,
          "content-type": "application/json",
          "x-api-key": key,
          "anthropic-version": "2023-06-01"
        };
        const conv = toAnthropicBody(system, messages2);
        payload = { model, stream: true, max_tokens: maxTokens, temperature, system: conv.system ?? "", messages: conv.messages };
        if (tools) {
          payload.tools = tools.map((t) => ({ name: t.function.name, description: t.function.description ?? "", input_schema: t.function.parameters ?? { type: "object", properties: {} } }));
        }
      } else if (kind === "gemini") {
        url = `${base}/models/${encodeURIComponent(model)}:streamGenerateContent?alt=sse`;
        headers = {
          ...browserish,
          "content-type": "application/json",
          ...key ? { "x-goog-api-key": key } : {}
        };
        payload = {
          contents: toGeminiContents(messages2),
          generationConfig: { temperature, maxOutputTokens: maxTokens }
        };
        if (system) payload.systemInstruction = { parts: [{ text: system }] };
        if (tools) {
          payload.tools = [{
            functionDeclarations: tools.map((t) => ({
              name: t.function.name,
              description: t.function.description ?? "",
              parameters: t.function.parameters ?? { type: "object", properties: {} }
            }))
          }];
        }
      } else {
        url = `${base}/chat/completions`;
        headers = {
          ...browserish,
          "content-type": "application/json",
          ...key ? { authorization: `Bearer ${key}` } : {},
          ...isNvidia && key ? { "x-nvidia-api-key": key } : {},
          ...isOpenRouter ? { "HTTP-Referer": "https://researchengine.local", "X-OpenRouter-Title": "Research Engine" } : {}
        };
        payload = {
          model,
          stream: true,
          max_tokens: maxTokens,
          temperature,
          messages: toOpenAIMessages(system, messages2)
        };
        if (tools) {
          payload.tools = tools;
          payload.tool_choice = "auto";
        }
        if (isNvidia && /deepseek|reasoning|qwq|thought|thinking|nemotron/i.test(model)) {
          payload.chat_template_kwargs = { enable_thinking: true, thinking: true };
        }
      }
      const upstream = await fetch(url, {
        method: "POST",
        headers,
        body: JSON.stringify(payload),
        signal: c.req.raw.signal
        // client abort kills the upstream call
      });
      if (!upstream.ok || !upstream.body) {
        const errText = await upstream.text().catch(() => "");
        let msg = `${upstream.status}`;
        try {
          const j = JSON.parse(errText);
          msg = j?.error?.message ?? j?.detail ?? j?.message ?? msg;
        } catch {
        }
        if (upstream.status === 403 && isNvidia) {
          msg += " \u2014 NVIDIA rejected this key for chat. GET /v1/models can still work when inference is not enabled. Check that your NVIDIA organization has Public API Endpoints access, accept the model terms on its catalog page, regenerate the nvapi key, and try a currently chat-capable model. Research Engine already sends NVIDIA-NIM-Client/1.0, Bearer, and X-NVIDIA-API-Key headers.";
        }
        return c.json({ error: maskSecrets(msg) }, upstream.status);
      }
      c.header("Content-Type", "text/event-stream");
      c.header("Cache-Control", "no-cache");
      return streamSSE(c, async (stream) => {
        const reader = upstream.body.getReader();
        const td = new TextDecoder();
        try {
          for (; ; ) {
            const { done, value } = await reader.read();
            if (done) break;
            await stream.write(td.decode(value, { stream: true }));
          }
        } catch {
        }
      });
    });
  }
});

// src/routes/documents.ts
var documents_exports = {};
__export(documents_exports, {
  documentRoutes: () => documentRoutes
});
import { Hono as Hono4 } from "hono";
var documentRoutes;
var init_documents = __esm({
  async "src/routes/documents.ts"() {
    "use strict";
    await init_db();
    documentRoutes = new Hono4();
    documentRoutes.post("/", async (c) => {
      const body = await c.req.json();
      const { id, name, kind = "file", text: text2 = "" } = body;
      if (!id || !name) return c.json({ error: "id and name are required" }, 400);
      db.insertDocument({ id, name, kind, text: text2, addedAt: Date.now() });
      return c.json({ ok: true, id });
    });
    documentRoutes.get("/", (c) => c.json({ documents: db.listDocuments() }));
  }
});

// src/routes/ollama.ts
var ollama_exports = {};
__export(ollama_exports, {
  ollamaRoutes: () => ollamaRoutes
});
import { Hono as Hono5 } from "hono";
var ollamaRoutes;
var init_ollama = __esm({
  "src/routes/ollama.ts"() {
    "use strict";
    ollamaRoutes = new Hono5();
    ollamaRoutes.get("/tags", async (c) => {
      const base = (process.env.OLLAMA_URL ?? "http://localhost:11434").replace(/\/$/, "");
      try {
        const res = await fetch(`${base}/api/tags`);
        if (!res.ok) return c.json({ error: `Ollama responded ${res.status}` }, 502);
        return c.json(await res.json());
      } catch (e) {
        return c.json({ error: `Cannot reach Ollama at ${base}: ${e.message}` }, 502);
      }
    });
  }
});

// src/routes/integrations.ts
var integrations_exports = {};
__export(integrations_exports, {
  integrationRoutes: () => integrationRoutes
});
import { Hono as Hono6 } from "hono";
var integrationRoutes, pending;
var init_integrations = __esm({
  "src/routes/integrations.ts"() {
    "use strict";
    integrationRoutes = new Hono6();
    pending = /* @__PURE__ */ new Map();
    integrationRoutes.post("/oauth/start", async (c) => {
      const { provider, scopes = [] } = await c.req.json();
      const state = Math.random().toString(36).slice(2);
      pending.set(state, { provider, createdAt: Date.now() });
      return c.json({ state, provider, scopes, note: "Authorize via the localhost callback." });
    });
    integrationRoutes.get("/oauth/callback", (c) => {
      const state = c.req.query("state");
      if (!state || !pending.has(state)) return c.json({ error: "Unknown or expired OAuth state" }, 400);
      const info = pending.get(state);
      pending.delete(state);
      return c.json({ ok: true, provider: info.provider, note: "Token handed to the local encrypted vault." });
    });
  }
});

// src/routes/resources.ts
var resources_exports = {};
__export(resources_exports, {
  resourceRoutes: () => resourceRoutes
});
import { existsSync as existsSync4, statSync as statSync4 } from "node:fs";
import { join as join4 } from "node:path";
import { Hono as Hono7 } from "hono";
function resourceRoutes(rt) {
  const r = new Hono7();
  r.get("/resources", (c) => {
    const mem2 = process.memoryUsage();
    const dbFile = rt.dbPath;
    return c.json({
      ok: true,
      process: {
        rssMB: Math.round(mem2.rss / 1048576),
        heapMB: Math.round(mem2.heapUsed / 1048576),
        uptimeSec: Math.round(process.uptime()),
        node: process.version
      },
      dataDir: {
        path: rt.dataDir,
        totalMB: +(dirSize(rt.dataDir) / 1048576).toFixed(1)
      },
      db: {
        ...dbStats(),
        sizeMB: existsSync4(dbFile) ? +(statSync4(dbFile).size / 1048576).toFixed(2) : 0
      },
      cacheMB: +(dirSize(join4(rt.dataDir, "cache")) / 1048576).toFixed(1),
      profile: rt.profile,
      caps: rt.caps,
      profiles: Object.fromEntries(Object.entries(PROFILES).map(([k, v]) => [k, { description: v.description }]))
    });
  });
  r.get("/config", (c) => c.json({
    ok: true,
    port: rt.port,
    dataDir: rt.dataDir,
    profile: rt.profile,
    caps: rt.caps,
    frontendServed: !!rt.frontendDist
  }));
  r.post("/config", async (c) => {
    const body = await c.req.json().catch(() => ({}));
    if (body.profile && body.profile in PROFILES) {
      const profile = body.profile;
      rt.profile = profile;
      rt.caps = PROFILES[profile];
      saveConfig(rt.dataDir, { profile });
      return c.json({ ok: true, profile, caps: rt.caps });
    }
    return c.json({ ok: false, error: "Unknown profile" }, 400);
  });
  return r;
}
var init_resources = __esm({
  async "src/routes/resources.ts"() {
    "use strict";
    await init_db();
    init_runtime();
  }
});

// src/preview/paths.ts
import { isAbsolute, join as join5, relative, resolve as resolve2 } from "node:path";
function projectsRootOf(dataDir) {
  return resolve2(join5(dataDir, "projects"));
}
function isInternalEntry(name) {
  return INTERNAL_PREFIX.some((p) => name.startsWith(p));
}
function tidy(n) {
  return n.replace(/[. ]+$/, "");
}
function normalizeProjectName(raw) {
  const original = String(raw ?? "");
  let n = original.replace(ILLEGAL, " ").replace(/\s+/g, " ").trim();
  n = tidy(n);
  if (!n) return null;
  if (n === "." || n === "..") n = `project${n === "." ? "" : "-dot"}`;
  if (WINDOWS_DEVICE.test(n)) n = `${n}-project`;
  if (Buffer.byteLength(n, "utf8") > 128) {
    while (Buffer.byteLength(n, "utf8") > 128) n = n.slice(0, -1);
    n = tidy(n);
  }
  if (!n) return null;
  return { name: n, changed: n !== original.trim().replace(/\s+/g, " ") };
}
function normPath(p) {
  const unified = p.replace(/[\\/]+/g, "/").replace(/\/+$/, "");
  return process.platform === "win32" ? unified.toLowerCase() : unified;
}
function isWithinDir(parent, child) {
  if (normPath(parent) === normPath(child)) return true;
  const rel = relative(parent, child);
  if (rel !== "" && !rel.startsWith("..") && !isAbsolute(rel)) return true;
  return normPath(child).startsWith(normPath(parent) + "/");
}
function isStrictlyWithinDir(parent, child) {
  return normPath(parent) !== normPath(child) && isWithinDir(parent, child);
}
function safeProjectName(name) {
  return normalizeProjectName(name)?.name ?? null;
}
function projectDirOf(projectsRoot, name) {
  const n = safeProjectName(name);
  if (!n) return null;
  const abs = resolve2(join5(projectsRoot, n));
  return isStrictlyWithinDir(projectsRoot, abs) ? abs : null;
}
function projectDirFor(projectsRoot, name) {
  const normalized = normalizeProjectName(name);
  if (!normalized) return null;
  const abs = resolve2(join5(projectsRoot, normalized.name));
  if (!isStrictlyWithinDir(projectsRoot, abs)) return null;
  return { dir: abs, ...normalized };
}
var INTERNAL_PREFIX, ILLEGAL, WINDOWS_DEVICE;
var init_paths = __esm({
  "src/preview/paths.ts"() {
    "use strict";
    INTERNAL_PREFIX = [".import-", ".tmp-", ".trash-"];
    ILLEGAL = /[<>:"/\\|?*\u0000-\u001f\u007f]/g;
    WINDOWS_DEVICE = /^(con|prn|aux|nul|com[1-9]|lpt[1-9])(\..*)?$/i;
  }
});

// src/routes/fs.ts
var fs_exports = {};
__export(fs_exports, {
  fsRoutes: () => fsRoutes
});
import { mkdir, readFile, readdir, stat, writeFile } from "node:fs/promises";
import { dirname as dirname2, join as join6, resolve as resolve3 } from "node:path";
import { Hono as Hono8 } from "hono";
function fsRoutes(rt) {
  const r = new Hono8();
  const root = resolve3(join6(rt.dataDir, "files"));
  const safePath = (rel) => {
    if (!rel || rel.startsWith("/") || rel.includes("..")) return null;
    const abs = resolve3(join6(root, rel));
    return isWithinDir(root, abs) ? abs : null;
  };
  r.get("/fs/read", async (c) => {
    const rel = c.req.query("path") ?? "";
    const abs = safePath(rel);
    if (!abs) return c.text("Path must stay inside the Research Engine files folder.", 400);
    try {
      return c.text(await readFile(abs, "utf8"));
    } catch {
      return c.text("File not found.", 404);
    }
  });
  r.post("/fs/write", async (c) => {
    let body;
    try {
      body = await c.req.json();
    } catch {
      return c.text("Invalid JSON body.", 400);
    }
    const abs = safePath(body.path ?? "");
    if (!abs) return c.text("Path must stay inside the Research Engine files folder.", 400);
    if (typeof body.content !== "string") return c.text("Missing content.", 400);
    if (body.content.length > 2e6) return c.text("Content too large (2 MB limit).", 413);
    await mkdir(dirname2(abs), { recursive: true });
    await writeFile(abs, body.content, "utf8");
    return c.json({ ok: true, path: body.path });
  });
  r.get("/fs/read-bin", async (c) => {
    const rel = c.req.query("path") ?? "";
    const abs = safePath(rel);
    if (!abs) return c.text("Path must stay inside the Research Engine files folder.", 400);
    try {
      const buf = await readFile(abs);
      const ext = abs.toLowerCase();
      const type = ext.endsWith(".pdf") ? "application/pdf" : ext.endsWith(".docx") ? "application/vnd.openxmlformats-officedocument.wordprocessingml.document" : "application/octet-stream";
      return c.body(new Uint8Array(buf), 200, { "content-type": type });
    } catch {
      return c.text("File not found.", 404);
    }
  });
  r.get("/fs/list", async (c) => {
    await mkdir(root, { recursive: true });
    let entries = [];
    try {
      const list = await readdir(root, { withFileTypes: true });
      entries = await Promise.all(list.map(async (e) => {
        if (e.name.startsWith(".")) return null;
        const dir = e.isDirectory();
        let size = 0;
        if (!dir) {
          try {
            size = (await stat(join6(root, e.name))).size;
          } catch {
          }
        }
        return { name: e.name, dir, size };
      })).then((a) => a.filter(Boolean));
      entries.sort((x, y) => Number(y.dir) - Number(x.dir) || x.name.localeCompare(y.name));
    } catch {
    }
    return c.json({ root, files: entries });
  });
  r.post("/fs/upload", async (c) => {
    let body;
    try {
      body = await c.req.json();
    } catch {
      return c.text("Invalid JSON body.", 400);
    }
    const name = (body.name ?? "").replace(/[\\/]/g, "_").trim();
    if (!name || name.startsWith(".")) return c.text("Missing file name.", 400);
    if (typeof body.dataBase64 !== "string") return c.text("Missing dataBase64.", 400);
    const buf = Buffer.from(body.dataBase64, "base64");
    if (buf.length > 8 * 1024 * 1024) return c.text("File too large (8 MB limit).", 413);
    const abs = safePath(name);
    if (!abs) return c.text("File name must stay inside the Research Engine files folder.", 400);
    await mkdir(dirname2(abs), { recursive: true });
    await writeFile(abs, buf);
    return c.json({ ok: true, path: name, size: buf.length });
  });
  return r;
}
var init_fs = __esm({
  "src/routes/fs.ts"() {
    "use strict";
    init_paths();
  }
});

// src/routes/providers.ts
var providers_exports = {};
__export(providers_exports, {
  providerRoutes: () => providerRoutes
});
import { Hono as Hono9 } from "hono";
async function discover(kind, base, key, timeout) {
  const t0 = Date.now();
  try {
    if (kind === "ollama") {
      const res2 = await fetch(`${base}/api/tags`, { signal: AbortSignal.timeout(timeout) });
      if (!res2.ok) return { error: `Ollama responded ${res2.status}`, ms: Date.now() - t0 };
      const json2 = await res2.json();
      return { models: (json2.models ?? []).map((m) => String(m.name)), ms: Date.now() - t0 };
    }
    const headers = {
      // NVIDIA NIM UA-dialect: its gateways 403 generic user-agents.
      "user-agent": base.includes("api.nvidia.com") || kind === "nim" ? "NVIDIA-NIM-Client/1.0" : "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
      accept: "application/json"
    };
    if (base.includes("openrouter.ai")) {
      headers["HTTP-Referer"] = "https://researchengine.local";
      headers["X-OpenRouter-Title"] = "Research Engine";
    }
    if (kind === "anthropic") {
      headers["x-api-key"] = key;
      headers["anthropic-version"] = "2023-06-01";
    } else if (kind === "gemini") {
      headers["x-goog-api-key"] = key;
    } else if (key) {
      headers.authorization = `Bearer ${key}`;
    }
    const res = await fetch(`${base}/models`, { headers, signal: AbortSignal.timeout(timeout) });
    if (!res.ok) {
      let msg = `Provider responded ${res.status}`;
      try {
        const j = await res.json();
        msg = j?.error?.message ?? j?.detail ?? j?.message ?? msg;
      } catch {
      }
      if (res.status === 403 && (base.includes("api.nvidia.com") || kind === "nim")) {
        msg += " \u2014 NVIDIA may allow model listing while blocking inference. Check Public API Endpoints access, model terms, key status, and current model availability.";
      }
      return { error: maskSecrets(msg), ms: Date.now() - t0 };
    }
    const json = await res.json();
    if (kind === "gemini") {
      const models2 = (json.models ?? []).filter((m) => Array.isArray(m?.supportedGenerationMethods) && m.supportedGenerationMethods.includes("generateContent")).map((m) => String(m.name ?? "").replace(/^models\//, "")).filter(Boolean);
      return { models: models2, ms: Date.now() - t0 };
    }
    const models = (json.data ?? []).map((m) => String(m.id ?? m.name)).filter(Boolean);
    return { models, ms: Date.now() - t0 };
  } catch (e) {
    const msg = e?.name === "TimeoutError" || e?.name === "AbortError" ? `Timed out after ${Math.round(timeout / 1e3)}s` : e?.message ?? "Network error";
    return { error: msg, ms: Date.now() - t0 };
  }
}
function args(c) {
  const kind = c.req.query("kind") ?? "openai";
  const base = (c.req.query("base") ?? "").replace(/\/+$/, "");
  const key = c.req.header("x-re-key") ?? "";
  return { kind, base, key };
}
var providerRoutes, MODELS_TIMEOUT_MS, TEST_TIMEOUT_MS;
var init_providers = __esm({
  "src/routes/providers.ts"() {
    "use strict";
    init_secrets();
    providerRoutes = new Hono9();
    MODELS_TIMEOUT_MS = 8e3;
    TEST_TIMEOUT_MS = 6e3;
    providerRoutes.get("/providers/models", async (c) => {
      const { kind, base, key } = args(c);
      if (!base) return c.json({ error: "base is required" }, 400);
      const out = await discover(kind, base, key, MODELS_TIMEOUT_MS);
      if (out.error) return c.json(out, 502);
      return c.json(out);
    });
    providerRoutes.get("/providers/test", async (c) => {
      const { kind, base, key } = args(c);
      if (!base) return c.json({ error: "base is required" }, 400);
      const out = await discover(kind, base, key, TEST_TIMEOUT_MS);
      if (out.error) return c.json(out, 502);
      return c.json({ ms: out.ms });
    });
  }
});

// src/routes/ide.ts
var ide_exports = {};
__export(ide_exports, {
  ideRoutes: () => ideRoutes
});
import { mkdir as mkdir2, readFile as readFile2, readdir as readdir2, rm, stat as stat2, writeFile as writeFile2, rename } from "node:fs/promises";
import { existsSync as existsSync5 } from "node:fs";
import { join as join7, resolve as resolve4, dirname as dirname3 } from "node:path";
import { spawn, spawnSync } from "node:child_process";
import { randomUUID } from "node:crypto";
import { Hono as Hono10 } from "hono";
function scrubbedEnv() {
  const out = {};
  for (const [k, v] of Object.entries(process.env)) {
    if (/key|token|secret|passw|credential|auth/i.test(k)) continue;
    if (typeof v === "string") out[k] = v;
  }
  return out;
}
function ideRoutes(rt) {
  const r = new Hono10();
  const projectsRoot = projectsRootOf(rt.dataDir);
  mkdir2(projectsRoot, { recursive: true }).catch(() => {
  });
  const projectDir = (name) => projectDirOf(projectsRoot, name);
  const existingFor = async (name) => {
    const wanted = name.toLowerCase();
    for (const e of await readdir2(projectsRoot, { withFileTypes: true }).catch(() => [])) {
      if (e.isDirectory() && e.name.toLowerCase() === wanted) return e.name;
    }
    return null;
  };
  const freeName = async (base) => {
    if (!await existingFor(base)) return base;
    for (let i = 2; i < 500; i++) {
      const candidate = `${base}-${i}`;
      if (!await existingFor(candidate)) return candidate;
    }
    return `${base}-${Date.now()}`;
  };
  const safeRel = (dir, rel) => {
    if (!rel || rel.startsWith("/") || rel.includes("\0")) return null;
    if (rel.split(/[/\\]/).some((seg) => seg === "..")) return null;
    const abs = resolve4(join7(dir, rel));
    return isStrictlyWithinDir(dir, abs) ? abs : null;
  };
  r.get("/ide/projects", async (c) => {
    await mkdir2(projectsRoot, { recursive: true });
    const out = [];
    for (const e of await readdir2(projectsRoot, { withFileTypes: true })) {
      if (!e.isDirectory() || isInternalEntry(e.name)) continue;
      const dir = join7(projectsRoot, e.name);
      let files = 0, size = 0;
      const walk = async (d, depth) => {
        if (depth > 6) return;
        for (const f of await readdir2(d, { withFileTypes: true })) {
          if (f.name === "node_modules" || f.name === ".git" || f.name.startsWith(".")) continue;
          const p = join7(d, f.name);
          if (f.isDirectory()) await walk(p, depth + 1);
          else {
            files++;
            try {
              size += (await stat2(p)).size;
            } catch {
            }
          }
        }
      };
      await walk(dir, 0).catch(() => {
      });
      let mtime = 0;
      try {
        mtime = (await stat2(dir)).mtimeMs;
      } catch {
      }
      out.push({ name: e.name, files, size, mtime, git: existsSync5(join7(dir, ".git")) });
    }
    return c.json({ projects: out.sort((a, b) => b.mtime - a.mtime) });
  });
  r.post("/ide/projects", async (c) => {
    let body;
    try {
      body = await c.req.json();
    } catch {
      return c.json({ error: "Invalid JSON body." }, 400);
    }
    const requested = normalizeProjectName(String(body.name ?? body.projectName ?? ""));
    const invented = !requested;
    const fallbackName = normalizeProjectName(String(body.fallback ?? ""));
    const base = (requested ?? fallbackName ?? { name: "untitled-project" }).name;
    const wantsUnique = !!body.unique || invented;
    const name = wantsUnique ? await freeName(base) : base;
    const dir = join7(projectsRoot, name);
    const existing = wantsUnique ? null : await existingFor(name);
    if (existing) {
      return c.json({
        error: `A project called \u201C${existing}\u201D already exists.`,
        code: "exists",
        existing
      }, 409);
    }
    await mkdir2(dir, { recursive: true });
    let written = 0;
    for (const [rel, content] of Object.entries(body.files ?? {})) {
      const abs = safeRel(dir, rel);
      if (!abs || typeof content !== "string" || content.length > 5e5) continue;
      await mkdir2(dirname3(abs), { recursive: true });
      await writeFile2(abs, content, "utf8");
      written++;
    }
    return c.json({ ok: true, name, renamed: name !== base, invented, files: written });
  });
  r.delete("/ide/projects/:name", async (c) => {
    const dir = projectDir(c.req.param("name"));
    if (!dir || !existsSync5(dir)) return c.json({ error: "Project not found." }, 404);
    await rm(dir, { recursive: true, force: true });
    return c.json({ ok: true });
  });
  r.post("/ide/projects/rename", async (c) => {
    let body;
    try {
      body = await c.req.json();
    } catch {
      return c.json({ error: "Invalid JSON body." }, 400);
    }
    const fromDir = projectDir(body.from ?? body.project ?? "");
    if (!fromDir || !existsSync5(fromDir)) return c.json({ error: "Project not found." }, 404);
    const currentName = await existingFor(String(body.from ?? body.project ?? ""));
    const target = projectDirFor(projectsRoot, body.to ?? "");
    if (!target) {
      return c.json({ ok: true, name: currentName, unchanged: true, kept: true, code: "bad_name" });
    }
    const toName = target.name;
    const toDir = target.dir;
    if (toDir === fromDir) return c.json({ ok: true, name: toName, unchanged: true });
    const fromName = currentName;
    const sameTarget = !!fromName && fromName.toLowerCase() === toName.toLowerCase();
    const taken = await existingFor(toName);
    if (taken && !sameTarget) {
      return c.json({ error: `A project called \u201C${taken}\u201D already exists.`, code: "exists", existing: taken }, 409);
    }
    try {
      await rename(fromDir, toDir);
      return c.json({ ok: true, name: toName });
    } catch (e) {
      return c.json({ error: String(e?.message ?? e) }, 500);
    }
  });
  r.post("/ide/import", async (c) => {
    let body;
    try {
      body = await c.req.json();
    } catch {
      return c.json({ error: "Invalid JSON body." }, 400);
    }
    const wanted = projectDirFor(projectsRoot, body.name ?? "") ?? projectDirFor(projectsRoot, "imported-project");
    const name = await freeName(wanted.name);
    const dir = name === wanted.name ? wanted.dir : projectDirFor(projectsRoot, name).dir;
    const buf = Buffer.from(body.dataBase64 ?? "", "base64");
    if (!buf.length || buf.length > IMPORT_CAP) return c.json({ error: "Archive missing or larger than 24 MB." }, 413);
    const fn = (body.fileName ?? "project.zip").toLowerCase();
    const isZip = fn.endsWith(".zip");
    const isTar = fn.endsWith(".tar.gz") || fn.endsWith(".tgz") || fn.endsWith(".tar");
    if (!isZip && !isTar) return c.json({ error: "Upload a .zip, .tar.gz or .tgz archive." }, 400);
    const tmp = join7(projectsRoot, `.import-${randomUUID()}`);
    await mkdir2(tmp, { recursive: true });
    const archive = join7(tmp, isZip ? "up.zip" : "up.tar.gz");
    try {
      await writeFile2(archive, buf);
      const res = isZip ? spawnSync("unzip", ["-q", "-o", archive, "-d", tmp], { timeout: 6e4 }) : spawnSync("tar", ["-xf", archive, "-C", tmp], { timeout: 6e4 });
      if (res.status !== 0) return c.json({ error: "Could not extract the archive (it may be corrupted or password-protected)." }, 400);
      await rm(archive, { force: true });
      let entries = (await readdir2(tmp)).filter((n) => !n.startsWith("."));
      if (entries.length === 1 && (await stat2(join7(tmp, entries[0]))).isDirectory()) {
        const inner = join7(tmp, entries[0]);
        for (const f of await readdir2(inner)) await rename(join7(inner, f), join7(tmp, f));
        await rm(inner, { force: true });
      }
      await rename(tmp, dir);
      return c.json({ ok: true, name, renamed: name !== wanted.name });
    } catch (e) {
      await rm(tmp, { recursive: true, force: true }).catch(() => {
      });
      return c.json({ error: String(e?.message ?? e) }, 500);
    }
  });
  r.get("/ide/tree", async (c) => {
    const dir = projectDir(c.req.query("project") ?? "");
    if (!dir || !existsSync5(dir)) return c.json({ error: "Project not found." }, 404);
    const SKIP = /* @__PURE__ */ new Set(["node_modules", ".git", "dist", "build", ".next", "__pycache__", ".venv"]);
    const walk = async (d, rel, depth) => {
      if (depth > 8) return [];
      const out = [];
      for (const e of await readdir2(d, { withFileTypes: true })) {
        if (SKIP.has(e.name)) continue;
        const p = join7(d, e.name);
        const rp = rel ? `${rel}/${e.name}` : e.name;
        if (e.isDirectory()) out.push({ name: e.name, path: rp, dir: true, children: await walk(p, rp, depth + 1) });
        else out.push({ name: e.name, path: rp, dir: false });
      }
      return out.sort((a, b) => Number(b.dir) - Number(a.dir) || a.name.localeCompare(b.name));
    };
    return c.json({ tree: await walk(dir, "", 0) });
  });
  r.get("/ide/file", async (c) => {
    const dir = projectDir(c.req.query("project") ?? "");
    const abs = dir ? safeRel(dir, c.req.query("path") ?? "") : null;
    if (!abs) return c.json({ error: "Path must stay inside the project." }, 400);
    try {
      const st = await stat2(abs);
      if (st.size > 1e6) return c.json({ error: "File too large to edit here (1 MB limit)." }, 413);
      return c.json({ content: await readFile2(abs, "utf8") });
    } catch {
      return c.json({ error: "File not found." }, 404);
    }
  });
  r.post("/ide/file", async (c) => {
    let body;
    try {
      body = await c.req.json();
    } catch {
      return c.json({ error: "Invalid JSON body." }, 400);
    }
    const dir = projectDir(body.project ?? "");
    const abs = dir ? safeRel(dir, body.path ?? "") : null;
    if (!abs) return c.json({ error: "Path must stay inside the project." }, 400);
    if (typeof body.content !== "string" || body.content.length > 1e6) return c.json({ error: "Content missing or over 1 MB." }, 413);
    await mkdir2(dirname3(abs), { recursive: true });
    await writeFile2(abs, body.content, "utf8");
    return c.json({ ok: true });
  });
  r.delete("/ide/file", async (c) => {
    const dir = projectDir(c.req.query("project") ?? "");
    const abs = dir ? safeRel(dir, c.req.query("path") ?? "") : null;
    if (!abs) return c.json({ error: "Path must stay inside the project." }, 400);
    if (!existsSync5(abs)) return c.json({ error: "File not found." }, 404);
    await rm(abs, { recursive: true, force: true });
    return c.json({ ok: true });
  });
  r.get("/ide/search", async (c) => {
    const dir = projectDir(c.req.query("project") ?? "");
    if (!dir || !existsSync5(dir)) return c.json({ error: "Project not found." }, 404);
    const q = (c.req.query("q") ?? "").trim();
    if (q.length < 2) return c.json({ results: [], note: "Type at least 2 characters." });
    const SKIP = /* @__PURE__ */ new Set(["node_modules", ".git", "dist", "build", ".next", "__pycache__", ".venv", "coverage", ".turbo", "out"]);
    const results = [];
    const needle = q.toLowerCase();
    const walk = async (d, rel, depth) => {
      if (depth > 8 || results.length >= 200) return;
      let entries;
      try {
        entries = await readdir2(d, { withFileTypes: true });
      } catch {
        return;
      }
      for (const e of entries) {
        if (results.length >= 200) return;
        if (SKIP.has(e.name) || e.name.startsWith(".")) continue;
        const abs = join7(d, e.name);
        const rp = rel ? rel + "/" + e.name : e.name;
        if (e.isDirectory()) {
          await walk(abs, rp, depth + 1);
          continue;
        }
        if (/^(.*\.(png|jpg|jpeg|gif|webp|ico|woff2?|ttf|pdf|zip|gz|mp4|mp3|so|node|dylib))$/i.test(e.name)) continue;
        if (rp.toLowerCase().includes(needle) && results.length < 40) results.push({ path: rp, line: 0, text: "file name match", kind: "file" });
        let text2 = "";
        try {
          const st = await stat2(abs);
          if (st.size > 512 * 1024) continue;
          text2 = await readFile2(abs, "utf8");
        } catch {
          continue;
        }
        if (text2.indexOf("\0") !== -1) continue;
        const lines = text2.split("\n");
        for (let i = 0; i < lines.length && results.length < 200; i++) {
          const idx = lines[i].toLowerCase().indexOf(needle);
          if (idx === -1) continue;
          results.push({ path: rp, line: i + 1, text: lines[i].trim().slice(0, 200), kind: "match" });
        }
      }
    };
    await walk(dir, "", 0);
    return c.json({ results, truncated: results.length >= 200 });
  });
  r.post("/ide/exec", async (c) => {
    let body;
    try {
      body = await c.req.json();
    } catch {
      return c.json({ error: "Invalid JSON body." }, 400);
    }
    const dir = projectDir(body.project ?? "");
    const command = (body.command ?? "").trim();
    if (!dir || !existsSync5(dir)) return c.json({ error: "Project not found." }, 404);
    if (!command || command.length > 2e3) return c.json({ error: "Empty or oversized command." }, 400);
    const denied = DENY.find((re) => re.test(command));
    if (denied) return c.json({ blocked: true, reason: "This command matches a hard safety rule and can never run from Research Engine." }, 200);
    const guarded = NEEDS_CONFIRM.find((re) => re.test(command));
    if (guarded && !body.confirmed) return c.json({ requiresConfirm: true, reason: "This command modifies files, installs packages, or touches git history. Review and approve it." }, 200);
    const timeout = Math.min(body.timeoutMs ?? EXEC_TIMEOUT_MS, EXEC_TIMEOUT_MS);
    const t0 = Date.now();
    const out = await new Promise((res) => {
      const child = spawn("/bin/sh", ["-c", command], { cwd: dir, env: scrubbedEnv(), timeout });
      let stdout = "", stderr = "", timedOut = false;
      const to = setTimeout(() => {
        timedOut = true;
        child.kill("SIGKILL");
      }, timeout);
      child.stdout.on("data", (d) => {
        if (stdout.length < OUTPUT_CAP) stdout += d.toString();
      });
      child.stderr.on("data", (d) => {
        if (stderr.length < OUTPUT_CAP) stderr += d.toString();
      });
      child.on("close", (code) => {
        clearTimeout(to);
        res({ exit: code, stdout, stderr, timedOut });
      });
      child.on("error", (e) => {
        clearTimeout(to);
        res({ exit: -1, stdout, stderr: String(e), timedOut });
      });
    });
    console.log(`[re] ide exec [${body.project}] exit=${out.exit} ${command.slice(0, 100)}`);
    return c.json({ ...out, ms: Date.now() - t0, stdout: out.stdout.slice(0, OUTPUT_CAP), stderr: out.stderr.slice(0, OUTPUT_CAP), truncated: out.stdout.length >= OUTPUT_CAP || out.stderr.length >= OUTPUT_CAP });
  });
  r.get("/ide/git", async (c) => {
    const dir = projectDir(c.req.query("project") ?? "");
    if (!dir || !existsSync5(dir)) return c.json({ error: "Project not found." }, 404);
    const ALLOWED = {
      status: ["status", "--porcelain=v1", "-b"],
      log: ["log", "--oneline", "-30"],
      diff: ["diff", "--stat"],
      branches: ["branch", "-a"],
      remote: ["remote", "-v"]
    };
    const op = c.req.query("op") ?? "status";
    const args2 = ALLOWED[op];
    if (!args2) return c.json({ error: "Unknown git op." }, 400);
    if (!existsSync5(join7(dir, ".git"))) return c.json({ norepo: true });
    const res = spawnSync("git", args2, { cwd: dir, env: scrubbedEnv(), timeout: 15e3, maxBuffer: 2 * 1024 * 1024 });
    return c.json({ exit: res.status, stdout: (res.stdout ?? "").toString().slice(0, OUTPUT_CAP), stderr: (res.stderr ?? "").toString().slice(0, 4e3) });
  });
  r.post("/ide/git", async (c) => {
    let body;
    try {
      body = await c.req.json();
    } catch {
      return c.json({ error: "Invalid JSON body." }, 400);
    }
    const dir = projectDir(body.project ?? "");
    if (!dir || !existsSync5(dir)) return c.json({ error: "Project not found." }, 404);
    const run = (args2) => {
      const res = spawnSync("git", args2, { cwd: dir, env: scrubbedEnv(), timeout: 15e3, maxBuffer: 2 * 1024 * 1024 });
      return { exit: res.status, stdout: (res.stdout ?? "").toString().slice(0, OUTPUT_CAP), stderr: (res.stderr ?? "").toString().slice(0, 4e3) };
    };
    if (body.op === "init") return c.json(run(["init"]));
    if (!existsSync5(join7(dir, ".git"))) return c.json({ error: "Not a git repository." }, 400);
    if (body.op === "add") return c.json(run(["add", "-A"]));
    if (body.op === "commit") {
      const msg = (body.message ?? "").trim().slice(0, 500);
      if (!msg) return c.json({ error: "Commit message required." }, 400);
      if (!body.confirmed) return c.json({ requiresConfirm: true, reason: "Commit staged changes to local git history." });
      run(["add", "-A"]);
      const res = spawnSync("git", [
        "-c",
        "user.name=Research Engine",
        "-c",
        "user.email=research-engine@local",
        "commit",
        "-m",
        msg
      ], { cwd: dir, env: scrubbedEnv(), timeout: 15e3, maxBuffer: 2 * 1024 * 1024 });
      return c.json({ exit: res.status, stdout: (res.stdout ?? "").toString().slice(0, OUTPUT_CAP), stderr: (res.stderr ?? "").toString().slice(0, 4e3) });
    }
    return c.json({ error: "Unknown git op." }, 400);
  });
  return r;
}
var EXEC_TIMEOUT_MS, OUTPUT_CAP, IMPORT_CAP, DENY, NEEDS_CONFIRM;
var init_ide = __esm({
  "src/routes/ide.ts"() {
    "use strict";
    init_paths();
    EXEC_TIMEOUT_MS = 6e4;
    OUTPUT_CAP = 2e5;
    IMPORT_CAP = 24 * 1024 * 1024;
    DENY = [
      /\brm\s+(-[a-z]*\s+)*(-[a-z]*\s+)*\/(\s|$)/,
      // rm -rf /
      /\brm\s+-[a-z]*r[a-z]*\s+~\/?\s*($|;|&|\|)/,
      // rm -rf ~
      /\bsudo\b/,
      /\bsu\s+-/,
      /doas\b/,
      /\bmkfs\b/,
      /\bdd\s+if=/,
      /\bfdisk\b/,
      /\bparted\b/,
      /:\(\)\s*\{\s*:\|:&\s*\}\s*;\s*:/,
      // fork bomb
      /\bshutdown\b/,
      /\breboot\b/,
      /\bhalt\b/,
      /\bpoweroff\b/,
      /\binit\s+0/,
      /\bchmod\s+(-R\s+)?777\s+\//,
      /\bchown\s+-R\s+[^\s]+\s+\//,
      /\/dev\/(sd[a-z]|nvme|disk)/,
      /\b(curl|wget)\b[^\n|]*\|\s*(sudo\s+)?(ba)?sh/,
      // pipe-to-shell
      /\beval\s+.*\b(curl|wget)\b/,
      /\bbase64\s+(-d|--decode)[^\n]*\|\s*(ba)?sh/,
      /\bcrontab\b/,
      /\bat\s+-f/,
      /\bsystemctl\b/,
      /\blaunchctl\b/,
      /\bkill\s+(-9\s+)?1\b/,
      /\bkillall\b/,
      /\bnpm\s+publish\b/,
      /\bcargo\s+publish\b/,
      /\btwine\s+upload\b/,
      /\bgit\s+push\s+(--force\b|.*--force\b|-f\b)/,
      /\biptables\b/,
      /\bufw\b/,
      /\bifconfig\b.*\bdown\b/,
      /\broute\s+(del|add)/,
      /\buseradd\b/,
      /\buserdel\b/,
      /\bpasswd\b/,
      /\bvisudo\b/,
      /\bformat\s+[a-z]:/i,
      /\bdel\s+\/[sfq]+\s+[a-z]:\\/i,
      /\brmdir\s+\/s/i,
      /\breg\s+(delete|add)\b/i,
      /\bnet\s+user\b/i,
      />~?\/(etc|usr|bin|boot|proc|sys)\//,
      /\bssh\b.*-[iLDR]\b/,
      /\bscp\b/,
      /\brsync\b/,
      /\bnc\b.*-[elp]/,
      /\bnetcat\b/,
      /\btelnetd\b/,
      /\bminer\b/i,
      /xmrig/i
    ];
    NEEDS_CONFIRM = [
      /\brm\b/,
      /\bmv\b/,
      /\bgit\s+(push|reset|clean|checkout\s+--|restore)\b/,
      /\b(npm|yarn|pnpm|bun)\s+(install|add|remove|update|run\s+build)\b/,
      /\bpip3?\s+install\b/,
      /\bdocker\b/,
      /\bkubectl\b/,
      /\bgit\s+commit\b/,
      /\bmkdir\b/,
      /\btouch\b/,
      /\bchmod\b/,
      /\bnpx\b/,
      /\bmake\b/
    ];
  }
});

// src/preview/bridge.ts
var BRIDGE_JS;
var init_bridge = __esm({
  "src/preview/bridge.ts"() {
    "use strict";
    BRIDGE_JS = String.raw`
(function () {
  if (window.__RE_DESIGN_BRIDGE__) return;
  window.__RE_DESIGN_BRIDGE__ = true;

  var HOST_SOURCE = 're-design-host';
  var BRIDGE_SOURCE = 're-design-bridge';
  var uidSeq = 0;
  var uidMap = new WeakMap();
  var consoleLog = [];
  var networkLog = [];
  var navCount = 0;
  var pickMode = false;
  var overlay = null;
  var lastError = null;
  // Shared secret handed over in the iframe URL hash, so only the IDE that
  // embedded this frame can drive it (and fake results are ignored).
  var TOKEN = (function () {
    try { var m = /re-token=([A-Za-z0-9_-]{4,40})/.exec(location.hash || ''); return m ? m[1] : ''; } catch (e) { return ''; }
  })();

  /* ---------------- console + error capture ---------------- */
  function record(level, args) {
    try {
      var parts = [];
      for (var i = 0; i < args.length; i++) {
        var a = args[i];
        if (a instanceof Error) parts.push(a.stack || a.message || String(a));
        else if (typeof a === 'object') { try { parts.push(JSON.stringify(a)); } catch (e) { parts.push(String(a)); } }
        else parts.push(String(a));
      }
      var text = parts.join(' ').slice(0, 900);
      if (level === 'error' || level === 'warn' || consoleLog.length < 400) {
        consoleLog.push({ level: level, text: text, at: Date.now(), count: 1 });
        if (consoleLog.length > 500) consoleLog.shift();
      }
    } catch (e) { /* never break the app */ }
  }
  var origError = console.error, origWarn = console.warn, origLog = console.log, origInfo = console.info;
  console.error = function () { record('error', arguments); origError.apply(console, arguments); };
  console.warn = function () { record('warn', arguments); origWarn.apply(console, arguments); };
  console.log = function () { record('log', arguments); origLog.apply(console, arguments); };
  console.info = function () { record('info', arguments); origInfo.apply(console, arguments); };
  window.addEventListener('error', function (e) {
    lastError = (e && e.message ? e.message : 'error') + (e && e.filename ? ' @ ' + String(e.filename).split('/').pop() + ':' + e.lineno : '');
    record('error', [lastError]);
  });
  window.addEventListener('unhandledrejection', function (e) {
    var r = e && e.reason;
    lastError = 'Unhandled promise rejection: ' + (r && r.message ? r.message : String(r));
    record('error', [lastError]);
  });
  try {
    var origFetch = window.fetch;
    if (origFetch) {
      window.fetch = function () {
        var url = String((arguments[0] && arguments[0].url) || arguments[0] || '');
        var t0 = Date.now();
        return origFetch.apply(this, arguments).then(function (res) {
          if (!res.ok) {
            networkLog.push({ url: url.slice(0, 300), status: res.status, ms: Date.now() - t0 });
            if (networkLog.length > 100) networkLog.shift();
          }
          return res;
        }, function (err) {
          networkLog.push({ url: url.slice(0, 300), status: 0, error: String(err && err.message || err), ms: Date.now() - t0 });
          return Promise.reject(err);
        });
      };
    }
  } catch (e) { /* ignore */ }

  /* ---------------- element identity + selectors ---------------- */
  function uid(el) {
    if (!el || el.nodeType !== 1) return null;
    var u = uidMap.get(el);
    if (!u) { u = 'e' + (++uidSeq); uidMap.set(el, u); try { el.setAttribute('data-re-uid', u); } catch (e) {} }
    return u;
  }
  function cssPath(el) {
    if (!el || el.nodeType !== 1) return '';
    if (el.id) return '#' + el.id;
    var parts = [];
    var node = el;
    while (node && node.nodeType === 1 && parts.length < 6) {
      var sel = node.tagName.toLowerCase();
      if (node.id) { parts.unshift('#' + node.id); break; }
      var cls = (node.getAttribute('class') || '').trim().split(/\s+/).filter(function (c) { return c && c.length < 30; }).slice(0, 2);
      if (cls.length) sel += '.' + cls.join('.');
      var parent = node.parentElement;
      if (parent) {
        var same = 0, idx = 1, kids = parent.children;
        for (var i = 0; i < kids.length; i++) {
          if (kids[i].tagName === node.tagName) { same++; if (kids[i] === node) idx = same; }
        }
        if (same > 1) sel += ':nth-of-type(' + idx + ')';
      }
      parts.unshift(sel);
      if (node.parentElement && node.parentElement.id) { parts.unshift('#' + node.parentElement.id); break; }
      node = node.parentElement;
    }
    return parts.join(' > ');
  }
  function resolve(target) {
    if (!target) return null;
    var s = String(target);
    if (/^e\d+$/.test(s)) {
      var found = document.querySelector('[data-re-uid="' + s + '"]');
      if (found) return found;
    }
    try { return document.querySelector(s); } catch (e) { return null; }
  }
  function isVisible(el) {
    if (!el || !el.getBoundingClientRect) return false;
    var r = el.getBoundingClientRect();
    if (r.width <= 0 || r.height <= 0) return false;
    var cs = getComputedStyle(el);
    if (cs.display === 'none' || cs.visibility === 'hidden' || Number(cs.opacity) === 0) return false;
    return true;
  }
  /** Visible text of an element. jsdom (and any engine without layout) leaves
   *  innerText empty, so textContent is the reliable fallback. */
  function textOf(el) {
    if (!el) return '';
    var t = el.innerText;
    if (!t) t = el.textContent || '';
    return String(t).replace(/\s+/g, ' ').trim();
  }
  function rectOf(el) {
    var r = el.getBoundingClientRect();
    return { x: Math.round(r.x), y: Math.round(r.y), w: Math.round(r.width), h: Math.round(r.height) };
  }
  function accessibleName(el) {
    var t = el.getAttribute && (el.getAttribute('aria-label') || '');
    if (t) return t.trim();
    if (el.tagName === 'INPUT' || el.tagName === 'SELECT' || el.tagName === 'TEXTAREA') {
      if (el.id) {
        var lab = document.querySelector('label[for="' + el.id.replace(/"/g, '') + '"]');
        if (lab && lab.textContent) return lab.textContent.trim().slice(0, 80);
      }
      var wrapLab = el.closest && el.closest('label');
      if (wrapLab && wrapLab.textContent) return wrapLab.textContent.trim().slice(0, 80);
      return el.getAttribute('placeholder') || el.getAttribute('name') || el.getAttribute('title') || '';
    }
    if (el.tagName === 'IMG') return el.getAttribute('alt') || '(no alt)';
    var txt = (el.innerText || el.textContent || '').replace(/\s+/g, ' ').trim();
    return txt.slice(0, 80);
  }
  function roleOf(el) {
    if (el.getAttribute && el.getAttribute('role')) return el.getAttribute('role');
    var t = el.tagName;
    if (t === 'A') return el.getAttribute('href') ? 'link' : 'generic';
    if (t === 'BUTTON') return 'button';
    if (t === 'INPUT') return el.type === 'submit' ? 'button' : (el.type || 'textbox');
    if (t === 'SELECT') return 'combobox';
    if (t === 'TEXTAREA') return 'textbox';
    if (/^H[1-6]$/.test(t)) return 'heading';
    if (t === 'IMG') return 'img';
    if (t === 'NAV') return 'navigation';
    if (t === 'MAIN') return 'main';
    if (t === 'HEADER') return 'banner';
    if (t === 'FOOTER') return 'contentinfo';
    if (t === 'FORM') return 'form';
    return 'generic';
  }
  function styleOf(el, props) {
    var cs = getComputedStyle(el);
    var out = {};
    for (var i = 0; i < props.length; i++) out[props[i]] = cs.getPropertyValue(props[i]);
    return out;
  }
  var STYLE_KEYS = ['display', 'position', 'width', 'height', 'font-size', 'font-weight', 'font-family',
    'line-height', 'color', 'background-color', 'border-radius', 'padding', 'margin', 'gap', 'flex-direction',
    'align-items', 'justify-content', 'overflow', 'z-index', 'text-align', 'box-shadow', 'border-width', 'border-color'];

  function parseColor(c) {
    var m = String(c).match(/rgba?\(([^)]+)\)/);
    if (!m) return null;
    var p = m[1].split(',').map(function (v) { return parseFloat(v); });
    return { r: p[0], g: p[1], b: p[2], a: p.length > 3 ? p[3] : 1 };
  }
  function lum(c) {
    if (!c) return null;
    var f = function (v) { v = v / 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); };
    return 0.2126 * f(c.r) + 0.7152 * f(c.g) + 0.0722 * f(c.b);
  }
  function effectiveBg(el) {
    var node = el;
    while (node && node.nodeType === 1) {
      var cs = getComputedStyle(node);
      var bg = parseColor(cs.backgroundColor);
      if (bg && bg.a > 0.35) return bg;
      node = node.parentElement;
    }
    return { r: 255, g: 255, b: 255, a: 1 };
  }
  function contrastOf(el) {
    var fg = parseColor(getComputedStyle(el).color);
    if (!fg) return null;
    if (!textOf(el)) return null;
    var bg = effectiveBg(el);
    var l1 = lum(fg), l2 = lum(bg);
    if (l1 == null || l2 == null) return null;
    var ratio = (Math.max(l1, l2) + 0.05) / (Math.min(l1, l2) + 0.05);
    return { ratio: Math.round(ratio * 100) / 100, fg: getComputedStyle(el).color, bg: 'rgb(' + bg.r + ',' + bg.g + ',' + bg.b + ')', passAA: ratio >= 4.5, passLargeAA: ratio >= 3 };
  }

  /* ---------------- page snapshot ---------------- */
  var KEY_SELECTOR = 'h1,h2,h3,h4,a[href],button,input,select,textarea,[role],[aria-label],img,form,main,header,footer,nav,aside,section,table,[data-testid],video,canvas,svg[width]';
  function snapshot(opts) {
    opts = opts || {};
    var maxNodes = opts.maxNodes || 140;
    var nodes = [];
    var all = document.querySelectorAll(KEY_SELECTOR);
    var vp = { w: window.innerWidth, h: window.innerHeight };
    for (var i = 0; i < all.length && nodes.length < maxNodes; i++) {
      var el = all[i];
      if (!isVisible(el)) continue;
      var r = rectOf(el);
      if (r.y > vp.h * 4) continue; // far below the fold — noise for a first pass
      var cs = getComputedStyle(el);
      var txt = textOf(el);
      nodes.push({
        uid: uid(el),
        sel: cssPath(el),
        tag: el.tagName.toLowerCase(),
        role: roleOf(el),
        name: accessibleName(el).slice(0, 90),
        text: roleOf(el) === 'generic' ? undefined : txt.slice(0, 110) || undefined,
        rect: r,
        aboveFold: r.y + r.h > 0 && r.y < vp.h,
        style: {
          fs: cs.fontSize, fw: cs.fontWeight, color: cs.color, bg: cs.backgroundColor,
          pad: cs.padding, gap: cs.gap, radius: cs.borderRadius, display: cs.display
        },
        flags: flagsFor(el, cs, r, vp)
      });
    }
    var headings = [];
    var hs = document.querySelectorAll('h1,h2,h3,h4,h5,h6');
    for (var h = 0; h < hs.length && h < 30; h++) {
      if (isVisible(hs[h])) headings.push({ tag: hs[h].tagName.toLowerCase(), text: textOf(hs[h]).slice(0, 90) });
    }
    return {
      url: location.href,
      title: document.title,
      viewport: vp,
      scroll: { x: Math.round(window.scrollX), y: Math.round(window.scrollY), height: document.documentElement.scrollHeight },
      headings: headings,
      counts: {
        interactive: document.querySelectorAll('button,a[href],input,select,textarea,[role="button"]').length,
        nodes: document.getElementsByTagName('*').length,
        images: document.images.length
      },
      elements: nodes,
      findings: audit(),
      console: consoleTail(12),
      network: networkLog.slice(-8)
    };
  }

  function flagsFor(el, cs, r, vp) {
    var flags = [];
    if (el.scrollWidth > el.clientWidth + 2 && (cs.overflow === 'hidden' || cs.textOverflow === 'ellipsis')) flags.push('text-clipped');
    if (r.w > vp.w + 1) flags.push('overflows-viewport');
    if (r.x < -1) flags.push('off-screen-left');
    if (parseFloat(cs.fontSize) < 12) flags.push('tiny-text(' + cs.fontSize + ')');
    if ((el.tagName === 'BUTTON' || el.tagName === 'A') && (r.h < 32 || r.w < 24)) flags.push('small-target(' + r.w + 'x' + r.h + ')');
    var c = contrastOf(el);
    if (c && !c.passLargeAA && textOf(el)) flags.push('low-contrast(' + c.ratio + ':1)');
    if (/^\s*0px$/.test(cs.borderRadius) === false && r.w > 0 && r.h > 0 && textOf(el) && cs.backgroundColor === 'rgba(0, 0, 0, 0)' && (el.tagName === 'DIV' || el.tagName === 'SECTION')) flags.push('transparent-text-container');
    if (el.tagName === 'IMG' && !el.getAttribute('alt')) flags.push('img-no-alt');
    if (el.tagName === 'INPUT' && !accessibleName(el)) flags.push('input-no-label');
    if (el.tagName === 'A' && el.getAttribute('href') === '#') flags.push('dead-link-href-#');
    return flags;
  }

  /** Cheap static audit across the whole document (not just the fold). */
  function audit() {
    var out = [];
    var push = function (kind, msg, sel) { if (out.length < 40) out.push({ kind: kind, msg: msg, sel: sel }); };
    var dk = document.documentElement;
    if (dk.scrollWidth > window.innerWidth + 2) push('layout', 'Document is horizontally scrollable (' + dk.scrollWidth + 'px content in ' + window.innerWidth + 'px viewport)', 'html');
    var hs = document.querySelectorAll('h1,h2,h3,h4,h5,h6');
    var prev = 0;
    for (var i = 0; i < hs.length; i++) {
      var lvl = Number(hs[i].tagName[1]);
      if (prev && lvl > prev + 1) push('a11y', 'Heading level jumps from h' + prev + ' to h' + lvl + ': "' + textOf(hs[i]).slice(0, 50) + '"', cssPath(hs[i]));
      prev = lvl;
    }
    if (!document.querySelector('h1')) push('a11y', 'Page has no h1 heading', 'body');
    if (!document.querySelector('main,[role="main"]')) push('a11y', 'No <main> landmark', 'body');
    var imgs = document.images;
    for (var j = 0; j < imgs.length && j < 60; j++) {
      if (!imgs[j].getAttribute('alt')) push('a11y', 'Image without alt text', cssPath(imgs[j]));
      if (imgs[j].naturalWidth === 0 && imgs[j].complete) push('assets', 'Broken image: ' + (imgs[j].currentSrc || imgs[j].src || '').slice(-60), cssPath(imgs[j]));
    }
    var ctrls = document.querySelectorAll('button,a[href],input,select,textarea,[role="button"]');
    var noName = 0;
    for (var k = 0; k < ctrls.length; k++) {
      if (!accessibleName(ctrls[k]) && isVisible(ctrls[k])) { noName++; if (noName <= 5) push('a11y', 'Interactive element has no accessible name (' + ctrls[k].tagName.toLowerCase() + ')', cssPath(ctrls[k])); }
    }
    var small = 0;
    for (var m = 0; m < ctrls.length; m++) {
      if (!isVisible(ctrls[m])) continue;
      var rr = ctrls[m].getBoundingClientRect();
      if (rr.height < 32 || rr.width < 24) small++;
    }
    if (small) push('touch', small + ' interactive element(s) smaller than 32px tall — hard to tap on mobile');
    for (var n = 0; n < ctrls.length && n < 200; n++) {
      if (ctrls[n].tagName === 'A' && ctrls[n].getAttribute('href') === '#') push('ux', 'Anchor with href="#" does nothing', cssPath(ctrls[n]));
      if (ctrls[n].tagName === 'IMG' && !ctrls[n].hasAttribute('width') && !ctrls[n].style.width) push('layout', 'Image without intrinsic size — can cause layout shift', cssPath(ctrls[n]));
    }
    var empties = document.querySelectorAll('div,section,article');
    var emptyCount = 0;
    for (var p = 0; p < empties.length && p < 400; p++) {
      var e = empties[p];
      if (e.children.length === 0 && !(e.textContent || '').trim() && isVisible(e)) {
        var er = e.getBoundingClientRect();
        if (er.width > 40 && er.height > 40) { emptyCount++; if (emptyCount <= 3) push('layout', 'Large empty block ' + Math.round(er.width) + 'x' + Math.round(er.height) + 'px (may be an unloaded/broken section)', cssPath(e)); }
      }
    }
    if (lastError) push('console', 'Runtime error captured: ' + lastError, '');
    var errors = consoleLog.filter(function (l) { return l.level === 'error'; });
    if (errors.length) push('console', errors.length + ' console error(s); first: ' + errors[0].text.slice(0, 160), '');
    for (var q = 0; q < networkLog.length && q < 5; q++) push('network', 'Request failed: ' + networkLog[q].status + ' ' + networkLog[q].url.slice(0, 90), '');
    return out;
  }

  /* ---------------- inspect ---------------- */
  function describe(el) {
    var cs = getComputedStyle(el);
    var r = el.getBoundingClientRect();
    var parents = [];
    var p = el.parentElement;
    while (p && parents.length < 4) { parents.push({ sel: cssPath(p), rect: rectOf(p), display: getComputedStyle(p).display }); p = p.parentElement; }
    var siblings = [];
    if (el.parentElement) {
      var kids = el.parentElement.children;
      for (var i = 0; i < kids.length && siblings.length < 8; i++) {
        if (kids[i] !== el) siblings.push({ sel: cssPath(kids[i]), rect: rectOf(kids[i]), tag: kids[i].tagName.toLowerCase() });
      }
    }
    return {
      uid: uid(el),
      sel: cssPath(el),
      tag: el.tagName.toLowerCase(),
      role: roleOf(el),
      name: accessibleName(el),
      text: textOf(el).slice(0, 400),
      rect: rectOf(el),
      box: {
        margin: cs.margin, padding: cs.padding, border: cs.borderWidth,
        contentBox: { w: el.clientWidth, h: el.clientHeight }, scroll: { w: el.scrollWidth, h: el.scrollHeight }
      },
      styles: styleOf(el, STYLE_KEYS),
      contrast: contrastOf(el),
      flags: flagsFor(el, cs, { x: r.x, y: r.y, w: r.width, h: r.height }, { w: window.innerWidth, h: window.innerHeight }),
      parents: parents,
      siblings: siblings,
      attributes: (function () {
        var a = {};
        for (var i = 0; i < el.attributes.length && i < 25; i++) {
          var at = el.attributes[i];
          if (at.name === 'style' && at.value.length > 400) a.style = at.value.slice(0, 400) + '…';
          else a[at.name] = String(at.value).slice(0, 200);
        }
        return a;
      })(),
      path: (function () {
        var chain = [], node = el;
        while (node && node.tagName && chain.length < 8) {
          chain.unshift(node.tagName.toLowerCase() + (node.id ? '#' + node.id : '') + (node.className && typeof node.className === 'string' ? '.' + node.className.trim().split(/\s+/).slice(0, 2).join('.') : ''));
          node = node.parentElement;
        }
        return chain.join(' > ');
      })()
    };
  }

  /* ---------------- interactions ---------------- */
  function fire(el, type, init) {
    try { el.dispatchEvent(new MouseEvent(type, Object.assign({ bubbles: true, cancelable: true, view: window }, init || {}))); } catch (e) {}
  }
  function clickTarget(el) {
    if (!el) return { ok: false, error: 'element not found' };
    try { if (el.scrollIntoView) el.scrollIntoView({ block: 'center', inline: 'center' }); } catch (e) {}
    var r = rectOf(el);
    var before = { url: location.href, nodes: document.getElementsByTagName('*').length };
    highlight(el, true);
    fire(el, 'mouseover'); fire(el, 'mousedown'); fire(el, 'mouseup'); fire(el, 'click');
    try { if (typeof el.click === 'function') el.click(); } catch (e) {}
    return { ok: true, before: before, rect: r, tag: el.tagName.toLowerCase(), name: accessibleName(el).slice(0, 80) };
  }
  function typeInto(el, text, submit) {
    if (!el) return { ok: false, error: 'element not found' };
    try { if (el.scrollIntoView) el.scrollIntoView({ block: 'center' }); el.focus(); } catch (e) {}
    var proto = el.tagName === 'TEXTAREA' ? window.HTMLTextAreaElement.prototype : window.HTMLInputElement.prototype;
    var setter = Object.getOwnPropertyDescriptor(proto || {}, 'value');
    if (setter && setter.set) setter.set.call(el, text); else el.value = text;
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    if (submit) {
      var form = el.form;
      fire(el, 'keydown', { key: 'Enter', keyCode: 13 });
      fire(el, 'keypress', { key: 'Enter', keyCode: 13 });
      fire(el, 'keyup', { key: 'Enter', keyCode: 13 });
      if (form && el.type !== 'textarea') { try { form.requestSubmit ? form.requestSubmit() : form.submit(); } catch (e) {} }
    }
    return { ok: true, value: el.value, tag: el.tagName.toLowerCase(), name: accessibleName(el).slice(0, 80) };
  }

  function checkOne(c) {
    var el = resolve(c.target || c.selector);
    var res = { check: c.kind, target: c.target || c.selector, pass: false };
    // Whole-page checks come first — they need no element and must not be
    // short-circuited by the "element not found" guard below.
    if (c.kind === 'count') {
      var list = []; try { list = document.querySelectorAll(c.selector || c.target); } catch (e) {}
      res.pass = list.length === Number(c.expect);
      res.detail = list.length + ' element(s) matched (expected ' + c.expect + ')';
      return res;
    }
    if (c.kind === 'noConsoleErrors') {
      var errs = consoleLog.filter(function (l) { return l.level === 'error'; });
      res.pass = errs.length === 0;
      res.detail = errs.length ? errs.length + ' console error(s): ' + errs[0].text.slice(0, 120) : 'no console errors';
      return res;
    }
    if (c.kind === 'noHorizontalScroll') {
      res.pass = document.documentElement.scrollWidth <= window.innerWidth + 2;
      res.detail = document.documentElement.scrollWidth + 'px content vs ' + window.innerWidth + 'px viewport';
      return res;
    }
    if (c.kind === 'exists') { res.pass = !!el; res.detail = el ? 'found ' + cssPath(el) : 'not found'; return res; }
    if (!el) { res.detail = 'element not found: ' + (c.target || c.selector); return res; }
    if (c.kind === 'visible') { res.pass = isVisible(el); res.detail = res.pass ? 'visible' : 'hidden or zero-size'; return res; }
    if (c.kind === 'text') {
      var have = (el.innerText || el.textContent || '').replace(/\s+/g, ' ').trim();
      var want = String(c.expect || '');
      res.pass = c.mode === 'equals' ? have === want : have.toLowerCase().indexOf(want.toLowerCase()) !== -1;
      res.detail = JSON.stringify(have.slice(0, 160)) + (res.pass ? ' contains ' : ' does NOT contain ') + JSON.stringify(want);
      return res;
    }
    if (c.kind === 'value') { res.pass = String(el.value || '') === String(c.expect || ''); res.detail = 'value is ' + JSON.stringify(String(el.value || '').slice(0, 80)); return res; }
    if (c.kind === 'style') {
      var got = getComputedStyle(el).getPropertyValue(c.prop);
      res.pass = String(got).trim() === String(c.expect).trim();
      res.detail = c.prop + ' = ' + got + ' (expected ' + c.expect + ')';
      return res;
    }
    if (c.kind === 'contrast') {
      var cc = contrastOf(el);
      res.pass = !!(cc && cc.ratio >= (Number(c.expect) || 4.5));
      res.detail = cc ? cc.ratio + ':1' : 'unknown';
      return res;
    }
    if (c.kind === 'rect') {
      var rr = rectOf(el);
      res.pass = (!c.minWidth || rr.w >= c.minWidth) && (!c.minHeight || rr.h >= c.minHeight) && (!c.maxWidth || rr.w <= c.maxWidth);
      res.detail = 'rect ' + rr.w + 'x' + rr.h;
      return res;
    }
    res.detail = 'unknown check kind: ' + c.kind;
    return res;
  }

  /* ---------------- overlay highlighting ---------------- */
  function ensureOverlay() {
    if (overlay && overlay.parentNode) return overlay;
    overlay = document.createElement('div');
    overlay.setAttribute('data-re-overlay', '1');
    overlay.style.cssText = 'position:fixed;z-index:2147483647;pointer-events:none;border:2px solid #3ddc84;background:rgba(61,220,132,0.14);border-radius:4px;transition:all .12s ease;top:0;left:0;width:0;height:0;' +
      'font:600 10px/1.2 system-ui,sans-serif;color:#05170e;box-shadow:0 6px 24px rgba(0,0,0,.35)';
    overlay.innerHTML = '<span style="position:absolute;top:-18px;left:0;background:#3ddc84;color:#05170e;padding:1px 5px;border-radius:4px;white-space:nowrap"></span>';
    (document.body || document.documentElement).appendChild(overlay);
    return overlay;
  }
  function highlight(el, keep) {
    var o = ensureOverlay();
    if (!el) { o.style.width = '0px'; o.style.height = '0px'; return { ok: true }; }
    var r = el.getBoundingClientRect();
    o.style.top = r.top + 'px'; o.style.left = r.left + 'px';
    o.style.width = r.width + 'px'; o.style.height = r.height + 'px';
    o.firstChild.textContent = el.tagName.toLowerCase() + ' · ' + Math.round(r.width) + '×' + Math.round(r.height) + (accessibleName(el) ? ' · ' + accessibleName(el).slice(0, 40) : '');
    if (!keep) setTimeout(function () { if (overlay) { overlay.style.width = '0px'; overlay.style.height = '0px'; } }, 1400);
    return { ok: true, rect: rectOf(el) };
  }
  window.addEventListener('scroll', function () { if (overlay) { overlay.style.width = '0px'; overlay.style.height = '0px'; } }, true);

  /* ---------------- element picker ---------------- */
  var pickHandler = null, pickHover = null;
  function setPick(on) {
    pickMode = !!on;
    if (pickHandler) { document.removeEventListener('mousemove', pickHover, true); document.removeEventListener('click', pickHandler, true); pickHandler = null; }
    if (!pickMode) return { ok: true, picking: false };
    pickHover = function (e) { if (e.target && e.target.getAttribute && e.target.getAttribute('data-re-overlay')) return; highlight(e.target, true); };
    pickHandler = function (e) {
      e.preventDefault(); e.stopPropagation();
      var el = e.target;
      setPick(false);
      highlight(el, false);
      send('picked', describe(el));
    };
    document.addEventListener('mousemove', pickHover, true);
    document.addEventListener('click', pickHandler, true);
    return { ok: true, picking: true };
  }

  /* ---------------- screenshot (DOM → SVG → canvas) ---------------- */
  var SCREENSHOT_PROPS = ['display', 'position', 'top', 'left', 'right', 'bottom', 'width', 'height', 'min-width', 'min-height',
    'max-width', 'max-height', 'margin', 'padding', 'border', 'border-width', 'border-style', 'border-color', 'border-radius',
    'background', 'background-color', 'background-image', 'background-size', 'background-position', 'background-repeat',
    'color', 'font-family', 'font-size', 'font-weight', 'font-style', 'line-height', 'letter-spacing', 'text-align',
    'text-decoration', 'text-transform', 'white-space', 'overflow', 'overflow-x', 'overflow-y', 'opacity', 'box-shadow',
    'flex-direction', 'flex-wrap', 'align-items', 'justify-content', 'gap', 'grid-template-columns', 'grid-template-rows',
    'grid-column', 'grid-row', 'transform', 'vertical-align', 'object-fit', 'list-style', 'z-index', 'visibility', 'pointer-events'];
  function inlineStyles(src, dst, depth) {
    if (depth > 22) return;
    var cs = getComputedStyle(src);
    var css = '';
    for (var i = 0; i < SCREENSHOT_PROPS.length; i++) {
      var v = cs.getPropertyValue(SCREENSHOT_PROPS[i]);
      if (!v || v === 'none' && SCREENSHOT_PROPS[i].indexOf('background') === 0) { if (SCREENSHOT_PROPS[i] === 'background-image') css += 'background-image:none;'; continue; }
      css += SCREENSHOT_PROPS[i] + ':' + v + ';';
    }
    var r = src.getBoundingClientRect();
    if (r.width > 0 && r.height > 0 && (cs.position === 'static')) css += 'box-sizing:border-box;';
    dst.setAttribute('style', css);
    if (src.tagName === 'IMG') {
      try {
        var c = document.createElement('canvas');
        c.width = src.naturalWidth || src.width; c.height = src.naturalHeight || src.height;
        c.getContext('2d').drawImage(src, 0, 0);
        dst.setAttribute('src', c.toDataURL('image/png'));
      } catch (e) { dst.setAttribute('src', src.currentSrc || src.src || ''); }
    }
    if (src.tagName === 'INPUT' || src.tagName === 'TEXTAREA') { try { dst.setAttribute('value', src.value); } catch (e) {} }
    if (src.tagName === 'CANVAS') {
      try {
        var img = document.createElement('img');
        img.setAttribute('src', src.toDataURL('image/png'));
        img.setAttribute('style', dst.getAttribute('style'));
        dst.parentNode.replaceChild(img, dst);
        return;
      } catch (e) { /* tainted canvas — skip */ }
    }
    var sc = src.children, dc = dst.children;
    for (var k = 0; k < sc.length && k < dc.length; k++) {
      if (sc[k].tagName === 'SCRIPT' || sc[k].tagName === 'NOSCRIPT' || sc[k].tagName === 'LINK') continue;
      inlineStyles(sc[k], dc[k], depth + 1);
    }
  }
  function screenshot(opts) {
    opts = opts || {};
    return new Promise(function (resolve) {
      try {
        var w = Math.max(320, window.innerWidth);
        var full = !!opts.full;
        var h = full ? Math.max(window.innerHeight, document.documentElement.scrollHeight) : window.innerHeight;
        var scale = Math.min(opts.scale || 1, 2);
        var clone = document.documentElement.cloneNode(true);
        var dead = clone.querySelectorAll('script,link[rel="preload"]');
        for (var i = 0; i < dead.length; i++) dead[i].parentNode.removeChild(dead[i]);
        var bodyClone = clone.querySelector('body') || clone;
        inlineStyles(document.body, bodyClone, 0);
        bodyClone.style.margin = '0';
        var svg = '<svg xmlns="http://www.w3.org/2000/svg" width="' + w + '" height="' + h + '" viewBox="0 0 ' + w + ' ' + h + '">' +
          '<foreignObject x="0" y="0" width="100%" height="100%">' +
          '<div xmlns="http://www.w3.org/1999/xhtml" style="width:' + w + 'px;height:' + h + 'px;overflow:hidden;background:#fff">' +
          new XMLSerializer().serializeToString(bodyClone) + '</div></foreignObject></svg>';
        var url = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg);
        var img = new Image();
        img.onload = function () {
          try {
            var canvas = document.createElement('canvas');
            canvas.width = Math.round(w * scale); canvas.height = Math.round(h * scale);
            var ctx = canvas.getContext('2d');
            ctx.fillStyle = '#ffffff'; ctx.fillRect(0, 0, canvas.width, canvas.height);
            ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
            var fmt = opts.format === 'png' ? 'image/png' : 'image/jpeg';
            resolve({ ok: true, dataUrl: canvas.toDataURL(fmt, opts.quality || 0.82), width: canvas.width, height: canvas.height, url: location.href, title: document.title });
          } catch (e) { resolve({ ok: false, error: 'canvas encode failed: ' + e.message }); }
        };
        img.onerror = function () { resolve({ ok: false, error: 'svg rasterise failed' }); };
        img.src = url;
      } catch (e) { resolve({ ok: false, error: String(e && e.message || e) }); }
    });
  }

  /* ---------------- responsive metrics ---------------- */
  function metrics() {
    var vp = { w: window.innerWidth, h: window.innerHeight };
    var overflowing = [];
    var all = document.querySelectorAll('body *');
    for (var i = 0; i < all.length && overflowing.length < 12; i++) {
      var el = all[i];
      if (!isVisible(el)) continue;
      var r = el.getBoundingClientRect();
      if (r.right > vp.w + 2 && r.width < 4000) overflowing.push({ sel: cssPath(el), right: Math.round(r.right), width: Math.round(r.width), text: (el.innerText || '').replace(/\s+/g, ' ').trim().slice(0, 50) });
    }
    var smallest = [];
    var ctrls = document.querySelectorAll('button,a[href],input,select,textarea');
    for (var j = 0; j < ctrls.length && smallest.length < 10; j++) {
      if (!isVisible(ctrls[j])) continue;
      var rr = ctrls[j].getBoundingClientRect();
      if (rr.height < 32 || rr.width < 24) smallest.push({ sel: cssPath(ctrls[j]), w: Math.round(rr.width), h: Math.round(rr.height), name: accessibleName(ctrls[j]).slice(0, 40) });
    }
    return {
      viewport: vp,
      document: { scrollWidth: document.documentElement.scrollWidth, scrollHeight: document.documentElement.scrollHeight, nodes: document.getElementsByTagName('*').length },
      horizontalOverflow: document.documentElement.scrollWidth > vp.w + 2,
      overflowingElements: overflowing,
      smallTargets: smallest,
      media: (function () {
        var m = [];
        if (!window.matchMedia) return m;
        var mq = ['(max-width:480px)', '(max-width:768px)', '(max-width:1024px)', '(min-width:1280px)'];
        for (var i = 0; i < mq.length; i++) { try { m.push({ query: mq[i], matches: window.matchMedia(mq[i]).matches }); } catch (e) {} }
        return m;
      })()
    };
  }

  function interactiveMap() {
    var sel = 'button,a[href],input,select,textarea,[role="button"],[role="tab"],[role="link"],[data-testid]';
    var out = [];
    var els = document.querySelectorAll(sel);
    for (var i = 0; i < els.length && out.length < 120; i++) {
      var el = els[i];
      if (!isVisible(el)) continue;
      var r = rectOf(el);
      var typ = el.tagName === 'INPUT' || el.tagName === 'TEXTAREA' || el.tagName === 'SELECT';
      var kind = typ ? 'input' : (el.tagName === 'A' ? 'link' : 'button');
      var name = accessibleName(el).slice(0, 70);
      if (!name && !el.getAttribute('data-testid')) continue;
      out.push({
        uid: uid(el), sel: cssPath(el), kind: kind, name: name || '(unnamed)',
        testid: el.getAttribute('data-testid') || undefined,
        rect: r, aboveFold: r.y < window.innerHeight,
        currentValue: typ ? String(el.value || '').slice(0, 60) : undefined,
        disabled: !!el.disabled,
        pressed: el.getAttribute('aria-pressed') || undefined,
        href: el.getAttribute('href') || undefined,
        type: el.getAttribute('type') || undefined
      });
    }
    return { count: out.length, controls: out };
  }

  /* ---------------- messaging ---------------- */
  function consoleTail(n) {
    var seen = {};
    var out = [];
    for (var i = consoleLog.length - 1; i >= 0 && out.length < n; i--) {
      var l = consoleLog[i];
      var key = l.level + l.text.slice(0, 60);
      if (seen[key]) { seen[key].repeat++; continue; }
      seen[key] = { level: l.level, text: l.text, at: l.at, repeat: 1 };
      out.unshift(seen[key]);
    }
    return out;
  }
  function send(type, payload, id) {
    try { window.parent.postMessage({ source: BRIDGE_SOURCE, type: type, id: id, payload: payload, token: TOKEN }, '*'); } catch (e) {}
  }
  function handle(cmd, args, id) {
    args = args || {};
    var done = function (payload) { send('result', payload, id); };
    var fail = function (msg) { send('error', { message: String(msg) }, id); };
    try {
      switch (cmd) {
        case 'ping': return done({ pong: true, url: location.href, title: document.title, viewport: { w: innerWidth, h: innerHeight }, picking: pickMode });
        case 'snapshot': return done(snapshot(args));
        case 'inspect': { var el = resolve(args.target); return el ? done(describe(el)) : fail('element not found: ' + args.target); }
        case 'query': {
          var list = [];
          try { var m = document.querySelectorAll(args.selector); for (var i = 0; i < m.length && i < 40; i++) list.push(describe(m[i])); } catch (e) { return fail('bad selector'); }
          return done({ count: list.length, matches: list });
        }
        case 'click': {
          var c = clickTarget(resolve(args.target));
          if (!c.ok) return fail(c.error);
          setTimeout(function () {
            var after = document.getElementsByTagName('*').length;
            var delta = consoleLog.slice(c.before.nodes ? -8 : -8);
            done({
              clicked: c.name || c.tag, rect: c.rect, urlBefore: c.before.url, urlAfter: location.href,
              navigated: c.before.url !== location.href,
              domDelta: after - c.before.nodes,
              console: consoleTail(6)
            });
          }, args.waitMs || 450);
          return;
        }
        case 'type': {
          var t = typeInto(resolve(args.target), String(args.text == null ? '' : args.text), !!args.submit);
          if (!t.ok) return fail(t.error);
          setTimeout(function () { done({ typed: t.value, target: t.name, urlAfter: location.href, console: consoleTail(6) }); }, args.waitMs || 400);
          return;
        }
        case 'press': {
          var focused = document.activeElement;
          var ev = { key: args.key || 'Enter', code: args.key || 'Enter', keyCode: args.key === 'Tab' ? 9 : 13, bubbles: true };
          fire(focused, 'keydown', ev); fire(focused, 'keyup', ev);
          if (args.key === 'Escape') { var d = document.querySelector('[role="dialog"],dialog'); if (d && d.close) try { d.close(); } catch (e) {} }
          return done({ ok: true, focused: focused ? cssPath(focused) : null, urlAfter: location.href });
        }
        case 'scrollTo': { var s = resolve(args.target); if (!s) return fail('element not found'); if (s.scrollIntoView) s.scrollIntoView({ block: args.block || 'center', behavior: 'auto' }); return done({ ok: true, scrollY: Math.round(window.scrollY) }); }
        case 'scrollBy': { window.scrollBy(0, args.y || 0); return done({ ok: true, scrollY: Math.round(window.scrollY) }); }
        case 'assert': {
          var checks = (args.checks || []).map(checkOne);
          return done({ passed: checks.filter(function (c) { return c.pass; }).length, total: checks.length, results: checks, allPassed: checks.every(function (c) { return c.pass; }) });
        }
        case 'highlight': { return done(highlight(args.target ? resolve(args.target) : null, !!args.keep)); }
        case 'pick': return done(setPick(args.on !== false));
        case 'console': { var tail = consoleTail(args.limit || 40); if (args.clear) { consoleLog = []; networkLog = []; } return done({ entries: tail, network: networkLog.slice(-10) }); }
        case 'metrics': return done(metrics());
        case 'controls': return done(interactiveMap());
        case 'audit': return done({ findings: audit(), viewport: { w: innerWidth, h: innerHeight }, url: location.href });
        case 'navigate': {
          var target = String(args.url || '/');
          var before = location.href;
          if (/^https?:/i.test(target)) location.href = target;
          else location.href = target.charAt(0) === '/' ? target : '/' + target;
          return done({ navigated: true, from: before, to: location.href });
        }
        case 'reload': location.reload(); return done({ reloading: true });
        case 'screenshot': screenshot(args).then(function (r) { r && r.ok ? done(r) : fail(r && r.error || 'screenshot failed'); }); return;
        case 'report': {
          return done({ snapshot: snapshot({ maxNodes: 120 }), metrics: metrics(), controls: interactiveMap(), console: consoleTail(20), network: networkLog.slice(-10) });
        }
        default: return fail('unknown command: ' + cmd);
      }
    } catch (e) { fail(e && e.message || String(e)); }
  }

  window.addEventListener('message', function (e) {
    var d = e.data;
    if (!d || d.source !== HOST_SOURCE || !d.cmd) return;
    if (TOKEN && d.token !== TOKEN) return;
    handle(d.cmd, d.args, d.id);
  });
  window.addEventListener('beforeunload', function () { navCount++; try { window.parent.postMessage({ source: BRIDGE_SOURCE, type: 'unloading', payload: { url: location.href } }, '*'); } catch (e) {} });

  // Announce readiness once the DOM exists (and again after load for late listeners).
  var announce = function () { send('ready', { url: location.href, title: document.title, viewport: { w: innerWidth, h: innerHeight }, ua: navigator.userAgent }); };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', announce);
  else announce();
  window.addEventListener('load', function () { setTimeout(announce, 150); setTimeout(function () { send('idle', { url: location.href, findings: audit().slice(0, 6), console: consoleTail(6) }); }, 1200); });
})();
`;
  }
});

// src/preview/manager.ts
var manager_exports = {};
__export(manager_exports, {
  MIME: () => MIME2,
  PreviewManager: () => PreviewManager,
  findOnPath: () => findOnPath,
  injectBridge: () => injectBridge,
  pythonBin: () => pythonBin
});
import { createServer as createServer2, request as httpRequest } from "node:http";
import { createConnection } from "node:net";
import { spawn as spawn2 } from "node:child_process";
import { existsSync as existsSync6, readFileSync as readFileSync3, statSync as statSync5, createReadStream as createReadStream2 } from "node:fs";
import { readFile as readFile3, readdir as readdir3 } from "node:fs/promises";
import { join as join8, extname as extname2, normalize as normalize2, delimiter } from "node:path";
function freePort() {
  return new Promise((resolve6, reject) => {
    const srv = createServer2();
    srv.on("error", reject);
    srv.listen(0, "0.0.0.0", () => {
      const addr = srv.address();
      const port = typeof addr === "object" && addr ? addr.port : 0;
      srv.close(() => resolve6(port));
    });
  });
}
function waitForPort(port, timeoutMs = 45e3) {
  const deadline = Date.now() + timeoutMs;
  return new Promise((resolve6) => {
    const attempt = () => {
      const sock = createConnection({ port, host: "127.0.0.1" });
      const done = (ok) => {
        sock.removeAllListeners();
        sock.destroy();
        ok ? resolve6(true) : Date.now() > deadline ? resolve6(false) : setTimeout(attempt, 350);
      };
      sock.once("connect", () => done(true));
      sock.once("error", () => done(false));
      sock.setTimeout(1500, () => done(false));
    };
    attempt();
  });
}
async function planFor(dir) {
  const has = (p) => existsSync6(join8(dir, p));
  const binPath = (name) => {
    const p = join8(dir, "node_modules", ".bin", name);
    return existsSync6(p) ? p : null;
  };
  let pkg = null;
  if (has("package.json")) {
    try {
      pkg = JSON.parse(await readFile3(join8(dir, "package.json"), "utf8"));
    } catch {
      pkg = null;
    }
  }
  const deps = { ...pkg?.dependencies ?? {}, ...pkg?.devDependencies ?? {} };
  const scripts = pkg?.scripts ?? {};
  const vite = binPath("vite");
  if (vite && (deps.vite || deps["@vitejs/plugin-react"] || scripts.dev?.includes("vite"))) {
    return { kind: "vite", command: "vite --port <p> --strictPort --host 0.0.0.0", bin: vite, args: (p) => ["--port", String(p), "--strictPort", "--host", "0.0.0.0"], needsPort: true };
  }
  const next = binPath("next");
  if (next && (deps.next || scripts.dev?.includes("next"))) {
    return { kind: "next", command: "next dev -p <p> -H 0.0.0.0", bin: next, args: (p) => ["dev", "-p", String(p), "-H", "0.0.0.0"], needsPort: true };
  }
  const astro = binPath("astro");
  if (astro && (deps.astro || scripts.dev?.includes("astro"))) {
    return { kind: "astro", command: "astro dev --port <p> --host 0.0.0.0", bin: astro, args: (p) => ["dev", "--port", String(p), "--host", "0.0.0.0"], needsPort: true };
  }
  const cra = binPath("react-scripts");
  if (cra && (deps["react-scripts"] || scripts.start?.includes("react-scripts"))) {
    return { kind: "cra", command: "react-scripts start (PORT=<p>)", bin: cra, args: () => ["start"], env: { PORT: "<p>", HOST: "0.0.0.0", BROWSER: "none", DANGEROUSLY_DISABLE_HOST_CHECK: "true" }, needsPort: true };
  }
  const python = pythonBin();
  if (has("manage.py") && python) {
    return { kind: "django", command: `${python} manage.py runserver 0.0.0.0:<p>`, bin: python, args: (p) => ["manage.py", "runserver", `0.0.0.0:${p}`, "--noreload"], needsPort: true };
  }
  if (scripts.dev && has("package.json")) {
    return { kind: "npm-dev", command: "npm run dev -- --port <p>", bin: "npm", args: (p) => ["run", "dev", "--", "--port", String(p), "--host"], env: { PORT: "<p>" }, needsPort: true };
  }
  if (scripts.start && has("package.json")) {
    return { kind: "npm-start", command: "npm run start (PORT=<p>)", bin: "npm", args: () => ["run", "start"], env: { PORT: "<p>", HOST: "0.0.0.0", BROWSER: "none" }, needsPort: true };
  }
  for (const candidate of ["index.html", "public/index.html", "dist/index.html", "build/index.html"]) {
    if (has(candidate)) {
      const folder = candidate.split("/")[0];
      const root = candidate === "index.html" ? dir : join8(dir, folder);
      return {
        kind: "static",
        command: candidate === "index.html" ? "static file server (project root)" : `static server (${folder}/)`,
        bin: "",
        args: () => [],
        static: true,
        needsPort: false,
        staticRoot: root
      };
    }
  }
  if ((has("requirements.txt") || has("pyproject.toml")) && python) {
    const entry = (await readdir3(dir)).find((f) => f === "app.py" || f === "main.py");
    if (entry) return { kind: "flask", command: `${python} ${entry}`, bin: python, args: () => [entry], env: { PORT: "<p>", FLASK_RUN_PORT: "<p>" }, needsPort: true };
  }
  return null;
}
function injectBridge(html) {
  const tag = `<script data-re-design-bridge>${BRIDGE_JS}</script>`;
  if (/<head[^>]*>/i.test(html)) return html.replace(/<head([^>]*)>/i, (m) => `${m}
${tag}`);
  if (/<html[^>]*>/i.test(html)) return html.replace(/<html([^>]*)>/i, (m) => `${m}
<head>${tag}</head>`);
  return tag + html;
}
function upstreamHeaders(headers, port) {
  const out = {};
  for (const [k, v] of Object.entries(headers)) {
    const lk = k.toLowerCase();
    if (lk === "host" || lk === "accept-encoding" || lk === "origin" || lk === "referer" || lk === "connection" || lk === "content-length") continue;
    out[k] = v;
  }
  out.host = `127.0.0.1:${port}`;
  return out;
}
function createProxy(session, upstream) {
  const server = createServer2((req, res) => {
    const url = req.url || "/";
    if (url.startsWith("/__re/bridge.js")) {
      res.writeHead(200, { "content-type": "text/javascript; charset=utf-8", "cache-control": "no-store" });
      res.end(BRIDGE_JS);
      return;
    }
    const port = upstream();
    if (!port) {
      serveStatic(session, req, res);
      return;
    }
    let up;
    try {
      up = httpRequest({ host: "127.0.0.1", port, method: req.method, path: url, headers: upstreamHeaders(req.headers, port) }, (r) => {
        const headers = { ...r.headers };
        for (const h of STRIP_HEADERS) delete headers[h];
        const ct = String(r.headers["content-type"] ?? "");
        if (ct.includes("text/html") || ct.includes("application/xhtml")) {
          const chunks = [];
          let size = 0;
          r.on("data", (c) => {
            size += c.length;
            if (size < 8e6) chunks.push(c);
          });
          r.on("end", () => {
            let html = Buffer.concat(chunks).toString("utf8");
            html = injectBridge(html);
            headers["content-type"] = "text/html; charset=utf-8";
            headers["content-length"] = Buffer.byteLength(html);
            headers["cache-control"] = "no-store";
            res.writeHead(r.statusCode ?? 200, headers);
            res.end(html);
          });
          return;
        }
        headers["cache-control"] = headers["cache-control"] ?? "no-store";
        res.writeHead(r.statusCode ?? 200, headers);
        r.pipe(res);
      });
    } catch (e) {
      res.writeHead(502, { "content-type": "text/plain" });
      res.end(`preview upstream error: ${e?.message ?? e}`);
      return;
    }
    up.on("error", (e) => {
      pushLog(session, `[proxy] upstream error: ${e?.message ?? e}`);
      if (!res.headersSent) res.writeHead(502, { "content-type": "text/html; charset=utf-8" });
      res.end(`<body style="font:14px system-ui;padding:40px;background:#111;color:#eee"><h3>Preview server is not responding</h3><p>${String(e?.message ?? e)}</p><p>Check the preview log in the IDE.</p></body>`);
    });
    req.pipe(up);
  });
  server.on("upgrade", (req, socket, head) => {
    const port = upstream();
    if (!port) {
      socket.destroy();
      return;
    }
    const up = createConnection({ host: "127.0.0.1", port }, () => {
      const raw = [`${req.method} ${req.url} HTTP/1.1`];
      const headers = { ...req.headers };
      headers.host = `127.0.0.1:${port}`;
      if (headers.origin) headers.origin = `http://127.0.0.1:${port}`;
      for (const [k, v] of Object.entries(headers)) {
        if (v === void 0) continue;
        raw.push(`${k}: ${Array.isArray(v) ? v.join(", ") : v}`);
      }
      up.write(raw.join("\r\n") + "\r\n\r\n");
      if (head?.length) up.write(head);
      socket.pipe(up);
      up.pipe(socket);
    });
    up.on("error", () => socket.destroy());
    socket.on("error", () => up.destroy());
  });
  return new Promise((resolve6, reject) => {
    server.on("error", reject);
    server.listen(session.publicPort, "0.0.0.0", () => resolve6(server));
  });
}
function findOnPath(name) {
  const dirs = (process.env.PATH ?? "").split(delimiter).filter(Boolean);
  for (const d of dirs) {
    if (process.platform !== "win32") {
      const full = join8(d, name);
      if (existsSync6(full)) return full;
    } else {
      for (const ext of PATH_EXTS) {
        const full = join8(d, name + ext);
        if (existsSync6(full)) return full;
      }
      const bare = join8(d, name);
      if (existsSync6(bare)) return bare;
    }
  }
  return null;
}
function pythonBin() {
  return findOnPath("python3") ?? findOnPath("python") ?? findOnPath("py");
}
function serveStatic(session, req, res) {
  const root = session.staticRoot;
  if (!root) {
    res.writeHead(404, { "content-type": "text/plain" });
    res.end("not found");
    return;
  }
  let rel = decodeURIComponent((req.url || "/").split("?")[0]);
  if (rel.endsWith("/")) rel += "index.html";
  const safe = normalize2(rel).replace(/^(\.\.[/\\])+/, "").replace(/^\/+/, "");
  let file = join8(root, safe);
  try {
    if (!isWithinDir(root, file)) throw new Error("escape");
    if (existsSync6(file) && statSync5(file).isDirectory()) file = join8(file, "index.html");
    if (!existsSync6(file)) {
      const index = join8(root, "index.html");
      if (existsSync6(index) && !extname2(rel)) file = index;
      else {
        res.writeHead(404, { "content-type": "text/plain" });
        res.end("404");
        return;
      }
    }
    const st = statSync5(file);
    const ext = extname2(file).toLowerCase();
    const type = MIME2[ext] ?? "application/octet-stream";
    if (type.includes("text/html")) {
      const html = injectBridge(readFileSync3(file, "utf8"));
      res.writeHead(200, { "content-type": type, "content-length": Buffer.byteLength(html), "cache-control": "no-store" });
      res.end(html);
      return;
    }
    res.writeHead(200, { "content-type": type, "content-length": st.size, "cache-control": "no-store" });
    createReadStream2(file).pipe(res);
  } catch {
    res.writeHead(404, { "content-type": "text/plain" });
    res.end("404");
  }
}
function pushLog(session, line) {
  for (const l of String(line).split("\n")) {
    const t = l.replace(/\u001b\[[0-9;]*m/g, "").trimEnd();
    if (!t) continue;
    session.logs.push(t.slice(0, 500));
  }
  if (session.logs.length > MAX_LOGS) session.logs.splice(0, session.logs.length - MAX_LOGS);
}
function sniffPort(text2) {
  const m = text2.match(/(?:localhost|127\.0\.0\.1|0\.0\.0\.0|\[::\]|:)(?::)?(\d{2,5})\b/);
  if (!m) return null;
  const p = Number(m[1]);
  return p > 0 && p < 65536 ? p : null;
}
function scrubbedEnv2() {
  const out = {};
  for (const [k, v] of Object.entries(process.env)) {
    if (/key|token|secret|passw|credential|auth/i.test(k)) continue;
    if (typeof v === "string") out[k] = v;
  }
  return out;
}
var MAX_LOGS, MIME2, STRIP_HEADERS, PATH_EXTS, PreviewManager;
var init_manager = __esm({
  "src/preview/manager.ts"() {
    "use strict";
    init_bridge();
    init_paths();
    MAX_LOGS = 400;
    MIME2 = {
      ".html": "text/html; charset=utf-8",
      ".js": "text/javascript; charset=utf-8",
      ".mjs": "text/javascript; charset=utf-8",
      ".css": "text/css; charset=utf-8",
      ".json": "application/json; charset=utf-8",
      ".svg": "image/svg+xml",
      ".png": "image/png",
      ".jpg": "image/jpeg",
      ".jpeg": "image/jpeg",
      ".gif": "image/gif",
      ".webp": "image/webp",
      ".ico": "image/x-icon",
      ".woff": "font/woff",
      ".woff2": "font/woff2",
      ".ttf": "font/ttf",
      ".mp4": "video/mp4",
      ".txt": "text/plain; charset=utf-8",
      ".map": "application/json"
    };
    STRIP_HEADERS = ["x-frame-options", "content-security-policy", "content-security-policy-report-only", "cross-origin-opener-policy", "cross-origin-embedder-policy", "content-length", "content-encoding", "transfer-encoding", "connection"];
    PATH_EXTS = process.platform === "win32" ? (process.env.PATHEXT ?? ".EXE;.CMD;.BAT;.COM").split(";").filter(Boolean) : [""];
    PreviewManager = class {
      sessions = /* @__PURE__ */ new Map();
      info(project) {
        const s = this.sessions.get(project);
        if (!s) return null;
        return {
          running: true,
          project: s.project,
          kind: s.kind,
          command: s.command,
          port: s.publicPort,
          internalPort: s.internalPort,
          url: `http://127.0.0.1:${s.publicPort}/`,
          startedAt: s.startedAt,
          ready: s.ready,
          error: s.error,
          logs: s.logs.slice(-120)
        };
      }
      list() {
        return [...this.sessions.keys()].map((k) => this.info(k)).filter(Boolean);
      }
      /**
       * Start (or restart) the preview for a project.
       *
       * A restart keeps the SAME public port and proxy, so the pane the user is
       * looking at does not have to be re-created — only the inner dev server is
       * replaced. That keeps the embedded iframe URL stable across AI edits.
       */
      async start(project, dir, opts = {}) {
        const existing = this.sessions.get(project);
        if (existing && !opts.restart && (existing.ready || !existing.error && existing.child)) return this.info(project);
        if (existing) {
          await this.killChild(existing);
          existing.error = null;
          existing.ready = false;
          existing.logs.push("[re] restarting preview\u2026");
          await this.bringUp(existing, dir);
          return this.info(project);
        }
        const session = {
          project,
          dir,
          kind: "starting",
          command: "",
          internalPort: null,
          publicPort: 0,
          proxy: null,
          child: null,
          staticRoot: null,
          startedAt: Date.now(),
          logs: [],
          ready: false,
          error: null
        };
        session.logs.push(`[re] preparing preview for ${project}`);
        this.sessions.set(project, session);
        session.publicPort = await freePort();
        try {
          await this.bringUp(session, dir);
          session.proxy = await createProxy(session, () => session.ready && session.internalPort ? session.internalPort : null);
          session.logs.push(`[re] preview proxy on 0.0.0.0:${session.publicPort}`);
        } catch (e) {
          session.error = String(e?.message ?? e);
          session.logs.push(`[re] preview failed: ${session.error}`);
        }
        return this.info(project);
      }
      /** Detect the stack, launch the dev server (or static server) and wait for it. */
      async bringUp(session, dir) {
        let plan = null;
        try {
          plan = await planFor(dir);
        } catch {
          plan = null;
        }
        if (!plan) {
          session.kind = "none";
          session.command = "\u2014";
          session.error = "No runnable entry point found. Add a package.json script (dev/start), an index.html, or a manage.py.";
          return;
        }
        if (plan.static) {
          session.kind = "static";
          session.command = plan.command;
          session.staticRoot = plan.staticRoot ?? dir;
          session.ready = true;
          session.logs.push(`[re] serving static files from ${session.staticRoot}`);
          return;
        }
        const port = await freePort();
        session.internalPort = port;
        const env = { ...scrubbedEnv2(), PORT: String(port), HOST: "0.0.0.0", BROWSER: "none", FORCE_COLOR: "0", CI: "1" };
        for (const [k, v] of Object.entries(plan.env ?? {})) env[k] = String(v).replace("<p>", String(port));
        const args2 = plan.args(port);
        session.kind = plan.kind;
        session.command = plan.command.replace(/<p>/g, String(port));
        session.logs.push(`[re] $ ${plan.bin} ${args2.join(" ")}`);
        const child = spawn2(plan.bin, args2, { cwd: dir, env, stdio: ["ignore", "pipe", "pipe"], detached: true, shell: process.platform === "win32" });
        session.child = child;
        child.stdout?.on("data", (d) => {
          pushLog(session, d.toString());
          const p = sniffPort(d.toString());
          if (p && !session.ready) session.internalPort = p;
        });
        child.stderr?.on("data", (d) => pushLog(session, d.toString()));
        child.on("exit", (code, signal) => {
          pushLog(session, `[re] process exited (code ${code ?? "null"}${signal ? `, ${signal}` : ""})`);
          if (code !== 0 && !session.ready) session.error = `The dev server exited with code ${code}. See the preview log.`;
          session.ready = false;
        });
        const live = await waitForPort(session.internalPort, 45e3);
        if (!live) {
          session.error = `Nothing started listening on port ${session.internalPort} after 45s. Check the preview log and the project's dev script.`;
        } else {
          session.ready = true;
          session.logs.push(`[re] dev server listening on 127.0.0.1:${session.internalPort}`);
        }
      }
      /** Only the spawned process — the proxy and its port survive a restart. */
      async killChild(s) {
        if (!s.child?.pid) return;
        try {
          process.kill(-s.child.pid, "SIGTERM");
        } catch {
          try {
            s.child.kill("SIGTERM");
          } catch {
          }
        }
        await new Promise((r) => setTimeout(r, 350));
        try {
          process.kill(-s.child.pid, "SIGKILL");
        } catch {
        }
        s.child = null;
      }
      async stop(project) {
        const s = this.sessions.get(project);
        if (!s) return false;
        this.sessions.delete(project);
        await this.kill(s);
        return true;
      }
      async kill(s) {
        try {
          s.proxy?.close();
        } catch {
        }
        await this.killChild(s);
      }
      async stopAll() {
        for (const key of [...this.sessions.keys()]) await this.stop(key);
      }
      /**
       * Synchronous teardown for process exit. Dev servers are their own process
       * group (detached), so a SIGKILL to -pid takes the whole tree with it — no
       * orphan node processes pointing at a dead proxy.
       */
      stopAllSync() {
        for (const [, s] of this.sessions) {
          try {
            s.proxy?.close();
          } catch {
          }
          if (s.child?.pid) {
            try {
              process.kill(-s.child.pid, "SIGKILL");
            } catch {
              try {
                s.child.kill("SIGKILL");
              } catch {
              }
            }
          }
        }
        this.sessions.clear();
      }
      /** Restart after the AI (or the user) changed the code. */
      async reload(project) {
        const s = this.sessions.get(project);
        if (!s) return null;
        return this.start(project, s.dir, { restart: true });
      }
      /** Absolute path of a running preview (used for logs/diagnostics). */
      dirOf(project) {
        return this.sessions.get(project)?.dir ?? null;
      }
      /**
       * Static-file previews can also be served *through the app origin*
       * (`/api/ide/preview/site`). That is the fallback path for hosts that refuse
       * to embed a page from another port; it needs the folder, nothing else.
       */
      staticRootFor(project, fallbackDir) {
        const s = this.sessions.get(project);
        if (s?.staticRoot) return s.staticRoot;
        if (fallbackDir) {
          for (const candidate of ["", "public", "dist", "build"]) {
            const root = candidate ? join8(fallbackDir, candidate) : fallbackDir;
            if (existsSync6(join8(root, "index.html"))) return root;
          }
        }
        return null;
      }
    };
  }
});

// src/routes/preview.ts
var preview_exports = {};
__export(preview_exports, {
  previewRoutes: () => previewRoutes
});
import { Hono as Hono11 } from "hono";
import { existsSync as existsSync7, statSync as statSync6, readFileSync as readFileSync4, createReadStream as createReadStream3 } from "node:fs";
import { extname as extname3, join as join9, normalize as normalize3 } from "node:path";
function previewRoutes(rt, manager) {
  const r = new Hono11();
  const projectsRoot = projectsRootOf(rt.dataDir);
  const dirFor = (name) => {
    const dir = projectDirOf(projectsRoot, name);
    return dir && existsSync7(dir) ? dir : null;
  };
  r.get("/ide/preview", (c) => c.json({ previews: manager.list() }));
  r.get("/ide/preview/status", (c) => {
    const project = c.req.query("project") ?? "";
    const info = manager.info(project);
    return c.json(info ? { ...info, running: info.running ?? true } : { running: false, project });
  });
  r.post("/ide/preview/start", async (c) => {
    let body;
    try {
      body = await c.req.json();
    } catch {
      return c.json({ error: "Invalid JSON body." }, 400);
    }
    const project = String(body.project ?? "");
    const dir = dirFor(project);
    if (!dir) return c.json({ error: "Project not found." }, 404);
    try {
      const info = await manager.start(project, dir, { restart: !!body.restart });
      return c.json({ ok: !info.error, ...info });
    } catch (e) {
      return c.json({ error: String(e?.message ?? e) }, 500);
    }
  });
  r.post("/ide/preview/stop", async (c) => {
    let body;
    try {
      body = await c.req.json();
    } catch {
      return c.json({ error: "Invalid JSON body." }, 400);
    }
    const stopped = await manager.stop(String(body.project ?? ""));
    return c.json({ ok: stopped });
  });
  r.post("/ide/preview/reload", async (c) => {
    let body;
    try {
      body = await c.req.json();
    } catch {
      return c.json({ error: "Invalid JSON body." }, 400);
    }
    const info = await manager.reload(String(body.project ?? ""));
    if (!info) return c.json({ error: "No preview running for this project." }, 404);
    return c.json({ ok: !info.error, ...info });
  });
  r.get("/ide/preview/site", (c) => {
    const project = c.req.query("project") ?? "";
    const rel = decodeURIComponent(c.req.query("path") ?? "/");
    const dir = dirFor(project);
    if (!dir) return c.json({ error: "Project not found." }, 404);
    const root = manager.staticRootFor(project, dir);
    if (!root) return c.json({ error: "This project needs a running dev server \u2014 start the preview first." }, 404);
    const prefix = `/api/ide/preview/site?project=${encodeURIComponent(project)}&path=`;
    const safe = normalize3(rel.split("?")[0]).replace(/^(\.\.[/\\])+/, "").replace(/^\/+/, "");
    let file = join9(root, safe);
    if (!file.startsWith(root)) return c.json({ error: "Path escapes the project." }, 400);
    if (existsSync7(file) && statSync6(file).isDirectory()) file = join9(file, "index.html");
    if (!existsSync7(file)) {
      const index = join9(root, "index.html");
      if (existsSync7(index) && !extname3(safe)) file = index;
      else return c.text("404", 404);
    }
    const ext = extname3(file).toLowerCase();
    const type = MIME2[ext] ?? "application/octet-stream";
    if (type.includes("text/html")) {
      let html = readFileSync4(file, "utf8");
      html = html.replace(/(\s(?:href|src|action)=)(["'])\/(?!\/)/g, (_m, attr, q) => `${attr}${q}${prefix}`);
      html = injectBridge(html);
      return c.body(html, 200, { "content-type": "text/html; charset=utf-8", "cache-control": "no-store" });
    }
    if (type.startsWith("text/css") || type.includes("javascript")) {
      const text2 = readFileSync4(file, "utf8").replace(/url\((["']?)\//g, `url($1${prefix}`);
      return c.body(text2, 200, { "content-type": type, "cache-control": "no-store" });
    }
    c.header("content-type", type);
    c.header("cache-control", "no-store");
    return c.body(createReadStream3(file), 200);
  });
  r.get("/ide/preview/logs", (c) => {
    const info = manager.info(c.req.query("project") ?? "");
    return c.json({ logs: info?.logs ?? [] });
  });
  return r;
}
var init_preview = __esm({
  "src/routes/preview.ts"() {
    "use strict";
    init_manager();
    init_paths();
  }
});

// src/routes/connectors.ts
var connectors_exports = {};
__export(connectors_exports, {
  connectorRoutes: () => connectorRoutes
});
import { mkdir as mkdir3, readFile as readFile4, readdir as readdir4, rm as rm2, writeFile as writeFile3 } from "node:fs/promises";
import { join as join10, resolve as resolve5 } from "node:path";
import { randomUUID as randomUUID2 } from "node:crypto";
import { Hono as Hono12 } from "hono";
function connectorRoutes(rt) {
  const r = new Hono12();
  const root = resolve5(join10(rt.dataDir, "connectors"));
  const boxDir = (box) => join10(root, box);
  const isBox = (b) => BOXES.includes(b);
  const listItems = async (box) => {
    await mkdir3(boxDir(box), { recursive: true });
    const out = [];
    for (const f of await readdir4(boxDir(box))) {
      if (!f.endsWith(".json")) continue;
      try {
        out.push(JSON.parse(await readFile4(join10(boxDir(box), f), "utf8")));
      } catch {
      }
    }
    return out.sort((a, b) => (b.addedAt ?? b.date ?? 0) - (a.addedAt ?? a.date ?? 0));
  };
  r.get("/connectors/list", async (c) => {
    const box = c.req.query("box") ?? "";
    if (!isBox(box)) return c.json({ error: "Unknown connector box." }, 400);
    const items = await listItems(box);
    return c.json({ box, items: items.map(({ dataBase64, body, notes, ...rest }) => ({ ...rest, preview: (body ?? notes ?? "").slice(0, 160) })) });
  });
  r.get("/connectors/item", async (c) => {
    const box = c.req.query("box") ?? "";
    const id = (c.req.query("id") ?? "").replace(/[^a-zA-Z0-9_-]/g, "");
    if (!isBox(box) || !id) return c.json({ error: "Bad request." }, 400);
    try {
      const item = JSON.parse(await readFile4(join10(boxDir(box), `${id}.json`), "utf8"));
      if (box !== "drive") delete item.dataBase64;
      return c.json({ item });
    } catch {
      return c.json({ error: "Item not found." }, 404);
    }
  });
  r.get("/connectors/search", async (c) => {
    const q = (c.req.query("q") ?? "").toLowerCase();
    const box = c.req.query("box") ?? "";
    const boxes = isBox(box) ? [box] : ["drive", "mail", "calendar"];
    const hits = [];
    for (const b of boxes) {
      for (const item of await listItems(b)) {
        const hay = JSON.stringify({ ...item, dataBase64: void 0 }).toLowerCase();
        if (!q || hay.includes(q)) hits.push({ box: b, id: item.id, title: item.name ?? item.subject ?? item.title, snippet: (item.body ?? item.notes ?? item.text ?? "").slice(0, 200), date: item.date ?? item.addedAt });
      }
    }
    return c.json({ q, hits: hits.slice(0, 40) });
  });
  r.post("/connectors/add", async (c) => {
    let body;
    try {
      body = await c.req.json();
    } catch {
      return c.json({ error: "Invalid JSON body." }, 400);
    }
    const box = body.box;
    if (!isBox(box)) return c.json({ error: "Unknown connector box." }, 400);
    const id = randomUUID2().slice(0, 8);
    let item;
    if (box === "drive" || box === "files") {
      const buf = Buffer.from(body.dataBase64 ?? "", "base64");
      if (buf.length > CAPS[box]) return c.json({ error: "File larger than 8 MB." }, 413);
      if (!buf.length && !String(body.text ?? "").trim()) return c.json({ error: "Provide a file or some text." }, 400);
      item = { id, name: String(body.name ?? "file").slice(0, 200), mime: body.mime ?? (buf.length ? "application/octet-stream" : "text/plain"), text: body.text ?? null, dataBase64: buf.length ? body.dataBase64 : null, addedAt: Date.now() };
    } else if (box === "mail") {
      item = { id, from: body.from ?? "", to: body.to ?? "", subject: String(body.subject ?? "").slice(0, 300), body: String(body.body ?? "").slice(0, CAPS.mail), date: body.date ?? (/* @__PURE__ */ new Date()).toISOString(), read: false, addedAt: Date.now() };
    } else {
      item = { id, title: String(body.title ?? "").slice(0, 300), date: body.date ?? "", time: body.time ?? "", location: body.location ?? "", notes: String(body.notes ?? "").slice(0, CAPS.calendar), attendees: body.attendees ?? [], addedAt: Date.now() };
    }
    await mkdir3(boxDir(box), { recursive: true });
    await writeFile3(join10(boxDir(box), `${id}.json`), JSON.stringify(item));
    return c.json({ ok: true, id });
  });
  r.delete("/connectors/item", async (c) => {
    const box = c.req.query("box") ?? "";
    const id = (c.req.query("id") ?? "").replace(/[^a-zA-Z0-9_-]/g, "");
    if (!isBox(box) || !id) return c.json({ error: "Bad request." }, 400);
    await rm2(join10(boxDir(box), `${id}.json`), { force: true });
    return c.json({ ok: true });
  });
  return r;
}
var BOXES, CAPS;
var init_connectors = __esm({
  "src/routes/connectors.ts"() {
    "use strict";
    BOXES = ["drive", "mail", "calendar", "files"];
    CAPS = { drive: 8 * 1024 * 1024, mail: 512 * 1024, calendar: 256 * 1024, files: 8 * 1024 * 1024 };
  }
});

// src/routes/mcp.ts
var mcp_exports = {};
__export(mcp_exports, {
  mcpRoutes: () => mcpRoutes
});
import { spawn as spawn3 } from "node:child_process";
import { Hono as Hono13 } from "hono";
function scrubServer(s) {
  const command = String(s?.command ?? "").trim();
  if (!command || /[;&|`$]/.test(command)) throw new Error("Invalid MCP command");
  const args2 = Array.isArray(s?.args) ? s.args.map(String).slice(0, 24) : [];
  const env = {};
  if (s?.env && typeof s.env === "object") {
    for (const [k, v] of Object.entries(s.env)) {
      if (/^[A-Za-z_][A-Za-z0-9_]*$/.test(k) && typeof v === "string") env[k] = v;
    }
  }
  return { command, args: args2, env };
}
function mcpRoutes() {
  const r = new Hono13();
  r.post("/mcp/tools", async (c) => {
    let body;
    try {
      body = await c.req.json();
    } catch {
      return c.json({ error: "Invalid JSON body." }, 400);
    }
    const out = [];
    for (const s of body.servers ?? []) {
      let session = null;
      try {
        const { command, args: args2, env } = scrubServer(s);
        session = new McpSession(command, args2, env);
        await session.init();
        const res = await session.request("tools/list", {}, HANDSHAKE_TIMEOUT_MS);
        out.push({ serverId: s.id, serverName: s.name ?? s.id, ok: true, tools: (res?.tools ?? []).map((t) => ({ name: t.name, description: t.description ?? "", inputSchema: t.inputSchema ?? {} })) });
      } catch (e) {
        out.push({ serverId: s.id, serverName: s.name ?? s.id, ok: false, error: String(e?.message ?? e), tools: [] });
      } finally {
        session?.kill();
      }
    }
    return c.json({ servers: out });
  });
  r.post("/mcp/call", async (c) => {
    let body;
    try {
      body = await c.req.json();
    } catch {
      return c.json({ error: "Invalid JSON body." }, 400);
    }
    let session = null;
    try {
      const { command, args: args2, env } = scrubServer(body.server);
      session = new McpSession(command, args2, env);
      await session.init();
      const res = await session.request("tools/call", { name: body.name, arguments: body.arguments ?? {} });
      const text2 = (res?.content ?? []).map((p) => p?.text ?? "").join("\n").slice(0, 1e5);
      return c.json({ ok: !res?.isError, text: text2, isError: !!res?.isError });
    } catch (e) {
      return c.json({ ok: false, isError: true, text: `MCP call failed: ${String(e?.message ?? e)}` }, 200);
    } finally {
      session?.kill();
    }
  });
  return r;
}
var PROTOCOL_VERSION, HANDSHAKE_TIMEOUT_MS, CALL_TIMEOUT_MS, McpSession;
var init_mcp = __esm({
  "src/routes/mcp.ts"() {
    "use strict";
    PROTOCOL_VERSION = "2024-11-05";
    HANDSHAKE_TIMEOUT_MS = 12e3;
    CALL_TIMEOUT_MS = 3e4;
    McpSession = class {
      child;
      buf = "";
      nextId = 1;
      pending = /* @__PURE__ */ new Map();
      dead = false;
      constructor(command, args2, env) {
        this.child = spawn3(command, args2, {
          stdio: ["pipe", "pipe", "pipe"],
          env: { PATH: process.env.PATH ?? "/usr/bin:/bin", HOME: process.env.HOME ?? "", ...env }
        });
        this.child.stdout.on("data", (d) => this.onData(d.toString()));
        this.child.stderr.on("data", () => {
        });
        this.child.on("exit", () => {
          this.dead = true;
          for (const p of this.pending.values()) p.reject(new Error("MCP server exited"));
        });
        this.child.on("error", (e) => {
          this.dead = true;
          for (const p of this.pending.values()) p.reject(e);
        });
      }
      onData(chunk) {
        this.buf += chunk;
        let idx;
        while ((idx = this.buf.indexOf("\n")) >= 0) {
          const line = this.buf.slice(0, idx).trim();
          this.buf = this.buf.slice(idx + 1);
          if (!line) continue;
          try {
            const msg = JSON.parse(line);
            if (msg.id != null && this.pending.has(msg.id)) {
              const p = this.pending.get(msg.id);
              this.pending.delete(msg.id);
              if (msg.error) p.reject(new Error(msg.error?.message ?? "MCP error"));
              else p.resolve(msg.result);
            }
          } catch {
          }
        }
      }
      notify(method, params) {
        if (this.dead) return;
        this.child.stdin.write(JSON.stringify({ jsonrpc: "2.0", method, params }) + "\n");
      }
      request(method, params, timeoutMs = CALL_TIMEOUT_MS) {
        if (this.dead) return Promise.reject(new Error("MCP server not running"));
        const id = this.nextId++;
        return new Promise((resolve6, reject) => {
          const to = setTimeout(() => {
            this.pending.delete(id);
            reject(new Error(`Timed out after ${Math.round(timeoutMs / 1e3)}s`));
          }, timeoutMs);
          this.pending.set(id, {
            resolve: (v) => {
              clearTimeout(to);
              resolve6(v);
            },
            reject: (e) => {
              clearTimeout(to);
              reject(e);
            }
          });
          this.child.stdin.write(JSON.stringify({ jsonrpc: "2.0", id, method, params }) + "\n");
        });
      }
      async init() {
        const caps = await this.request("initialize", {
          protocolVersion: PROTOCOL_VERSION,
          capabilities: {},
          clientInfo: { name: "research-engine", version: "0.15" }
        }, HANDSHAKE_TIMEOUT_MS);
        this.notify("notifications/initialized");
        return caps;
      }
      kill() {
        try {
          this.child.kill("SIGKILL");
        } catch {
        }
      }
    };
  }
});

// src/index.ts
init_runtime();
import { serve } from "@hono/node-server";
import { Hono as Hono14 } from "hono";
import { cors } from "hono/cors";
import { logger } from "hono/logger";

// src/static.ts
import { createReadStream, existsSync as existsSync3, statSync as statSync3 } from "node:fs";
import { Readable } from "node:stream";
import { extname, join as join3, normalize } from "node:path";
var MIME = {
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".mjs": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".json": "application/json",
  ".svg": "image/svg+xml",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".webp": "image/webp",
  ".ico": "image/x-icon",
  ".woff": "font/woff",
  ".woff2": "font/woff2",
  ".ttf": "font/ttf",
  ".map": "application/json",
  ".txt": "text/plain; charset=utf-8",
  ".webmanifest": "application/manifest+json"
};
function staticHandler(root) {
  const indexHtml = join3(root, "index.html");
  return async (c) => {
    const url = new URL(c.req.url);
    let rel = decodeURIComponent(url.pathname).replace(/^\/+/, "");
    rel = normalize(rel).replace(/^(\.\.[/\\])+/, "");
    const file = rel ? join3(root, rel) : indexHtml;
    const target = existsSync3(file) && statSync3(file).isFile() ? file : indexHtml;
    if (!existsSync3(target)) return c.notFound();
    const isIndex = target === indexHtml;
    const headers = {
      "content-type": MIME[extname(target).toLowerCase()] ?? "application/octet-stream",
      "content-length": String(statSync3(target).size)
    };
    if (isIndex) headers["cache-control"] = "no-cache";
    else if (rel.startsWith("assets/")) headers["cache-control"] = "public, max-age=31536000, immutable";
    const rs = createReadStream(target);
    return new Response(Readable.toWeb(rs), { status: 200, headers });
  };
}

// src/index.ts
init_build_info();
async function main() {
  const rt = await resolveRuntime(process.argv.slice(2));
  const { healthRoutes: healthRoutes2 } = await init_health().then(() => health_exports);
  const { searchRoutes: searchRoutes2 } = await Promise.resolve().then(() => (init_search(), search_exports));
  const { chatRoutes: chatRoutes2 } = await Promise.resolve().then(() => (init_chat(), chat_exports));
  const { documentRoutes: documentRoutes2 } = await init_documents().then(() => documents_exports);
  const { ollamaRoutes: ollamaRoutes2 } = await Promise.resolve().then(() => (init_ollama(), ollama_exports));
  const { integrationRoutes: integrationRoutes2 } = await Promise.resolve().then(() => (init_integrations(), integrations_exports));
  const { resourceRoutes: resourceRoutes2 } = await init_resources().then(() => resources_exports);
  const { fsRoutes: fsRoutes2 } = await Promise.resolve().then(() => (init_fs(), fs_exports));
  const { providerRoutes: providerRoutes2 } = await Promise.resolve().then(() => (init_providers(), providers_exports));
  const { ideRoutes: ideRoutes2 } = await Promise.resolve().then(() => (init_ide(), ide_exports));
  const { previewRoutes: previewRoutes2 } = await Promise.resolve().then(() => (init_preview(), preview_exports));
  const { PreviewManager: PreviewManager3 } = await Promise.resolve().then(() => (init_manager(), manager_exports));
  const { connectorRoutes: connectorRoutes2 } = await Promise.resolve().then(() => (init_connectors(), connectors_exports));
  const { mcpRoutes: mcpRoutes2 } = await Promise.resolve().then(() => (init_mcp(), mcp_exports));
  const previews = new PreviewManager3();
  previewsForExit = previews;
  const app = new Hono14();
  app.use("*", cors());
  app.use("*", logger((msg) => console.log(`[re] ${msg}`)));
  app.route("/api", healthRoutes2(rt.frontendDist));
  app.route("/api", resourceRoutes2(rt));
  app.route("/api", fsRoutes2(rt));
  app.route("/api", ideRoutes2(rt));
  app.route("/api", previewRoutes2(rt, previews));
  app.route("/api", connectorRoutes2(rt));
  app.route("/api", mcpRoutes2());
  app.route("/api/search", searchRoutes2);
  app.route("/api/chat", chatRoutes2);
  app.route("/api/documents", documentRoutes2);
  app.route("/api/ollama", ollamaRoutes2);
  app.route("/api/integrations", integrationRoutes2);
  app.route("/api", providerRoutes2);
  app.onError((err, c) => {
    return c.json({ error: err.message }, 500);
  });
  if (rt.frontendDist) {
    const handler = staticHandler(rt.frontendDist);
    app.get("*", handler);
  }
  serve({ fetch: app.fetch, port: rt.port, hostname: rt.host }, (info) => {
    console.log(`Research Engine listening on http://${rt.host}:${info.port}`);
    console.log(`  data dir : ${rt.dataDir}`);
    console.log(`  profile  : ${rt.profile} (${rt.caps.floodWorkers} flood worker${rt.caps.floodWorkers > 1 ? "s" : ""}, ${rt.caps.concurrentStreams} concurrent stream${rt.caps.concurrentStreams > 1 ? "s" : ""})`);
    console.log(`  frontend : ${rt.frontendDist ?? "not found \u2014 API only (run `npm run build` in frontend/ for single-process mode)"}${rt.frontendDist ? webBuildNote(rt) : ""}`);
    console.log(`  database : ${rt.dbPath}`);
    if (rt.rememberedPort) console.log(`  note     : preferred port was busy \u2014 using ${info.port} (remembered in config.json)`);
  });
}
function webBuildNote(rt) {
  const served = webBuild(rt.frontendDist);
  if (!served) return " (no build-info.json \u2014 rebuild the frontend to get a fingerprint)";
  const source = sourceVersion();
  const stale = source && served.version !== source ? ` \u2014 STALE, source is ${source} (run: npm run build)` : "";
  return ` [${served.version}]${stale}`;
}
var previewsForExit = null;
process.on("exit", () => {
  try {
    previewsForExit?.stopAllSync();
  } catch {
  }
});
for (const sig of ["SIGINT", "SIGTERM", "SIGHUP"]) {
  process.on(sig, () => {
    try {
      previewsForExit?.stopAllSync();
    } catch {
    }
    ;
    process.exit(0);
  });
}
main().catch((e) => {
  console.error("[re] fatal:", e);
  process.exit(1);
});
