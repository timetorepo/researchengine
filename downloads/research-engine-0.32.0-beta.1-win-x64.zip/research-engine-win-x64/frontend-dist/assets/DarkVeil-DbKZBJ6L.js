import{r as i,dy as s,cQ as l,j as o}from"./index-C0maNvSO.js";import{C as u,V as n,u as f}from"./react-three-fiber.esm-B_8OgORT.js";const m=`
varying vec2 vUv;
void main() {
  vUv = uv;
  gl_Position = vec4(position.xy, 0.0, 1.0);
}
`,p=`
precision highp float;
varying vec2 vUv;
uniform float uTime;
uniform vec3 uColorA;
uniform vec3 uColorB;
uniform float uIntensity;

vec2 hash2(vec2 p) {
  p = vec2(dot(p, vec2(127.1, 311.7)), dot(p, vec2(269.5, 183.3)));
  return -1.0 + 2.0 * fract(sin(p) * 43758.5453123);
}
float noise(vec2 p) {
  vec2 i = floor(p);
  vec2 f = fract(p);
  vec2 u = f * f * (3.0 - 2.0 * f);
  return mix(
    mix(dot(hash2(i + vec2(0.0, 0.0)), f - vec2(0.0, 0.0)),
        dot(hash2(i + vec2(1.0, 0.0)), f - vec2(1.0, 0.0)), u.x),
    mix(dot(hash2(i + vec2(0.0, 1.0)), f - vec2(0.0, 1.0)),
        dot(hash2(i + vec2(1.0, 1.0)), f - vec2(1.0, 1.0)), u.x),
    u.y);
}
float fbm(vec2 p) {
  float v = 0.0;
  float a = 0.5;
  mat2 rot = mat2(0.8, 0.6, -0.6, 0.8);
  for (int i = 0; i < 5; i++) {
    v += a * noise(p);
    p = rot * p * 2.0 + vec2(1.7, 9.2);
    a *= 0.5;
  }
  return v;
}

void main() {
  float t = uTime * 0.045;
  vec2 uv = vUv * vec2(2.6, 1.8);
  float n1 = fbm(uv + vec2(t, -t * 0.6));
  float n2 = fbm(uv * 1.9 - vec2(t * 1.4, t * 0.5) + n1 * 0.8);
  float veil = smoothstep(-0.4, 0.9, n1 * 0.55 + n2 * 0.45);
  vec3 col = mix(uColorA, uColorB, veil);
  col *= mix(0.82, 1.06, vUv.y); // softly darker toward the bottom
  gl_FragColor = vec4(col, uIntensity);
}
`;function d({a:e,b:a,intensity:r}){const t=i.useRef(null),v=i.useMemo(()=>({uTime:{value:0},uColorA:{value:new n(...e)},uColorB:{value:new n(...a)},uIntensity:{value:r}}),[e.join(","),a.join(","),r]);return f((h,c)=>{t.current&&(t.current.uniforms.uTime.value+=c)}),o.jsxs("mesh",{children:[o.jsx("planeGeometry",{args:[2,2]}),o.jsx("shaderMaterial",{ref:t,vertexShader:m,fragmentShader:p,uniforms:v,transparent:!0,depthTest:!1,depthWrite:!1})]})}function y({theme:e,intensity:a=.6}){const r=i.useMemo(()=>s(e.bg,e.isLight?.92:.62),[e]),t=i.useMemo(()=>l(s(e.bg,e.isLight?.8:.9),e.primary,.16),[e]);return o.jsx("div",{className:"absolute inset-0","aria-hidden":"true",children:o.jsx(u,{gl:{antialias:!1,alpha:!0,powerPreference:"low-power"},camera:{position:[0,0,1]},dpr:[1,1.5],style:{position:"absolute",inset:0},children:o.jsx(d,{a:r,b:t,intensity:Math.min(1,a+.15)})})})}export{y as default};
