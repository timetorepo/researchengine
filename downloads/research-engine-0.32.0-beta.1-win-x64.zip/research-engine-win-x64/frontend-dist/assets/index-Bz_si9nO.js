import{dv as a,dw as e,dx as t}from"./index-C0maNvSO.js";const n={renderer:t,...e,...a};var o=n;export{o as default};
