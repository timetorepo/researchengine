import{ev as e,ew as a,ex as t}from"./index-CP48Uoo8.js";const n={renderer:t,...a,...e};var o=n;export{o as default};
