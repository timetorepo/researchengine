import{r as m,l as j,eB as z,j as o,i as w,a1 as C}from"./index-CP48Uoo8.js";import{C as S,a as $,u as k,S as E,O as F,b as I,c as M,G as O,d as x,V as g}from"./react-three-fiber.esm-C1YffUTX.js";const q=({animationSpeed:e=.4,opacities:n=[.3,.3,.3,.5,.5,.5,.8,.8,.8,1],colors:i=[[0,255,255]],containerClassName:s,dotSize:u,showGradient:f=!0,paused:d})=>{const v=m.useRef(null),[l,t]=m.useState(!1),[a,r]=m.useState(()=>typeof document>"u"||document.visibilityState==="visible"),c=j();m.useEffect(()=>{const p=v.current;if(!p||typeof IntersectionObserver>"u"){t(!0);return}const y=new IntersectionObserver(([h])=>t(h.isIntersecting),{rootMargin:"120px"});return y.observe(p),()=>y.disconnect()},[]),m.useEffect(()=>{const p=()=>r(document.visibilityState==="visible");return document.addEventListener("visibilitychange",p),()=>document.removeEventListener("visibilitychange",p)},[]);const _=z()==="minimal",b=!c&&a&&!_&&!(d??!l);return o.jsxs("div",{ref:v,className:w("relative h-full w-full bg-transparent",s),children:[c||_||!a?o.jsx("div",{className:"h-full w-full",style:{backgroundImage:`radial-gradient(${`rgba(${i[0][0]},${i[0][1]},${i[0][2]},0.35)`} ${u??3}px, transparent ${u??3}px)`,backgroundSize:"14px 14px"}}):o.jsx("div",{className:"h-full w-full",children:o.jsx(R,{colors:i??[[0,255,255]],dotSize:u??3,opacities:n??[.3,.3,.3,.5,.5,.5,.8,.8,.8,1],shader:`
              float animation_speed_factor = ${e.toFixed(1)};
              float intro_offset = distance(u_resolution / 2.0 / u_total_size, st2) * 0.01 + (random(st2) * 0.15);
              opacity *= step(intro_offset, u_time * animation_speed_factor);
              opacity *= clamp((1.0 - step(intro_offset + 0.1, u_time * animation_speed_factor)) * 1.25, 1.0, 1.25);
            `,center:["x","y"],paused:!b})}),f&&!c&&o.jsx("div",{className:"absolute inset-0 bg-gradient-to-t from-gray-950 to-[84%]"})]})},R=({colors:e=[[0,0,0]],opacities:n=[.04,.04,.04,.04,.04,.08,.08,.08,.08,.14],totalSize:i=4,dotSize:s=2,shader:u="",center:f=["x","y"],paused:d=!1})=>{const v=C.useMemo(()=>{let l=[e[0],e[0],e[0],e[0],e[0],e[0]];return e.length===2?l=[e[0],e[0],e[0],e[1],e[1],e[1]]:e.length===3&&(l=[e[0],e[0],e[1],e[1],e[2],e[2]]),{u_colors:{value:l.map(t=>[t[0]/255,t[1]/255,t[2]/255]),type:"uniform3fv"},u_opacities:{value:n,type:"uniform1fv"},u_total_size:{value:i,type:"uniform1f"},u_dot_size:{value:s,type:"uniform1f"}}},[e,n,i,s]);return o.jsx(N,{source:`
        precision mediump float;
        in vec2 fragCoord;

        uniform float u_time;
        uniform float u_opacities[10];
        uniform vec3 u_colors[6];
        uniform float u_total_size;
        uniform float u_dot_size;
        uniform vec2 u_resolution;
        out vec4 fragColor;
        float PHI = 1.61803398874989484820459;
        float random(vec2 xy) {
            return fract(tan(distance(xy * PHI, xy) * 0.5) * xy.x);
        }
        float map(float value, float min1, float max1, float min2, float max2) {
            return min2 + (value - min1) * (max2 - min2) / (max1 - min1);
        }
        void main() {
            vec2 st = fragCoord.xy;
            ${f.includes("x")?"st.x -= abs(floor((mod(u_resolution.x, u_total_size) - u_dot_size) * 0.5));":""}
            ${f.includes("y")?"st.y -= abs(floor((mod(u_resolution.y, u_total_size) - u_dot_size) * 0.5));":""}
      float opacity = step(0.0, st.x);
      opacity *= step(0.0, st.y);

      vec2 st2 = vec2(int(st.x / u_total_size), int(st.y / u_total_size));

      float frequency = 5.0;
      float show_offset = random(st2);
      float rand = random(st2 * floor((u_time / frequency) + show_offset + frequency) + 1.0);
      opacity *= u_opacities[int(rand * 10.0)];
      opacity *= 1.0 - step(u_dot_size / u_total_size, fract(st.x / u_total_size));
      opacity *= 1.0 - step(u_dot_size / u_total_size, fract(st.y / u_total_size));

      vec3 color = u_colors[int(show_offset * 6.0)];

      ${u}

      fragColor = vec4(color, opacity);
      fragColor.rgb *= fragColor.a;
        }`,uniforms:v,maxFps:d?0:60})},L=({source:e,uniforms:n,maxFps:i=60,paused:s=!1})=>{const{size:u}=$(),f=m.useRef(null);let d=0;k(({clock:t})=>{if(!f.current||s)return;const a=t.getElapsedTime();if(a-d<1/i)return;d=a;const c=f.current.material.uniforms.u_time;c.value=a});const v=()=>{const t={};for(const a in n){const r=n[a];switch(r.type){case"uniform1f":t[a]={value:r.value,type:"1f"};break;case"uniform3f":t[a]={value:new g().fromArray(r.value),type:"3f"};break;case"uniform1fv":t[a]={value:r.value,type:"1fv"};break;case"uniform3fv":t[a]={value:r.value.map(c=>new g().fromArray(c)),type:"3fv"};break;case"uniform2f":t[a]={value:new x().fromArray(r.value),type:"2f"};break;default:console.error(`Invalid uniform type for '${a}'.`);break}}return t.u_time={value:0,type:"1f"},t.u_resolution={value:new x(u.width*2,u.height*2)},t},l=m.useMemo(()=>new E({vertexShader:`
      precision mediump float;
      in vec2 coordinates;
      uniform vec2 u_resolution;
      out vec2 fragCoord;
      void main(){
        float x = position.x;
        float y = position.y;
        gl_Position = vec4(x, y, 0.0, 1.0);
        fragCoord = (position.xy + vec2(1.0)) * 0.5 * u_resolution;
        fragCoord.y = u_resolution.y - fragCoord.y;
      }
      `,fragmentShader:e,uniforms:v(),glslVersion:O,blending:M,blendSrc:I,blendDst:F}),[e]);return o.jsxs("mesh",{ref:f,children:[o.jsx("planeGeometry",{args:[2,2]}),o.jsx("primitive",{object:l,attach:"material"})]})},N=({source:e,uniforms:n,maxFps:i=60,paused:s=!1})=>o.jsx(S,{className:"absolute inset-0 h-full w-full",children:o.jsx(L,{source:e,uniforms:n,maxFps:i,paused:s})});export{q as CanvasRevealEffect};
