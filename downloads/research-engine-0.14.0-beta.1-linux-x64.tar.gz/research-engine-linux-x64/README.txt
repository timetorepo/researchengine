Research Engine — portable build (linux-x64)

Requires Node.js 20+ on this machine (https://nodejs.org). For a fully
self-contained executable, rebuild with Bun: node scripts/package-binary.mjs --bun

Run:
  ./research-engine serve --port 3847

Then open http://127.0.0.1:3847

Data directory: ~/.research-engine (override with RESEARCH_ENGINE_DATA_DIR)
Profiles: ./research-engine serve --profile eco|balanced|performance
