import{eF as e,eG as a,eH as t}from"./index-DTwxbeFT.js";const n={renderer:t,...a,...e};var o=n;export{o as default};
