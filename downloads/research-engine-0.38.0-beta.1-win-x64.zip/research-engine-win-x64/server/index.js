var __defProp = Object.defineProperty;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// src/build-info.ts
import { existsSync, readFileSync, statSync } from "node:fs";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";
function moduleDir() {
  return dirname(fileURLToPath(import.meta.url));
}
function repoRoot() {
  return join(moduleDir(), "..", "..");
}
function resolveDistDir() {
  const candidates = [
    join(moduleDir(), "..", "frontend-dist"),
    // portable: <dir>/server → <dir>/frontend-dist
    join(repoRoot(), "frontend", "dist")
    // checkout: <repo>/frontend/dist
  ];
  return candidates.find((d) => existsSync(join(d, "index.html"))) ?? null;
}
function webBuild(distDir) {
  const dir = distDir ?? resolveDistDir() ?? join(repoRoot(), "frontend", "dist");
  const file2 = join(dir, "build-info.json");
  try {
    if (!existsSync(file2)) return null;
    const mtime = statSync(file2).mtimeMs;
    if (cache && cache.at === mtime) return cache.value;
    const parsed = JSON.parse(readFileSync(file2, "utf8"));
    const value = {
      version: String(parsed.version ?? ""),
      buildId: String(parsed.buildId ?? ""),
      builtAt: String(parsed.builtAt ?? "")
    };
    cache = { at: mtime, value };
    return value;
  } catch {
    cache = { at: -1, value: null };
    return null;
  }
}
function installMode() {
  try {
    const pkg = JSON.parse(readFileSync(join(moduleDir(), "package.json"), "utf8"));
    return pkg.name === "research-engine-server" ? "portable" : "checkout";
  } catch {
    return "checkout";
  }
}
function installKind() {
  if (process.env.RE_SHELL === "desktop") return "desktop";
  return installMode();
}
function appRoot() {
  if (installMode() !== "portable") return null;
  return resolve(moduleDir(), "..");
}
function sourceVersion() {
  const candidates = [
    join(moduleDir(), "package.json"),
    // portable build: <dir>/server/package.json
    join(repoRoot(), "package.json")
    // source checkout: <repo>/package.json
  ];
  for (const file2 of candidates) {
    try {
      const pkg = JSON.parse(readFileSync(file2, "utf8"));
      if (pkg.version && (pkg.name === "research-engine" || pkg.name === "research-engine-server")) return pkg.version;
    } catch {
    }
  }
  return "";
}
function buildInfoReport(frontendDist) {
  const served = webBuild(frontendDist);
  const source = sourceVersion();
  const mode = installMode();
  const lines = [
    `Research Engine ${source || "(unknown version)"}  [${mode}]`,
    served ? `  built frontend : ${served.version} (${served.builtAt})` : "  built frontend : not found \u2014 run `npm run build` in frontend/ (or unpack a release archive)"
  ];
  if (served && source && served.version !== source) {
    lines.push(
      `  STATUS         : STALE \u2014 the served build is ${served.version} but this code is ${source}`,
      mode === "checkout" ? "                   fix: npm run build   (then restart the server)" : "                   fix: unpack the current release archive over this folder",
      '                   or press "Clear cache & reload" on Settings \u2192 About if the page itself is cached'
    );
  } else if (served) {
    lines.push("  STATUS         : up to date");
  }
  return lines.join("\n");
}
var cache;
var init_build_info = __esm({
  "src/build-info.ts"() {
    "use strict";
    cache = null;
  }
});

// src/runtime.ts
import { existsSync as existsSync2, mkdirSync, readFileSync as readFileSync2, writeFileSync, statSync as statSync2, readdirSync } from "node:fs";
import { join as join2, resolve as resolve2 } from "node:path";
import { homedir } from "node:os";
import { createServer } from "node:net";
function parseFlags(argv) {
  const f = { serve: argv[0] !== "serve" ? true : true };
  const args2 = argv.filter((a) => a !== "serve");
  if (args2.includes("version") || args2.includes("--version") || args2.includes("-v")) {
    console.log(buildInfoReport(f.frontendDist));
    process.exit(0);
  }
  for (let i = 0; i < args2.length; i++) {
    const a = args2[i];
    const val = () => args2[++i];
    if (a === "--port") f.port = Number(val());
    else if (a === "--host") f.host = val();
    else if (a === "--data-dir") f.dataDir = val();
    else if (a === "--profile") {
      const p = val();
      if (p in PROFILES) f.profile = p;
    } else if (a === "--frontend-dist") f.frontendDist = val();
    else if (a === "--help" || a === "-h") {
      console.log(`Research Engine \u2014 single-process server

Usage: research-engine serve [options]
       research-engine version            Show the build fingerprint and exit
  --port <n>          HTTP port (default 3847; auto-picks next free if busy)
  --host <addr>       Bind address (default 127.0.0.1)
  --data-dir <path>   Data directory (default ~/.research-engine)
  --profile <p>       eco | balanced | performance (default balanced)
  --frontend-dist <p> Path to built frontend (default ../frontend/dist)

Environment: RE_PORT, RE_HOST, RESEARCH_ENGINE_DATA_DIR, RE_PROFILE, FRONTEND_DIST`);
      process.exit(0);
    }
  }
  return f;
}
function configPath(dataDir) {
  return join2(dataDir, "config.json");
}
function loadConfig(dataDir) {
  try {
    return JSON.parse(readFileSync2(configPath(dataDir), "utf8"));
  } catch {
    return {};
  }
}
function saveConfig(dataDir, patch) {
  const merged = { ...loadConfig(dataDir), ...patch };
  writeFileSync(configPath(dataDir), JSON.stringify(merged, null, 2));
  return merged;
}
function ensureDataDir(dataDir) {
  for (const sub of ["", "media", "notebooks", "cache"]) {
    mkdirSync(join2(dataDir, sub), { recursive: true });
  }
  if (!existsSync2(configPath(dataDir))) writeFileSync(configPath(dataDir), "{}\n");
}
function dirSize(dir) {
  try {
    let total = 0;
    for (const entry of readdirSync(dir, { withFileTypes: true })) {
      const p = join2(dir, entry.name);
      if (entry.isDirectory()) total += dirSize(p);
      else if (entry.isFile()) total += statSync2(p).size;
    }
    return total;
  } catch {
    return 0;
  }
}
function portFree(port, host2) {
  return new Promise((res) => {
    const srv = createServer();
    srv.once("error", () => res(false));
    srv.listen({ port, host: host2, exclusive: true }, () => {
      srv.close(() => res(true));
    });
  });
}
async function pickPort(preferred2, host2) {
  for (let i = 0; i < 20; i++) {
    if (await portFree(preferred2 + i, host2)) return preferred2 + i;
  }
  return preferred2;
}
async function resolveRuntime(argv) {
  const flags = parseFlags(argv);
  const dataDir = resolve2(flags.dataDir ?? process.env.RESEARCH_ENGINE_DATA_DIR ?? join2(homedir(), ".research-engine"));
  ensureDataDir(dataDir);
  const saved = loadConfig(dataDir);
  const host2 = flags.host ?? process.env.RE_HOST ?? "127.0.0.1";
  const envPort = Number(process.env.RE_PORT ?? process.env.PORT ?? "");
  const isDev = import.meta.url.includes("/src/");
  const preferredPort = flags.port ?? (envPort || (isDev ? 8787 : saved.port || 3847));
  const port = await pickPort(preferredPort, host2);
  const rememberedPort = port !== preferredPort;
  const profileRaw = flags.profile ?? process.env.RE_PROFILE ?? saved.profile ?? "balanced";
  const profile = profileRaw in PROFILES ? profileRaw : "balanced";
  const candidates = [
    flags.frontendDist,
    process.env.FRONTEND_DIST,
    resolve2(import.meta.dirname, "../../frontend/dist"),
    resolve2(process.cwd(), "frontend/dist")
  ].filter(Boolean);
  const frontendDist = candidates.find((d) => existsSync2(join2(d, "index.html"))) ?? null;
  const dbPath2 = process.env.DB_PATH ?? join2(dataDir, "db.sqlite");
  process.env.DB_PATH = dbPath2;
  if (rememberedPort && !isDev) saveConfig(dataDir, { port });
  return { port, host: host2, dataDir, profile, caps: PROFILES[profile], frontendDist, dbPath: dbPath2, rememberedPort };
}
var PROFILES;
var init_runtime = __esm({
  "src/runtime.ts"() {
    "use strict";
    init_build_info();
    PROFILES = {
      eco: {
        floodWorkers: 1,
        searchResults: 5,
        concurrentStreams: 1,
        backgroundIndexing: false,
        description: "1 concurrent stream, smaller retrieval, no background work. Best on \u22648 GB RAM."
      },
      balanced: {
        floodWorkers: 2,
        searchResults: 7,
        concurrentStreams: 2,
        backgroundIndexing: true,
        description: "Normal multi-tab use. Background indexing allowed."
      },
      performance: {
        floodWorkers: 4,
        searchResults: 9,
        concurrentStreams: 4,
        backgroundIndexing: true,
        description: "Parallel agents, faster preloading, larger caches."
      }
    };
  }
});

// src/db/schema.ts
var schema_exports = {};
__export(schema_exports, {
  chats: () => chats,
  citations: () => citations,
  documents: () => documents,
  messages: () => messages,
  skills: () => skills
});
import { sqliteTable, text, integer } from "drizzle-orm/sqlite-core";
var chats, messages, documents, skills, citations;
var init_schema = __esm({
  "src/db/schema.ts"() {
    "use strict";
    chats = sqliteTable("chats", {
      id: text("id").primaryKey(),
      title: text("title").notNull(),
      spaceId: text("space_id"),
      createdAt: integer("created_at").notNull(),
      updatedAt: integer("updated_at").notNull()
    });
    messages = sqliteTable("messages", {
      id: text("id").primaryKey(),
      chatId: text("chat_id").notNull(),
      role: text("role").notNull(),
      content: text("content").notNull(),
      model: text("model"),
      createdAt: integer("created_at").notNull()
    });
    documents = sqliteTable("documents", {
      id: text("id").primaryKey(),
      name: text("name").notNull(),
      kind: text("kind").notNull(),
      text: text("text").notNull(),
      addedAt: integer("added_at").notNull()
    });
    skills = sqliteTable("skills", {
      id: text("id").primaryKey(),
      name: text("name").notNull(),
      json: text("json").notNull()
    });
    citations = sqliteTable("citations", {
      id: text("id").primaryKey(),
      title: text("title").notNull(),
      url: text("url").notNull(),
      collection: text("collection"),
      savedAt: integer("saved_at").notNull()
    });
  }
});

// src/db/index.ts
function safeJson(text2, fallback) {
  try {
    return JSON.parse(text2);
  } catch {
    return fallback;
  }
}
function dbStats() {
  return sqlite ? { engine, file: process.env.DB_PATH ?? "./research-engine.db" } : { engine: "memory" };
}
var MIGRATION, sqlite, engine, dbPath, mem, db;
var init_db = __esm({
  async "src/db/index.ts"() {
    "use strict";
    init_schema();
    MIGRATION = `
CREATE TABLE IF NOT EXISTS chats (id TEXT PRIMARY KEY, title TEXT, space_id TEXT, created_at INTEGER, updated_at INTEGER);
CREATE TABLE IF NOT EXISTS messages (id TEXT PRIMARY KEY, chat_id TEXT, role TEXT, content TEXT, model TEXT, created_at INTEGER);
CREATE TABLE IF NOT EXISTS documents (id TEXT PRIMARY KEY, name TEXT, kind TEXT, text TEXT, added_at INTEGER);
CREATE TABLE IF NOT EXISTS skills (id TEXT PRIMARY KEY, name TEXT, json TEXT);
CREATE TABLE IF NOT EXISTS citations (id TEXT PRIMARY KEY, title TEXT, url TEXT, collection TEXT, saved_at INTEGER);
CREATE TABLE IF NOT EXISTS feedback (id TEXT PRIMARY KEY, kind TEXT, text TEXT, contact TEXT, app_version TEXT, created_at INTEGER);
CREATE TABLE IF NOT EXISTS library_items (id TEXT PRIMARY KEY, kind TEXT, title TEXT, url TEXT, snippet TEXT, tags TEXT, folder_id TEXT, saved_at INTEGER, extra TEXT);
CREATE TABLE IF NOT EXISTS library_folders (id TEXT PRIMARY KEY, name TEXT, created_at INTEGER);
`;
    sqlite = null;
    engine = "memory";
    dbPath = process.env.DB_PATH ?? "./research-engine.db";
    try {
      const specifier = "better-sqlite3";
      const Database = (await import(specifier)).default;
      sqlite = new Database(dbPath);
      sqlite.pragma("journal_mode = WAL");
      sqlite.exec(MIGRATION);
      engine = "sqlite (better-sqlite3)";
    } catch {
      try {
        const { DatabaseSync } = await import("node:sqlite");
        sqlite = new DatabaseSync(dbPath);
        sqlite.exec("PRAGMA journal_mode = WAL");
        sqlite.exec(MIGRATION);
        engine = "sqlite (node:sqlite)";
      } catch (e2) {
        console.warn("[re] no SQLite driver available \u2014 using in-memory fallback (data will not survive a restart). (" + e2.message + ")");
      }
    }
    mem = {
      chats: /* @__PURE__ */ new Map(),
      documents: /* @__PURE__ */ new Map(),
      feedback: /* @__PURE__ */ new Map(),
      libraryItems: /* @__PURE__ */ new Map(),
      libraryFolders: /* @__PURE__ */ new Map()
    };
    db = {
      schema: schema_exports,
      insertChat(chat) {
        if (sqlite) sqlite.prepare("INSERT OR REPLACE INTO chats VALUES (?,?,?,?,?)").run(chat.id, chat.title, chat.spaceId ?? null, chat.createdAt, chat.updatedAt);
        else mem.chats.set(chat.id, chat);
      },
      insertDocument(doc) {
        if (sqlite) sqlite.prepare("INSERT OR REPLACE INTO documents VALUES (?,?,?,?,?)").run(doc.id, doc.name, doc.kind, doc.text, doc.addedAt);
        else mem.documents.set(doc.id, doc);
      },
      listDocuments() {
        if (sqlite) return sqlite.prepare("SELECT id, name, kind, added_at as addedAt FROM documents ORDER BY added_at DESC").all();
        return [...mem.documents.values()];
      },
      /* ---------------------------------------------------------- feedback ---- */
      // Kept on the user's own machine, in the same database as everything else:
      // "send feedback" here means "write it down", not "post it somewhere".
      insertFeedback(f) {
        if (sqlite) sqlite.prepare("INSERT OR REPLACE INTO feedback VALUES (?,?,?,?,?,?)").run(f.id, f.kind, f.text, f.contact ?? null, f.appVersion ?? null, f.createdAt);
        else mem.feedback.set(f.id, f);
      },
      listFeedback() {
        if (sqlite) return sqlite.prepare("SELECT id, kind, text, contact, app_version as appVersion, created_at as createdAt FROM feedback ORDER BY created_at DESC").all();
        return [...mem.feedback.values()].sort((a, b) => b.createdAt - a.createdAt);
      },
      deleteFeedback(id) {
        if (sqlite) sqlite.prepare("DELETE FROM feedback WHERE id = ?").run(id);
        else mem.feedback.delete(id);
      },
      /* ----------------------------------------------------- library items --- */
      insertLibraryItem(it) {
        if (sqlite) sqlite.prepare("INSERT OR REPLACE INTO library_items VALUES (?,?,?,?,?,?,?,?,?)").run(
          it.id,
          it.kind,
          it.title,
          it.url ?? null,
          it.snippet ?? null,
          JSON.stringify(it.tags ?? []),
          it.folderId ?? null,
          it.savedAt,
          JSON.stringify(it.extra ?? null)
        );
        else mem.libraryItems.set(it.id, it);
      },
      listLibraryItems() {
        const rows = sqlite ? sqlite.prepare("SELECT id, kind, title, url, snippet, tags, folder_id as folderId, saved_at as savedAt, extra FROM library_items ORDER BY saved_at DESC").all() : [...mem.libraryItems.values()].sort((a, b) => b.savedAt - a.savedAt);
        return rows.map((r) => ({
          ...r,
          tags: typeof r.tags === "string" ? safeJson(r.tags, []) : r.tags ?? [],
          extra: typeof r.extra === "string" ? safeJson(r.extra, null) : r.extra ?? null
        }));
      },
      deleteLibraryItem(id) {
        if (sqlite) sqlite.prepare("DELETE FROM library_items WHERE id = ?").run(id);
        else mem.libraryItems.delete(id);
      },
      insertLibraryFolder(f) {
        if (sqlite) sqlite.prepare("INSERT OR REPLACE INTO library_folders VALUES (?,?,?)").run(f.id, f.name, f.createdAt);
        else mem.libraryFolders.set(f.id, f);
      },
      listLibraryFolders() {
        if (sqlite) return sqlite.prepare("SELECT id, name, created_at as createdAt FROM library_folders ORDER BY created_at ASC").all();
        return [...mem.libraryFolders.values()];
      },
      deleteLibraryFolder(id) {
        if (sqlite) {
          sqlite.prepare("DELETE FROM library_folders WHERE id = ?").run(id);
          sqlite.prepare("UPDATE library_items SET folder_id = NULL WHERE folder_id = ?").run(id);
        } else mem.libraryFolders.delete(id);
      }
    };
  }
});

// src/routes/health.ts
var health_exports = {};
__export(health_exports, {
  healthRoutes: () => healthRoutes,
  installMode: () => installMode,
  sourceVersion: () => sourceVersion,
  webBuild: () => webBuild
});
import { Hono as Hono3 } from "hono";
function healthRoutes(frontendDist) {
  const app = new Hono3();
  app.get(
    "/health",
    (c) => c.json({
      ok: true,
      service: "research-engine-backend",
      time: (/* @__PURE__ */ new Date()).toISOString(),
      db: dbStats(),
      // Frontend fingerprint, so the UI can warn about a stale self-hosted copy.
      web: { served: webBuild(frontendDist), source: sourceVersion(), mode: installMode() },
      // Which OS and Node this server actually runs on. Platform-specific bugs
      // (a Windows path separator, a missing POSIX binary) are invisible until
      // someone names the platform, so the diagnostics report carries it.
      runtime: {
        platform: process.platform,
        arch: process.arch,
        node: process.version,
        pathSep: process.platform === "win32" ? "\\" : "/"
      }
    })
  );
  return app;
}
var init_health = __esm({
  async "src/routes/health.ts"() {
    "use strict";
    await init_db();
    init_build_info();
    init_build_info();
  }
});

// src/routes/feedback.ts
var feedback_exports = {};
__export(feedback_exports, {
  feedbackRoutes: () => feedbackRoutes
});
import { Hono as Hono4 } from "hono";
var feedbackRoutes, KINDS;
var init_feedback = __esm({
  async "src/routes/feedback.ts"() {
    "use strict";
    await init_db();
    feedbackRoutes = new Hono4();
    KINDS = /* @__PURE__ */ new Set(["bug", "idea", "ui", "performance", "other"]);
    feedbackRoutes.post("/", async (c) => {
      const body = await c.req.json().catch(() => ({}));
      const text2 = String(body?.text ?? "").trim();
      if (text2.length < 3) return c.json({ error: "Feedback needs at least a few words." }, 400);
      if (text2.length > 8e3) return c.json({ error: "That is longer than this box is meant for (8000 characters)." }, 400);
      const kind = KINDS.has(String(body?.kind)) ? String(body.kind) : "other";
      const entry = {
        id: String(body?.id ?? `fb_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`),
        kind,
        text: text2,
        contact: body?.contact ? String(body.contact).slice(0, 200) : void 0,
        appVersion: body?.appVersion ? String(body.appVersion).slice(0, 40) : void 0,
        createdAt: Number(body?.createdAt) || Date.now()
      };
      db.insertFeedback(entry);
      return c.json({ ok: true, entry });
    });
    feedbackRoutes.get("/", (c) => c.json({ feedback: db.listFeedback() }));
    feedbackRoutes.delete("/:id", (c) => {
      db.deleteFeedback(c.req.param("id"));
      return c.json({ ok: true });
    });
  }
});

// src/services/search/adapters.ts
function withTimeout(ms, signal) {
  const t = AbortSignal.timeout(ms);
  if (!signal) return t;
  const ctrl = new AbortController();
  const abort = () => ctrl.abort();
  signal.addEventListener("abort", abort);
  t.addEventListener("abort", abort);
  return ctrl.signal;
}
function hostOf(url) {
  try {
    return new URL(url).hostname;
  } catch {
    return url;
  }
}
async function searchSearxng(base, q, timeoutMs = DEFAULT_TIMEOUT) {
  const url = `${base.replace(/\/$/, "")}/search?q=${encodeURIComponent(q)}&format=json&safesearch=0`;
  const res = await fetch(url, {
    headers: { accept: "application/json", "user-agent": "research-engine/1 (+self-hosted)" },
    signal: withTimeout(timeoutMs)
  });
  if (!res.ok) throw new Error(`SearXNG responded ${res.status}`);
  const json = await res.json().catch(() => null);
  if (!json || !Array.isArray(json.results)) throw new Error("SearXNG did not return JSON results");
  return (json.results ?? []).filter((r) => r?.url).slice(0, 8).map((r) => ({
    title: r.title || r.url,
    url: r.url,
    snippet: r.content ?? "",
    domain: hostOf(r.url)
  }));
}
async function searchSearxngAuto(q, opts = {}) {
  const candidates = [];
  if (opts.own) candidates.push(opts.own);
  if (preferred && Date.now() - preferred.at < PREFERRED_TTL) candidates.push(preferred.url);
  for (const url of [opts.own ? null : "http://localhost:8080", ...PUBLIC_SEARXNG]) {
    if (url && !candidates.includes(url)) candidates.push(url);
  }
  const perTry = opts.timeoutMs ?? 6e3;
  const limit = Math.max(1, Math.min(opts.timeouts ?? candidates.length, candidates.length));
  let lastError = null;
  for (const url of candidates.slice(0, limit)) {
    try {
      const results = await searchSearxng(url, q, perTry);
      if (results.length) {
        preferred = { url, at: Date.now() };
        return { results, instance: url };
      }
    } catch (e) {
      lastError = e;
    }
  }
  throw lastError ?? new Error("No SearXNG instance answered");
}
async function searchBrave(q, key, timeoutMs = DEFAULT_TIMEOUT) {
  const token = key || process.env.BRAVE_API_KEY;
  if (!token) throw new Error("No Brave key \u2014 paste one in Settings \u2192 Search, or set BRAVE_API_KEY");
  const res = await fetch(`https://api.search.brave.com/res/v1/web/search?q=${encodeURIComponent(q)}&count=8`, {
    headers: { "X-Subscription-Token": token, accept: "application/json" },
    signal: withTimeout(timeoutMs)
  });
  if (!res.ok) throw new Error(`Brave responded ${res.status}`);
  const json = await res.json();
  return (json.web?.results ?? []).slice(0, 8).map((r) => ({
    title: r.title,
    url: r.url,
    snippet: r.description ?? "",
    domain: hostOf(r.url)
  }));
}
async function searchSerper(q, key, timeoutMs = DEFAULT_TIMEOUT) {
  const token = key || process.env.SERPER_API_KEY;
  if (!token) throw new Error("No Serper key \u2014 paste one in Settings \u2192 Search, or set SERPER_API_KEY");
  const res = await fetch("https://google.serper.dev/search", {
    method: "POST",
    headers: { "X-API-KEY": token, "content-type": "application/json" },
    body: JSON.stringify({ q }),
    signal: withTimeout(timeoutMs)
  });
  if (!res.ok) throw new Error(`Serper responded ${res.status}`);
  const json = await res.json();
  return (json.organic ?? []).slice(0, 8).map((r) => ({
    title: r.title,
    url: r.link,
    snippet: r.snippet ?? "",
    domain: hostOf(r.link)
  }));
}
async function searchTavily(q, key, timeoutMs = DEFAULT_TIMEOUT) {
  const token = key || process.env.TAVILY_API_KEY;
  if (!token) throw new Error("No Tavily key \u2014 paste one in Settings \u2192 Search, or set TAVILY_API_KEY");
  const res = await fetch("https://api.tavily.com/search", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ api_key: token, query: q, max_results: 8 }),
    signal: withTimeout(timeoutMs)
  });
  if (!res.ok) throw new Error(`Tavily responded ${res.status}`);
  const json = await res.json();
  return (json.results ?? []).slice(0, 8).map((r) => ({
    title: r.title,
    url: r.url,
    snippet: r.content ?? "",
    domain: hostOf(r.url)
  }));
}
async function searchDdg(q, timeoutMs = DEFAULT_TIMEOUT) {
  const res = await fetch(`https://html.duckduckgo.com/html/?q=${encodeURIComponent(q)}`, {
    headers: { "user-agent": "Mozilla/5.0 (Research Engine)" },
    signal: withTimeout(timeoutMs)
  });
  if (!res.ok) throw new Error(`DuckDuckGo responded ${res.status}`);
  const html = await res.text();
  const out = [];
  const re = /<a[^>]+class="result__a"[^>]+href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/g;
  let m;
  while ((m = re.exec(html)) && out.length < 8) {
    const url = decodeURIComponent(m[1].replace(/^.*uddg=/, "").replace(/&rut=.*$/, ""));
    const title = m[2].replace(/<[^>]+>/g, "").trim();
    if (url.startsWith("http")) out.push({ title, url, snippet: "", domain: hostOf(url) });
  }
  if (!out.length) throw new Error("DuckDuckGo returned no parsable results");
  return out;
}
function searchDemo(q) {
  const domains = ["arxiv.org", "nature.com", "wikipedia.org", "acm.org", "ncbi.nlm.nih.gov"];
  return domains.map((d, i) => ({
    title: `${q} \u2014 result ${i + 1}`,
    url: `https://${d}/${encodeURIComponent(q.toLowerCase().replace(/\s+/g, "-"))}`,
    snippet: `Demo result for "${q}" (offline mode or no reachable engine).`,
    domain: d
  }));
}
async function searchStatus(keys, own) {
  const instances = [...own ? [own] : [], "http://localhost:8080", ...PUBLIC_SEARXNG];
  const probes = await Promise.all(instances.map(async (url) => {
    try {
      const res = await fetch(`${url.replace(/\/$/, "")}/search?q=research&format=json`, {
        headers: { accept: "application/json" },
        signal: withTimeout(4e3)
      });
      return { url, reachable: res.ok };
    } catch {
      return { url, reachable: false };
    }
  }));
  let ddg = false;
  try {
    const res = await fetch("https://html.duckduckgo.com/html/?q=research", {
      headers: { "user-agent": "Mozilla/5.0 (Research Engine)" },
      signal: withTimeout(4e3)
    });
    ddg = res.ok;
  } catch {
    ddg = false;
  }
  return {
    searxng: probes,
    ddg,
    keys: {
      brave: !!(keys.brave || process.env.BRAVE_API_KEY),
      serper: !!(keys.serper || process.env.SERPER_API_KEY),
      tavily: !!(keys.tavily || process.env.TAVILY_API_KEY)
    }
  };
}
var DEFAULT_TIMEOUT, PUBLIC_SEARXNG, preferred, PREFERRED_TTL;
var init_adapters = __esm({
  "src/services/search/adapters.ts"() {
    "use strict";
    DEFAULT_TIMEOUT = 8e3;
    PUBLIC_SEARXNG = [
      "https://searx.be",
      "https://search.inetol.net",
      "https://baresearch.org",
      "https://search.rhscz.eu",
      "https://priv.au",
      "https://searxng.site",
      "https://opnxng.com"
    ];
    preferred = null;
    PREFERRED_TTL = 5 * 60 * 1e3;
  }
});

// src/services/reader/html.ts
function titleOf(html) {
  const og = html.match(/<meta[^>]+property=["']og:title["'][^>]*content=["']([^"']+)/i)?.[1];
  if (og) return decodeEntities2(og).trim();
  const t = html.match(/<title[^>]*>([\s\S]{0,300}?)<\/title>/i)?.[1];
  return t ? decodeEntities2(t).trim() : void 0;
}
function metaOf(html, patterns) {
  for (const p of patterns) {
    const m = html.match(p);
    if (m?.[1]) return decodeEntities2(m[1]).trim().slice(0, 300);
  }
  return void 0;
}
function htmlToBlocks(html, base) {
  let body = html;
  const bodyMatch = html.match(/<body[^>]*>([\s\S]*)<\/body>/i);
  if (bodyMatch) body = bodyMatch[1];
  const before = body.length;
  body = body.replace(CHROME, " ").replace(/<!--[\s\S]*?-->/g, " ");
  const dropped = before - body.length > before * 0.35;
  const regions = body.split(/<(?:article|main|section|div)\b[^>]*>/i);
  let best = body;
  let bestScore = 0;
  for (const region of regions) {
    const text2 = strip(region);
    if (text2.length < 200) continue;
    const score = text2.length / Math.max(1, region.length);
    if (score > bestScore) {
      bestScore = score;
      best = region;
    }
  }
  if (bestScore === 0) best = body;
  const blocks = [];
  const outline = [];
  let headingIndex = 0;
  let lastWasItem = false;
  let itemBuffer = [];
  const flushItems = () => {
    if (itemBuffer.length) {
      blocks.push({ type: "list", items: itemBuffer });
      itemBuffer = [];
    }
  };
  BLOCK_RE.lastIndex = 0;
  let m;
  while (m = BLOCK_RE.exec(best)) {
    const tag = m[1].toLowerCase();
    const text2 = strip(m[2]);
    if (!text2 || text2.length < 2) {
      lastWasItem = false;
      continue;
    }
    if (tag === "li") {
      if (text2.length >= 40 || /[.!?:]$/.test(text2)) {
        itemBuffer.push(text2);
        lastWasItem = true;
      }
      continue;
    }
    flushItems();
    lastWasItem = false;
    if (tag.startsWith("h")) {
      const level = Math.min(3, Math.max(1, Number(tag[1]) - 1));
      const id = slug(text2, headingIndex++);
      blocks.push({ type: "heading", level, text: text2, id });
      outline.push({ id, text: text2, level });
    } else if (tag === "blockquote") {
      blocks.push({ type: "quote", text: text2 });
    } else if (tag === "pre") {
      blocks.push({ type: "code", text: decodeEntities2(m[2].replace(/<[^>]*>/g, "")) });
    } else {
      if (text2.length < 25) continue;
      blocks.push({ type: "paragraph", text: text2 });
    }
  }
  flushItems();
  if (blocks.length === 0) {
    const text2 = strip(best);
    for (const para of text2.split(/(?<=\.)\s{2,}/)) {
      const p = para.trim();
      if (p.length > 60) blocks.push({ type: "paragraph", text: p });
    }
  }
  const images = [];
  const imgRe = /<img[^>]+src=["']([^"']+)["'][^>]*>/gi;
  let img;
  while ((img = imgRe.exec(best)) && images.length < 12) {
    const src = img[1];
    if (/\.(svg|gif)($|\?)/i.test(src) || /sprite|icon|logo|avatar|pixel|1x1/i.test(src)) continue;
    const alt = img[0].match(/alt=["']([^"']*)/i)?.[1];
    try {
      images.push({ src: new URL(src, base).toString(), alt: alt ? decodeEntities2(alt) : void 0 });
    } catch {
    }
  }
  return { blocks, outline, images, dropped };
}
function looksLikeAppShell(html, blocks) {
  const textLength = blocks.reduce((n, b) => n + (b.type === "paragraph" ? b.text.length : b.type === "quote" ? b.text.length : 0), 0);
  if (textLength > 900) return false;
  const scriptBytes = (html.match(/<script[\s\S]*?<\/script>/gi) ?? []).join("").length;
  return scriptBytes > html.length * 0.35 || /<div id=["'](root|app|__next)["']\s*>\s*<\/div>/i.test(html);
}
var decodeEntities2, strip, CHROME, BLOCK_RE, slug;
var init_html = __esm({
  "src/services/reader/html.ts"() {
    "use strict";
    decodeEntities2 = (s) => s.replace(/&(nbsp|#160);/gi, " ").replace(/&(amp|#38);/gi, "&").replace(/&(lt|#60);/gi, "<").replace(/&(gt|#62);/gi, ">").replace(/&(quot|#34);/gi, '"').replace(/&(#39|apos|rsquo|lsquo);/gi, "'").replace(/&(mdash|#8212);/gi, "\u2014").replace(/&(ndash|#8211);/gi, "\u2013").replace(/&(hellip|#8230);/gi, "\u2026").replace(/&#x([0-9a-f]+);/gi, (_m, hex) => String.fromCodePoint(parseInt(hex, 16))).replace(/&#(\d+);/g, (_m, n) => String.fromCodePoint(Number(n)));
    strip = (s) => decodeEntities2(s.replace(/<[^>]*>/g, " ")).replace(/\s+/g, " ").trim();
    CHROME = /<(nav|footer|header|aside|form|script|style|noscript|svg|iframe|template|button|select)\b[\s\S]*?<\/\1>/gi;
    BLOCK_RE = /<(h[1-6]|p|li|blockquote|pre)\b[^>]*>([\s\S]*?)<\/\1>/gi;
    slug = (s, i) => s.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "").slice(0, 60) || `s-${i}`;
  }
});

// src/services/reader/extract.ts
function parseTarget2(raw) {
  try {
    const u = new URL(raw);
    if (u.protocol !== "http:" && u.protocol !== "https:") return null;
    const host2 = u.hostname.toLowerCase().replace(/^\[|\]$/g, "");
    if (host2 === "localhost" || host2.endsWith(".localhost") || host2 === "::1" || host2.endsWith(".internal") || host2.endsWith(".local")) return null;
    if (/^\d+\.\d+\.\d+\.\d+$/.test(host2)) {
      const [a, b] = host2.split(".").map(Number);
      if (a === 10 || a === 127 || a === 0 || a === 192 && b === 168 || a === 172 && b >= 16 && b <= 31 || a === 169 && b === 254) return null;
    }
    if (host2.includes(":")) {
      if (host2 === "::" || host2.startsWith("fe80") || host2.startsWith("fc") || host2.startsWith("fd")) return null;
    }
    return u;
  } catch {
    return null;
  }
}
async function readWikipedia(u) {
  const lang = (u.hostname.split(".")[0] || "en").replace(/[^a-z-]/gi, "");
  const title = decodeURIComponent(u.pathname.replace(/^\/wiki\//, ""));
  if (!title) return null;
  const api = `https://${lang}.wikipedia.org/w/api.php?action=query&format=json&prop=extracts|pageimages|info&inprop=url&explaintext=1&exsectionformat=wiki&piprop=original|thumbnail&pithumbsize=1000&redirects=1&titles=${encodeURIComponent(title)}`;
  const res = await fetch(api, { headers: { "user-agent": UA2, accept: "application/json" }, signal: AbortSignal.timeout(TIMEOUT2) });
  if (!res.ok) return null;
  const json = await res.json().catch(() => null);
  const page = json?.query?.pages ? Object.values(json.query.pages)[0] : null;
  const extract = page?.extract ?? "";
  if (!extract.trim()) return null;
  const blocks = [];
  const outline = [];
  let current = "";
  let pendingHeading = null;
  let sectionIndex = 0;
  const flush = () => {
    const text2 = current.trim();
    current = "";
    if (!text2) return;
    if (pendingHeading) {
      const id = slug2(pendingHeading.text, sectionIndex++);
      blocks.push({ type: "heading", level: pendingHeading.level, text: pendingHeading.text, id });
      outline.push({ id, text: pendingHeading.text, level: pendingHeading.level });
      pendingHeading = null;
    }
    for (const para of text2.split(/\n{2,}/)) {
      const p = para.trim();
      if (!p) continue;
      if (/^[*-]\s/.test(p)) {
        blocks.push({ type: "list", items: p.split("\n").map((l) => l.replace(/^[*-]\s*/, "").trim()).filter(Boolean) });
      } else if (/^\|/.test(p) || /^\{/.test(p) || /^\}/.test(p)) {
        continue;
      } else {
        blocks.push({ type: "paragraph", text: p.replace(/\n+/g, " ") });
      }
    }
  };
  for (const line of extract.split("\n")) {
    const h = line.match(/^\s*(={2,6})\s*(.+?)\s*\1\s*$/);
    if (h) {
      flush();
      pendingHeading = { level: Math.min(3, Math.max(1, h[1].length - 1)), text: h[2] };
      continue;
    }
    current += line + "\n";
  }
  flush();
  const words = blocks.reduce((n, b) => n + (b.type === "paragraph" ? b.text.split(/\s+/).length : b.type === "list" ? b.items.join(" ").split(/\s+/).length : 0), 0);
  const image = page?.original?.source ?? page?.thumbnail?.source;
  return {
    ok: true,
    url: u.toString(),
    via: "wikipedia-api",
    title: page?.title ?? title.replace(/_/g, " "),
    siteName: `${lang}.wikipedia.org`,
    wordCount: words,
    minutes: Math.max(1, Math.round(words / 220)),
    blocks,
    outline,
    images: image ? [{ src: image, alt: page?.title }] : [],
    fetchedAt: Date.now()
  };
}
async function readHtml(u) {
  const res = await fetch(u.toString(), {
    headers: { "user-agent": UA2, accept: "text/html,application/xhtml+xml" },
    redirect: "follow",
    signal: AbortSignal.timeout(TIMEOUT2)
  });
  const type = res.headers.get("content-type") ?? "";
  if (!/text\/html|application\/xhtml/.test(type)) {
    return failed(u, `That address answered with ${type || "an unknown type"}, which is not a web page the reader can typeset.`);
  }
  const raw = await res.text();
  const html = raw.length > MAX_BYTES ? raw.slice(0, MAX_BYTES) : raw;
  const { blocks, outline, images, dropped } = htmlToBlocks(html, u);
  const words = blocks.reduce((n, b) => n + (b.type === "paragraph" ? b.text.split(/\s+/).length : b.type === "list" ? b.items.join(" ").split(/\s+/).length : b.type === "quote" ? b.text.split(/\s+/).length : 0), 0);
  const interactive = looksLikeAppShell(html, blocks);
  const warning = interactive ? "This page builds itself with JavaScript, so the reader can only show what the server sent. The browser view is the honest one for this site." : dropped && words < 120 ? "Very little text was found on this page \u2014 it may be a gallery, a login wall or a script-only app." : void 0;
  return {
    ok: words > 0,
    url: u.toString(),
    via: "html",
    title: titleOf(html) ?? u.hostname,
    byline: metaOf(html, [/name=["']author["'][^>]*content=["']([^"']+)/i, /property=["']article:author["'][^>]*content=["']([^"']+)/i]),
    siteName: metaOf(html, [/property=["']og:site_name["'][^>]*content=["']([^"']+)/i]) ?? u.hostname,
    published: metaOf(html, [/property=["']article:published_time["'][^>]*content=["']([^"']+)/i, /name=["']date["'][^>]*content=["']([^"']+)/i]),
    wordCount: words,
    minutes: Math.max(1, Math.round(words / 220)),
    blocks,
    outline,
    images,
    warning: warning ?? (words === 0 ? "No readable text was found. The browser view should still work." : void 0),
    interactive,
    fetchedAt: Date.now()
  };
}
function failed(u, warning) {
  return {
    ok: false,
    url: u.toString(),
    via: "html",
    title: u.hostname,
    siteName: u.hostname,
    wordCount: 0,
    minutes: 0,
    blocks: [],
    outline: [],
    images: [],
    warning,
    fetchedAt: Date.now()
  };
}
async function readSource(raw) {
  const hit = cache4.get(raw);
  if (hit && Date.now() - hit.at < CACHE_TTL2) return hit.result;
  const u = parseTarget2(raw);
  if (!u) {
    return { ...failed({ hostname: "invalid" }, "That address cannot be fetched: only public http(s) links can be read."), url: raw };
  }
  try {
    const result = (isWikipedia(u) ? await readWikipedia(u) : null) ?? await readHtml(u);
    cache4.set(raw, { at: Date.now(), result });
    if (cache4.size > 60) cache4.delete(cache4.keys().next().value);
    return result;
  } catch (e) {
    const reason = e?.name === "TimeoutError" ? "The site did not answer in time." : /ENOTFOUND|EAI_AGAIN/.test(String(e?.cause?.code ?? "")) ? "That host could not be resolved from this machine." : `The page could not be fetched (${String(e?.message ?? e)}).`;
    const result = { ...failed(u, reason), via: "html" };
    cache4.set(raw, { at: Date.now(), result });
    return result;
  }
}
var UA2, TIMEOUT2, MAX_BYTES, isWikipedia, slug2, cache4, CACHE_TTL2;
var init_extract = __esm({
  "src/services/reader/extract.ts"() {
    "use strict";
    init_html();
    UA2 = "ResearchEngine/0.37 (+library reader; respects robots.txt)";
    TIMEOUT2 = 12e3;
    MAX_BYTES = 3e6;
    isWikipedia = (u) => /(^|\.)wikipedia\.org$/.test(u.hostname) || /(^|\.)wikimedia\.org$/.test(u.hostname);
    slug2 = (s, i) => s.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "").slice(0, 60) || `section-${i}`;
    cache4 = /* @__PURE__ */ new Map();
    CACHE_TTL2 = 15 * 60 * 1e3;
  }
});

// src/services/reader/mini.ts
async function web(q) {
  const viaSearx = await searchSearxngAuto(q, { timeouts: 2, timeoutMs: 4e3 }).catch(() => null);
  const found = viaSearx?.results?.length ? viaSearx.results : await searchDdg(q, TIMEOUT3);
  return found.map((s, i) => ({
    id: `web-${i}`,
    vertical: "web",
    title: s.title,
    url: s.url,
    snippet: s.snippet,
    source: host(s.url) || "web"
  }));
}
async function wikipedia(q) {
  const url = `https://en.wikipedia.org/w/api.php?action=query&list=search&srsearch=${encodeURIComponent(q)}&srlimit=6&format=json&origin=*`;
  const res = await fetch(url, { headers: { "user-agent": UA3, accept: "application/json" }, signal: AbortSignal.timeout(TIMEOUT3) });
  if (!res.ok) throw new Error(`Wikipedia answered HTTP ${res.status}`);
  const json = await res.json();
  return (json?.query?.search ?? []).map((r) => ({
    id: `wiki-${r.pageid}`,
    vertical: "wikipedia",
    title: r.title,
    url: `https://en.wikipedia.org/?curid=${r.pageid}`,
    snippet: String(r.snippet ?? "").replace(/<[^>]*>/g, ""),
    source: "Wikipedia",
    action: "read"
  }));
}
function screens(q) {
  const t = encodeURIComponent(q.trim());
  const slug3 = encodeURIComponent(q.trim().toLowerCase().replace(/\s+/g, "-"));
  return [
    { id: "scr-aw", vertical: "screens", title: `Awwwards \u2014 ${q}`, url: `https://www.awwwards.com/websites/?text=${t}`, source: "awwwards.com", snippet: "Awarded sites, judged on design \u2014 the reference for what is currently considered good." },
    { id: "scr-dr", vertical: "screens", title: `Dribbble \u2014 ${q}`, url: `https://dribbble.com/search/shots?q=${t}`, source: "dribbble.com", snippet: "Interface shots and explorations, useful for a specific pattern rather than a whole site." },
    { id: "scr-uc", vertical: "screens", title: `unicorn.studio \u2014 ${q}`, url: `https://unicorn.studio/?q=${t}`, source: "unicorn.studio", snippet: "WebGL and shader-driven interaction references." },
    { id: "scr-rf", vertical: "screens", title: `Refero \u2014 ${q}`, url: `https://refero.design/?q=${t}`, source: "refero.design", snippet: 'Real app screens, sorted by page type and flow \u2014 the closest thing to "how do apps do this".' },
    { id: "scr-mb", vertical: "ui", title: `Mobbin \u2014 ${q}`, url: `https://mobbin.com/search/${slug3}`, source: "mobbin.com", snippet: "Screens from shipping mobile apps, by pattern." }
  ];
}
function interfaces(q) {
  const t = q.trim();
  const lower = t.toLowerCase();
  const pattern = /(screen|page|flow|onboard|sign ?up|sign ?in|login|checkout|pricing|paywall|dashboard|settings|profile|feed|empty state|search|filter|table|card|list|detail|modal|sheet|wizard|notification|calendar|chat)/i.test(lower);
  const hits = [
    { id: "ui-ref", vertical: "ui", title: `App screens for \u201C${t}\u201D \u2014 Refero`, url: `https://refero.design/?q=${encodeURIComponent(t)}`, source: "refero.design", snippet: 'Filtered by page type, so this answers "how does a real app lay this out".', action: "open" },
    { id: "ui-mob", vertical: "ui", title: `Mobile screens for \u201C${t}\u201D \u2014 Mobbin`, url: `https://mobbin.com/search/${encodeURIComponent(lower.replace(/\s+/g, "-"))}`, source: "mobbin.com", snippet: "Shipping apps, iOS and Android, screenshotted by flow.", action: "open" },
    { id: "ui-hub", vertical: "ui", title: `Components for \u201C${t}\u201D in the design hub`, url: "app://design-hub", source: "Research Engine \xB7 Design hub", snippet: "Thirty registries, searched locally \u2014 open Design Mode \u2192 Components and the query is already there.", action: "open" }
  ];
  const note = pattern ? "Read as a screen request: the pattern you named is what these libraries index by." : "Tip: naming the pattern (\u201Cpricing table\u201D, \u201Conboarding\u201D, \u201Cempty state\u201D) gives sharper screen results than naming a technology.";
  return { hits, note };
}
function docs(q) {
  const words = q.toLowerCase().split(/\s+/).filter(Boolean);
  return DOCS_INDEX.map((d) => {
    const hay = `${d.title} ${d.keys} ${d.what}`.toLowerCase();
    const score = words.reduce((n, w) => n + (hay.includes(w) ? 1 : 0), 0);
    return { d, score };
  }).filter((x) => x.score > 0).sort((a, b) => b.score - a.score).slice(0, 4).map(({ d }) => ({
    id: `doc-${d.title}`,
    vertical: "docs",
    title: d.title,
    url: d.keys.includes("mdn") ? d.url + encodeURIComponent(q) : d.url,
    source: host(d.url) || "docs",
    snippet: d.what
  }));
}
async function lane(vertical, run2, noteFor) {
  const t0 = Date.now();
  try {
    const hits = await run2();
    const note = noteFor?.(hits.length);
    return { vertical, label: LABEL[vertical], state: hits.length ? "ok" : "empty", ms: Date.now() - t0, hits, note };
  } catch (e) {
    const reason = e?.name === "TimeoutError" ? `${LABEL[vertical]} did not answer in time.` : `${LABEL[vertical]} could not be reached (${String(e?.message ?? e)}).`;
    return empty(vertical, Date.now() - t0, reason);
  }
}
async function miniSearch(query) {
  const q = query.trim();
  const cached = cache5.get(q);
  const pending = [];
  if (cached && Date.now() - cached.at < CACHE_TTL3) {
    return { query: q, results: cached.results, tookMs: 0, pending: [] };
  }
  const uiRun = interfaces(q);
  const local = [
    { vertical: "screens", label: LABEL.screens, state: "ok", ms: 0, hits: screens(q), note: "Opens in the source viewer\u2019s browser tab \u2014 these catalogues are searched by their own URLs, nothing is scraped." },
    { vertical: "ui", label: LABEL.ui, state: "ok", ms: 0, hits: uiRun.hits, note: uiRun.note },
    { vertical: "docs", label: LABEL.docs, state: "ok", ms: 0, hits: docs(q), note: "A small curated index, not a crawler \u2014 these are the pages people actually open while building." }
  ];
  const remote = Promise.all([
    lane("wikipedia", () => wikipedia(q)),
    lane("web", () => web(q))
  ]).then((res) => {
    const merged = [...local, ...res];
    cache5.set(q, { at: Date.now(), results: merged });
    if (cache5.size > 40) cache5.delete(cache5.keys().next().value);
    return merged;
  });
  remote.catch(() => {
  });
  const settled = await Promise.race([
    remote,
    new Promise((resolve10) => setTimeout(() => resolve10(null), BUDGET_MS))
  ]);
  if (settled) return { query: q, results: settled, tookMs: BUDGET_MS, pending: [] };
  return { query: q, results: local, tookMs: BUDGET_MS, pending: ["wikipedia", "web"] };
}
var UA3, TIMEOUT3, LABEL, host, DOCS_INDEX, BUDGET_MS, cache5, CACHE_TTL3, empty;
var init_mini = __esm({
  "src/services/reader/mini.ts"() {
    "use strict";
    init_adapters();
    UA3 = "ResearchEngine/0.37 (+library search)";
    TIMEOUT3 = 7e3;
    LABEL = {
      web: "The web",
      wikipedia: "Wikipedia",
      screens: "Screens & references",
      ui: "App interfaces",
      docs: "Docs & registries"
    };
    host = (u) => {
      try {
        return new URL(u).hostname.replace(/^www\./, "");
      } catch {
        return "";
      }
    };
    DOCS_INDEX = [
      { title: "MDN \u2014 Web platform reference", url: "https://developer.mozilla.org/en-US/search?q=", keys: "html css javascript dom api browser web", what: "The reference for anything the browser does." },
      { title: "React docs", url: "https://react.dev/", keys: "react hooks components jsx state", what: "Official React documentation." },
      { title: "Tailwind CSS docs", url: "https://tailwindcss.com/docs/", keys: "tailwind css utility classes styling", what: "Utility reference, including the v4 changes." },
      { title: "shadcn/ui docs", url: "https://ui.shadcn.com/docs/components", keys: "shadcn component registry radix", what: "The base registry and how its components are consumed." },
      { title: "shadcn registry directory", url: "https://ui.shadcn.com/docs/directory", keys: "registry community components install namespace", what: "Every community registry the CLI can install from." },
      { title: "Tauri v2 docs", url: "https://v2.tauri.app/", keys: "tauri desktop rust webview shell", what: "The desktop shell this app ships in." },
      { title: "Hono docs", url: "https://hono.dev/docs/", keys: "hono server route middleware json", what: "The server framework the local backend uses." },
      { title: "Zod docs", url: "https://zod.dev/", keys: "zod schema validation typescript", what: "Runtime validation." },
      { title: "Motion docs", url: "https://motion.dev/docs", keys: "motion framer animation spring transition", what: "The animation library used for every interaction here." }
    ];
    BUDGET_MS = 220;
    cache5 = /* @__PURE__ */ new Map();
    CACHE_TTL3 = 10 * 60 * 1e3;
    empty = (vertical, ms, reason) => ({ vertical, label: LABEL[vertical], state: reason ? "error" : "empty", ms, hits: [], reason });
  }
});

// src/routes/library.ts
var library_exports = {};
__export(library_exports, {
  faviconFor: () => faviconFor2,
  libraryRoutes: () => libraryRoutes
});
import { Hono as Hono5 } from "hono";
function why(e, what, host2) {
  const err = e;
  const code = err?.cause?.code ?? err?.code;
  const where = host2 ? ` (${host2})` : "";
  if (err?.name === "TimeoutError" || err?.name === "AbortError") {
    return `${what} did not answer within ${Math.round(TIMEOUT4 / 1e3)}s${where}`;
  }
  if (code === "ENOTFOUND" || code === "EAI_AGAIN") return `${what} could not resolve its host${where} \u2014 this machine looks offline to it`;
  if (code === "ECONNREFUSED") return `${what} refused the connection${where}`;
  if (code === "ECONNRESET" || code === "UND_ERR_SOCKET") return `${what} dropped the connection${where}`;
  if (code === "CERT_HAS_EXPIRED" || code === "UNABLE_TO_VERIFY_LEAF_SIGNATURE" || code === "SELF_SIGNED_CERT_IN_CHAIN") return `${what} has a certificate problem${where}`;
  const http = /HTTP (\d{3})/.exec(String(err?.message ?? ""));
  if (http) return `${what} answered HTTP ${http[1]}${where}`;
  return `${what}: ${String(err?.message ?? err).replace(/\s+/g, " ").slice(0, 140)}${where}`;
}
function newLane(id) {
  return { id, label: LANE_LABEL[id], state: "pending", hits: [], ms: 0, startedAt: Date.now() };
}
function startSession(query, searxng) {
  const key = query.toLowerCase();
  const s = {
    query,
    key,
    at: Date.now(),
    local: localHits(query),
    lanes: { wikipedia: newLane("wikipedia"), sources: newLane("sources") },
    work: [],
    settled: false
  };
  const run2 = (id, fn) => {
    const lane2 = s.lanes[id];
    const started = Date.now();
    const job = fn().then((hits) => {
      lane2.state = "ok";
      lane2.hits = hits;
      lane2.ms = Date.now() - started;
    }).catch((e) => {
      lane2.state = "error";
      lane2.reason = e instanceof LaneError ? e.reason : why(e, lane2.label, id === "wikipedia" ? "en.wikipedia.org" : "html.duckduckgo.com");
      lane2.ms = Date.now() - started;
    });
    s.work.push(job);
  };
  run2("wikipedia", () => wikipedia2(query));
  run2("sources", () => trustedSources(query, searxng));
  Promise.allSettled(s.work).then(() => {
    s.settled = true;
    s.at = Date.now();
  });
  sessions.set(key, s);
  while (sessions.size > SESSIONS_MAX) sessions.delete(sessions.keys().next().value);
  return s;
}
function sessionFor(query, searxng, refresh) {
  const key = query.toLowerCase();
  const found = sessions.get(key);
  if (found && !refresh) {
    const fresh = found.settled ? Date.now() - found.at < CACHE_TTL4 : found.lanes.wikipedia.state === "pending" || found.lanes.sources.state === "pending";
    if (fresh) return found;
    const cool = Object.values(found.lanes).some((l) => l.state === "error" && Date.now() - l.startedAt < ERROR_TTL);
    if (cool) return found;
  }
  return startSession(query, searxng);
}
function localHits(q) {
  const needle = q.toLowerCase();
  const out = ownDocuments(q);
  const seen = new Set(out.map((h) => h.id));
  const hitsOfItem = (it) => ({
    id: `doc_${it.id}`,
    kind: "document",
    title: String(it.title ?? it.name ?? "Untitled"),
    url: it.url ?? void 0,
    snippet: String(it.snippet ?? "").slice(0, 300),
    source: "Your library",
    icon: "local"
  });
  for (const it of db.listLibraryItems()) {
    const hay = `${it.title} ${it.snippet ?? ""} ${(it.tags ?? []).join(" ")} ${it.url ?? ""}`.toLowerCase();
    if (!hay.includes(needle)) continue;
    const hit = hitsOfItem(it);
    if (seen.has(hit.id)) continue;
    seen.add(hit.id);
    out.push(hit);
  }
  for (const d of db.listDocuments()) {
    const hay = `${d.name} ${String(d.text ?? "").slice(0, 4e3)}`.toLowerCase();
    if (!hay.includes(needle)) continue;
    const hit = {
      id: `doc_${d.id}`,
      kind: "document",
      title: String(d.name ?? "Untitled"),
      snippet: String(d.text ?? "").replace(/\s+/g, " ").slice(0, 300),
      source: "Your documents",
      icon: "local"
    };
    if (seen.has(hit.id)) continue;
    seen.add(hit.id);
    out.push(hit);
  }
  return out.slice(0, 12);
}
async function get(url, accept = "application/json") {
  const res = await fetch(url, {
    headers: { "user-agent": UA4, accept },
    signal: AbortSignal.timeout(TIMEOUT4)
  });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res;
}
function faviconFor2(url) {
  try {
    return `https://www.google.com/s2/favicons?domain=${encodeURIComponent(new URL(url).hostname)}&sz=64`;
  } catch {
    return "";
  }
}
async function wikipedia2(q) {
  const url = `https://en.wikipedia.org/w/api.php?action=query&list=search&srsearch=${encodeURIComponent(q)}&srlimit=6&format=json&origin=*`;
  const json = await (await get(url)).json();
  const rows = json?.query?.search ?? [];
  return rows.map((r, i) => {
    const page = `https://en.wikipedia.org/?curid=${r.pageid}`;
    return {
      id: `wiki_${r.pageid ?? i}`,
      kind: "wikipedia",
      title: String(r.title ?? "").replace(/<[^>]+>/g, ""),
      url: page,
      snippet: String(r.snippet ?? "").replace(/<[^>]+>/g, "").slice(0, 300),
      source: "Wikipedia",
      favicon: faviconFor2(page),
      icon: "wikipedia"
    };
  });
}
async function trustedSources(q, searxng) {
  const problems = [];
  let results = [];
  try {
    results = (await searchSearxngAuto(q, { own: searxng, timeouts: searxng ? 1 : 2, timeoutMs: searxng ? 6e3 : 4e3 })).results;
  } catch (e) {
    problems.push(why(e, searxng ? "your SearXNG instance" : "SearXNG"));
  }
  if (!results.length) {
    try {
      results = await searchDdg(q, TIMEOUT4);
    } catch (e) {
      problems.push(why(e, "DuckDuckGo", "html.duckduckgo.com"));
    }
  }
  if (!results.length && problems.length) throw new LaneError(problems.join(" \xB7 "));
  return results.slice(0, 8).map((r, i) => ({
    id: `src_${i}_${encodeURIComponent(String(r.url ?? "")).slice(-24)}`,
    kind: "source",
    title: String(r.title ?? "").slice(0, 200) || String(r.url ?? ""),
    url: String(r.url ?? ""),
    snippet: String(r.snippet ?? "").slice(0, 300),
    source: (() => {
      try {
        return new URL(String(r.url)).hostname.replace(/^www\./, "");
      } catch {
        return "web";
      }
    })(),
    favicon: faviconFor2(String(r.url ?? "")),
    icon: "web"
  }));
}
function ownDocuments(q) {
  const needle = q.toLowerCase();
  return db.listLibraryItems().filter((it) => it.kind === "document" || it.kind === "note").filter((it) => `${it.title} ${it.snippet ?? ""} ${(it.tags ?? []).join(" ")}`.toLowerCase().includes(needle)).slice(0, 10).map((it) => ({
    id: `doc_${it.id}`,
    kind: "document",
    title: it.title,
    url: it.url ?? void 0,
    snippet: String(it.snippet ?? "").slice(0, 300),
    source: "Your library",
    icon: "local"
  }));
}
async function readFeed(url) {
  const res = await fetch(url, {
    headers: { "user-agent": UA4, accept: "application/rss+xml, application/atom+xml, application/xml, text/xml;q=0.9, */*;q=0.5" },
    signal: AbortSignal.timeout(TIMEOUT4)
  });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  const xml = (await res.text()).slice(0, 8e5);
  const title = decode(match(xml, /<title[^>]*>([\s\S]*?)<\/title>/i)) || "";
  const blocks = xml.match(/<(item|entry)[\s>][\s\S]*?<\/\1>/gi) ?? [];
  const items = blocks.slice(0, 25).map((b) => ({
    title: decode(match(b, /<title[^>]*>([\s\S]*?)<\/title>/i)),
    link: pickLink(b),
    summary: decode(match(b, /<(?:description|summary|content)[^>]*>([\s\S]*?)<\/(?:description|summary|content)>/i)).replace(/<[^>]+>/g, " ").trim().slice(0, 240),
    at: decode(match(b, /<(?:pubDate|updated|published)[^>]*>([\s\S]*?)<\/(?:pubDate|updated|published)>/i))
  })).filter((i) => i.title || i.link);
  return { title, items };
}
function match(text2, re) {
  const m = text2.match(re);
  return m ? m[1] : "";
}
function decode(s) {
  return s.replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, "$1").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&#39;|&apos;/g, "'").replace(/&amp;/g, "&").trim();
}
function pickLink(block) {
  const atom = block.match(/<link[^>]+href=["']([^"']+)["']/i);
  if (atom) return atom[1];
  return decode(match(block, /<link[^>]*>([\s\S]*?)<\/link>/i));
}
var libraryRoutes, UA4, TIMEOUT4, CACHE_TTL4, ERROR_TTL, BUDGET_MS2, sessions, SESSIONS_MAX, LANE_LABEL, LaneError, sleep;
var init_library = __esm({
  async "src/routes/library.ts"() {
    "use strict";
    await init_db();
    init_adapters();
    init_extract();
    init_mini();
    libraryRoutes = new Hono5();
    UA4 = "ResearchEngine/0.36 (+https://github.com/timetorepo/researchengine)";
    TIMEOUT4 = 7e3;
    CACHE_TTL4 = 10 * 60 * 1e3;
    ERROR_TTL = 30 * 1e3;
    BUDGET_MS2 = 200;
    sessions = /* @__PURE__ */ new Map();
    SESSIONS_MAX = 60;
    LANE_LABEL = {
      wikipedia: "Wikipedia",
      sources: "Trusted sources"
    };
    LaneError = class extends Error {
      reason;
      constructor(reason) {
        super(reason);
        this.reason = reason;
      }
    };
    sleep = (ms) => new Promise((r) => setTimeout(r, ms));
    libraryRoutes.get("/read", async (c) => {
      const url = String(c.req.query("url") ?? "").trim();
      if (!url) return c.json({ error: "A url is required." }, 400);
      const result = await readSource(url);
      return c.json(result, result.ok || result.warning ? 200 : 200);
    });
    libraryRoutes.get("/mini-search", async (c) => {
      const q = String(c.req.query("q") ?? "").trim();
      if (q.length < 2) return c.json({ error: "Type at least two characters.", results: [], pending: [] }, 400);
      const out = await miniSearch(q);
      return c.json(out);
    });
    libraryRoutes.get("/search", async (c) => {
      const q = (c.req.query("q") ?? "").trim();
      const t0 = Date.now();
      if (q.length < 2) {
        return c.json({ query: q, hits: [], notes: ["Type at least two characters."], note: "Type at least two characters.", sources: [], pending: [], tookMs: Date.now() - t0, cached: false });
      }
      const searxng = c.req.query("searxng") || process.env.SEARXNG_URL || null;
      const refresh = c.req.query("refresh") === "1";
      const budget = Math.min(Math.max(Number(c.req.query("budget")) || BUDGET_MS2, 0), 5e3);
      const session = sessionFor(q, searxng, refresh);
      const wasSettled = session.settled;
      if (!session.settled) await Promise.race([Promise.allSettled(session.work), sleep(budget)]);
      const lanes = Object.values(session.lanes);
      const hits = [
        ...session.local,
        ...session.lanes.wikipedia.hits,
        ...session.lanes.sources.hits
      ];
      const sources = lanes.map((l) => ({
        id: l.id,
        label: l.label,
        state: l.state,
        count: l.hits.length,
        ms: l.ms,
        reason: l.state === "error" ? l.reason : void 0
      }));
      const pending = lanes.filter((l) => l.state === "pending").map((l) => l.id);
      const notes = lanes.filter((l) => l.state === "error").map((l) => l.reason);
      return c.json({
        query: q,
        hits,
        sources,
        pending,
        notes,
        tookMs: Date.now() - t0,
        cached: wasSettled && !refresh
      });
    });
    libraryRoutes.get("/items", (c) => c.json({ items: db.listLibraryItems(), folders: db.listLibraryFolders() }));
    libraryRoutes.post("/items", async (c) => {
      const body = await c.req.json().catch(() => ({}));
      const title = String(body?.title ?? "").trim();
      if (!title) return c.json({ error: "An item needs a title." }, 400);
      const item = {
        id: String(body?.id ?? `lib_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 7)}`),
        kind: ["wikipedia", "source", "document", "note", "feed"].includes(String(body?.kind)) ? String(body.kind) : "source",
        title: title.slice(0, 300),
        url: body?.url ? String(body.url).slice(0, 1e3) : void 0,
        snippet: body?.snippet ? String(body.snippet).slice(0, 4e3) : void 0,
        tags: Array.isArray(body?.tags) ? body.tags.map((t) => String(t).slice(0, 40)).slice(0, 12) : [],
        folderId: body?.folderId ? String(body.folderId) : void 0,
        savedAt: Date.now(),
        extra: body?.extra ?? void 0
      };
      db.insertLibraryItem(item);
      return c.json({ ok: true, item });
    });
    libraryRoutes.delete("/items/:id", (c) => {
      db.deleteLibraryItem(c.req.param("id"));
      return c.json({ ok: true });
    });
    libraryRoutes.get("/folders", (c) => c.json({ folders: db.listLibraryFolders() }));
    libraryRoutes.post("/folders", async (c) => {
      const body = await c.req.json().catch(() => ({}));
      const name = String(body?.name ?? "").trim();
      if (!name) return c.json({ error: "A folder needs a name." }, 400);
      const folder = {
        id: String(body?.id ?? `fold_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 7)}`),
        name: name.slice(0, 80),
        createdAt: Date.now()
      };
      db.insertLibraryFolder(folder);
      return c.json({ ok: true, folder });
    });
    libraryRoutes.delete("/folders/:id", (c) => {
      db.deleteLibraryFolder(c.req.param("id"));
      return c.json({ ok: true });
    });
    libraryRoutes.post("/upload", async (c) => {
      const body = await c.req.json().catch(() => ({}));
      const name = String(body?.name ?? "").trim();
      if (!name) return c.json({ error: "The file needs a name." }, 400);
      const text2 = String(body?.text ?? "").slice(0, 4e5);
      const item = {
        id: `lib_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 7)}`,
        kind: "document",
        title: name.slice(0, 300),
        snippet: text2.slice(0, 4e3),
        tags: Array.isArray(body?.tags) ? body.tags.map((t) => String(t).slice(0, 40)).slice(0, 12) : [],
        folderId: body?.folderId ? String(body.folderId) : void 0,
        savedAt: Date.now(),
        extra: { bytes: Number(body?.bytes) || 0, type: String(body?.type ?? ""), chars: text2.length }
      };
      db.insertLibraryItem(item);
      return c.json({ ok: true, item });
    });
    libraryRoutes.post("/feeds", async (c) => {
      const body = await c.req.json().catch(() => ({}));
      const url = String(body?.url ?? "").trim();
      if (!/^https?:\/\//i.test(url)) return c.json({ error: "Feeds need an http(s) URL." }, 400);
      try {
        const feed = await readFeed(url);
        const item = {
          id: `feed_${Date.now().toString(36)}`,
          kind: "feed",
          title: feed.title || url,
          url,
          snippet: feed.items.slice(0, 3).map((i) => i.title).join(" \xB7 ").slice(0, 400),
          tags: Array.isArray(body?.tags) ? body.tags.map((t) => String(t).slice(0, 40)).slice(0, 12) : [],
          savedAt: Date.now(),
          extra: { feedTitle: feed.title, items: feed.items.length }
        };
        db.insertLibraryItem(item);
        return c.json({ ok: true, item, preview: feed.items.slice(0, 5) });
      } catch (e) {
        return c.json({ error: `That feed did not load: ${String(e?.message ?? e).slice(0, 120)}` }, 502);
      }
    });
    libraryRoutes.get("/recommendations", async (c) => {
      const items = db.listLibraryItems();
      const asked = (c.req.query("tags") ?? "").split(",").map((t) => t.trim()).filter(Boolean);
      const tags = [.../* @__PURE__ */ new Set([...asked, ...items.flatMap((i) => i.tags ?? [])])].slice(0, 6);
      const feeds = items.filter((i) => i.kind === "feed").slice(0, 5);
      const out = [];
      const startedAt = Date.now();
      const notes = [];
      const feedWork = feeds.map(async (f) => {
        try {
          const feed = await readFeed(f.url);
          for (const it of feed.items.slice(0, 4)) {
            const publisher = feed.title || f.title || (() => {
              try {
                return new URL(f.url).hostname.replace(/^www\./, "");
              } catch {
                return "a feed";
              }
            })();
            out.push({
              ...it,
              reason: `new in ${publisher}`,
              source: f.url,
              favicon: faviconFor2(f.url),
              topic: publisher,
              via: "feed",
              publisher
            });
          }
        } catch (e) {
          notes.push(`${f.title} did not load \u2014 ${why(e, "the feed", (() => {
            try {
              return new URL(f.url).hostname;
            } catch {
              return void 0;
            }
          })())}`);
        }
      });
      const tagWork = tags.map(async (tag) => {
        try {
          const hits = await wikipedia2(tag);
          for (const h of hits.slice(0, 3)) {
            out.push({
              title: h.title,
              link: h.url ?? "",
              summary: h.snippet,
              reason: `matches your tag #${tag}`,
              source: h.url ?? "",
              favicon: h.favicon,
              topic: `#${tag}`,
              via: "tag",
              publisher: "Wikipedia"
            });
          }
        } catch (e) {
          notes.push(`#${tag}: ${why(e, "Wikipedia", "en.wikipedia.org")}`);
        }
      });
      await Promise.allSettled([...feedWork, ...tagWork]);
      out.sort((a, b) => {
        const ta = a.at ? Date.parse(a.at) : NaN;
        const tb = b.at ? Date.parse(b.at) : NaN;
        if (Number.isNaN(ta) && Number.isNaN(tb)) return 0;
        if (Number.isNaN(ta)) return 1;
        if (Number.isNaN(tb)) return -1;
        return tb - ta;
      });
      const seen = /* @__PURE__ */ new Set();
      const unique = out.filter((r) => {
        const key = r.link || r.title;
        if (!key || seen.has(key)) return false;
        seen.add(key);
        return true;
      }).slice(0, 20);
      return c.json({
        recommendations: unique,
        watching: {
          tags,
          feeds: feeds.map((f) => ({ id: f.id, title: f.title, url: f.url })),
          topics: [...new Set(unique.map((r) => r.topic))]
        },
        notes,
        tookMs: Date.now() - startedAt,
        hint: tags.length || feeds.length ? void 0 : "Add tags to something you saved, or an RSS feed, and recommendations will follow those."
      });
    });
  }
});

// src/routes/skills.ts
var skills_exports = {};
__export(skills_exports, {
  scannerCandidates: () => scannerCandidates,
  scannerInfo: () => scannerInfo,
  skillsRoutes: () => skillsRoutes,
  staticScan: () => staticScan
});
import { Hono as Hono6 } from "hono";
import { spawn as spawn3 } from "node:child_process";
import { existsSync as existsSync6, mkdirSync as mkdirSync4, rmSync as rmSync3, writeFileSync as writeFileSync4 } from "node:fs";
import { join as join6 } from "node:path";
import { randomUUID } from "node:crypto";
function scannerCandidates() {
  const out = [];
  if (process.env.SKILLSPECTOR_BIN) out.push({ kind: "bin", cmd: process.env.SKILLSPECTOR_BIN, args: [] });
  const venv = process.env.SKILLSPECTOR_VENV && join6(process.env.SKILLSPECTOR_VENV, "bin", "skillspector");
  if (venv) out.push({ kind: "bin", cmd: venv, args: [] });
  out.push({ kind: "bin", cmd: "skillspector", args: [] });
  out.push({ kind: "bin", cmd: "skillspector.exe", args: [] });
  out.push({ kind: "bin", cmd: "python3 -m skillspector", args: [] });
  out.push({ kind: "docker", cmd: "docker", args: ["run", "--rm", "-v"] });
  return out;
}
async function scannerInfo() {
  const install = "pipx install graph-skillspector  (or: docker pull skillspector)";
  const explicit = process.env.SKILLSPECTOR_BIN;
  if (explicit && existsSync6(explicit)) {
    const v = await run([explicit, "--version"], void 0, 8e3).catch(() => null);
    return { available: true, how: "SKILLSPECTOR_BIN", detail: (v?.stdout || v?.stderr || "").trim().slice(0, 200) || explicit, install, llm: false };
  }
  const onPath = await which("skillspector");
  if (onPath) {
    const v = await run(["skillspector", "--version"], void 0, 8e3).catch(() => null);
    return { available: true, how: "path", detail: (v?.stdout || v?.stderr || "").trim().slice(0, 200) || onPath, install, llm: false };
  }
  const docker = await which("docker");
  if (docker) {
    const info = await run(["docker", "image", "inspect", "skillspector"], void 0, 8e3).catch(() => null);
    if (info && info.code === 0) {
      return { available: true, how: "docker", detail: "image skillspector", install, llm: false };
    }
    return { available: false, how: "docker", detail: "docker is installed but the skillspector image is not pulled", install: "docker pull skillspector", llm: false };
  }
  return { available: false, how: "none", detail: "SkillSpector is not installed on this machine", install, llm: false };
}
function which(cmd) {
  const probe = process.platform === "win32" ? ["where", cmd] : ["sh", "-lc", `command -v ${cmd}`];
  return run(probe, void 0, 6e3).then((r) => r.code === 0 && r.stdout.trim().split("\n")[0] || null).catch(() => null);
}
function run(argv, cwd, timeoutMs) {
  return new Promise((resolvePromise, reject) => {
    let cmd = argv[0];
    let args2 = argv.slice(1);
    if (cmd.includes(" ")) {
      const parts = cmd.split(" ");
      cmd = parts[0];
      args2 = [...parts.slice(1), ...args2];
    }
    let child;
    try {
      child = spawn3(cmd, args2, { cwd, shell: false });
    } catch (e) {
      reject(e);
      return;
    }
    let stdout = "";
    let stderr = "";
    const cap = 2e6;
    child.stdout?.on("data", (d) => {
      if (stdout.length < cap) stdout += String(d);
    });
    child.stderr?.on("data", (d) => {
      if (stderr.length < cap) stderr += String(d);
    });
    const timer = setTimeout(() => {
      try {
        child.kill("SIGKILL");
      } catch {
      }
      reject(new Error(`timed out after ${timeoutMs}ms`));
    }, timeoutMs);
    child.on("error", (e) => {
      clearTimeout(timer);
      reject(e);
    });
    child.on("close", (code) => {
      clearTimeout(timer);
      resolvePromise({ code: code ?? -1, stdout, stderr });
    });
  });
}
function staticScan(files) {
  const findings = [];
  for (const f of files) {
    const lines = f.text.split("\n");
    for (const rule of RULES) {
      for (let i = 0; i < lines.length; i++) {
        const line = lines[i];
        if (!rule.re.test(line)) continue;
        findings.push({
          id: rule.id,
          severity: rule.severity,
          title: rule.title,
          why: rule.why,
          file: f.path,
          line: i + 1,
          evidence: line.trim().slice(0, 200)
        });
        break;
      }
    }
  }
  const weight = { high: 34, medium: 14, low: 5 };
  const score = Math.min(100, findings.reduce((n, f) => n + weight[f.severity], 0));
  const severity = score >= 67 ? "HIGH" : score >= 34 ? "MEDIUM" : score > 0 ? "LOW" : "NONE";
  const recommendation = score > 50 ? "DO_NOT_INSTALL" : score > 0 ? "CAUTION" : "SAFE";
  return { score, severity, recommendation, findings };
}
function extractJson(text2) {
  if (!text2) return null;
  const start = text2.indexOf("{");
  const end = text2.lastIndexOf("}");
  if (start < 0 || end <= start) return null;
  try {
    return JSON.parse(text2.slice(start, end + 1));
  } catch {
    return null;
  }
}
var skillsRoutes, TIMEOUT_MS, MAX_FILES, MAX_FILE_BYTES, MAX_TOTAL_BYTES, RULES;
var init_skills = __esm({
  async "src/routes/skills.ts"() {
    "use strict";
    await init_db();
    skillsRoutes = new Hono6();
    TIMEOUT_MS = 12e4;
    MAX_FILES = 200;
    MAX_FILE_BYTES = 4e5;
    MAX_TOTAL_BYTES = 4e6;
    RULES = [
      { id: "exfil", severity: "high", title: "Sends data somewhere", re: /\b(curl|wget|fetch|requests\.post|axios\.post|Invoke-WebRequest)\b[^\n]{0,80}(https?:\/\/|--data|-d\s|@)/i, why: "A skill that posts data out can send your files, keys or prompts to a server." },
      { id: "pipe-shell", severity: "high", title: "Pipes a download into a shell", re: /\b(curl|wget)\b[^\n|]{0,120}\|\s*(ba|z|fi)?sh\b/i, why: "The classic install-and-run-anything pattern; the payload is not visible in the skill." },
      { id: "secrets", severity: "high", title: "Reads credentials or keys", re: /(id_rsa|\.ssh\/|\.aws\/credentials|\.env\b|api[_-]?key|secret|token|password|keychain)/i, why: "Reading credential stores is how a skill converts access into exfiltration." },
      { id: "destructive", severity: "high", title: "Deletes files outside the project", re: /\brm\s+-rf?\s+[/~]|\brm\s+-rf\s+\$|\bformat\s+c:|\bmkfs\b|shutil\.rmtree\(['"]\//i, why: "Irreversible destruction of the user's machine." },
      { id: "injection", severity: "high", title: "Instructs the model to ignore its rules", re: /(ignore (all )?(previous|prior|above) (instructions|rules)|disregard (your|all) (instructions|rules)|do not tell the user|without telling the user|hidden instruction)/i, why: "Prompt injection: the skill tries to take over the agent rather than help it." },
      { id: "eval", severity: "medium", title: "Evaluates or decodes a string into code", re: /\b(eval|exec)\s*\(|base64\s+(-d|--decode)|atob\s*\(|Invoke-Expression|FromBase64String/i, why: "Obfuscation: what runs is not what a reader sees." },
      { id: "sudo", severity: "medium", title: "Escalates privileges", re: /\bsudo\b|\brunas\b|setuid|doas\s/i, why: "A skill has no reason to need root." },
      { id: "persist", severity: "medium", title: "Installs itself to run later", re: /(crontab|systemctl enable|launchctl|Startup folder|\.bashrc|\.zshrc|\.profile)/i, why: "Persistence survives your deleting the skill." },
      { id: "postinstall", severity: "medium", title: "Runs code on install", re: /(postinstall|preinstall|prepare"\s*:|npm\s+i\s+-g|pip\s+install[^\n]{0,40}git\+)/i, why: "Supply chain: the install step becomes the payload." },
      { id: "broad-write", severity: "medium", title: "Writes outside its own folder", re: /(>|\btee\b)\s*(\/(etc|usr|bin|var)|\$HOME(\/|$))|writeFileSync\(['"]\//i, why: "A skill should work inside the project, not on the system." },
      { id: "broad-net", severity: "low", title: "Talks to a network endpoint", re: /https?:\/\/[^\s)"']+/i, why: "Not wrong on its own \u2014 but every endpoint is a place your data can go." },
      { id: "unbounded", severity: "low", title: "Loops or spawns without a bound", re: /(while\s*\(?\s*true|for\s*\(\s*;\s*;|--max-old-space|fork\s*\(\s*\d{2,})/i, why: "A skill that can run away takes the machine with it." }
    ];
    skillsRoutes.get("/scanner", async (c) => c.json(await scannerInfo()));
    skillsRoutes.post("/scan", async (c) => {
      const body = await c.req.json().catch(() => ({}));
      const files = Array.isArray(body?.files) ? body.files.slice(0, MAX_FILES).map((f) => ({ path: String(f?.path ?? "SKILL.md").slice(0, 200), text: String(f?.text ?? "").slice(0, MAX_FILE_BYTES) })).filter((f) => f.text) : [];
      if (!files.length) return c.json({ error: "Nothing to scan \u2014 give the skill at least one file." }, 400);
      const total = files.reduce((n, f) => n + f.text.length, 0);
      if (total > MAX_TOTAL_BYTES) return c.json({ error: "That skill is larger than this scanner accepts (4 MB of text)." }, 400);
      const local = staticScan(files);
      const info = await scannerInfo();
      if (!info.available) {
        return c.json({
          scanner: "local-static",
          scannerNote: `${info.detail}. This is this app's own static pass, not NVIDIA's SkillSpector \u2014 install it to get the full scan.`,
          install: info.install,
          verdict: local,
          files: files.map((f) => f.path)
        });
      }
      const dir = join6(process.env.RE_DATA_DIR || join6(process.cwd(), ".data"), "skill-scans", randomUUID());
      mkdirSync4(dir, { recursive: true });
      try {
        for (const f of files) {
          const rel = f.path.replace(/\\/g, "/").split("/").filter((p) => p && p !== "." && p !== "..").join("/");
          if (!rel) continue;
          const target = join6(dir, rel);
          mkdirSync4(join6(target, ".."), { recursive: true });
          writeFileSync4(target, f.text);
        }
        const argv = info.how === "docker" ? ["docker", "run", "--rm", "-v", `${dir}:/scan`, "skillspector", "scan", "/scan", "--format", "json", "--no-llm"] : [process.env.SKILLSPECTOR_BIN || "skillspector", "scan", dir, "--format", "json", "--no-llm"];
        const out = await run(argv, void 0, TIMEOUT_MS);
        if (out.code === 2 || out.code !== 0 && out.code !== 1) {
          return c.json({
            scanner: "local-static",
            scannerNote: `SkillSpector exited ${out.code}: ${(out.stderr || out.stdout).trim().slice(0, 300) || "no output"}`,
            install: info.install,
            verdict: local,
            files: files.map((f) => f.path)
          });
        }
        const json = extractJson(out.stdout) ?? extractJson(out.stderr);
        if (!json) {
          return c.json({
            scanner: "local-static",
            scannerNote: "SkillSpector ran but its report could not be read; the local pass is shown instead.",
            install: info.install,
            verdict: local,
            files: files.map((f) => f.path)
          });
        }
        const verdict = {
          score: Number(json.risk_score ?? json.score ?? local.score),
          severity: String(json.severity ?? local.severity),
          recommendation: String(json.recommendation ?? json.verdict ?? local.recommendation),
          safeToInstall: json.safe_to_install !== void 0 ? !!json.safe_to_install : Number(json.risk_score ?? 100) <= 50,
          findings: Array.isArray(json.findings) ? json.findings.slice(0, 200) : [],
          llmUsed: !!(json.llm_used ?? json?.metadata?.llm_used)
        };
        return c.json({ scanner: "skillspector", scannerNote: "Scanned by NVIDIA SkillSpector (static pass, no model, nothing uploaded).", verdict, local, files: files.map((f) => f.path) });
      } catch (e) {
        return c.json({
          scanner: "local-static",
          scannerNote: `SkillSpector could not be run (${String(e?.message ?? e).slice(0, 200)}); the local pass is shown instead.`,
          install: info.install,
          verdict: local,
          files: files.map((f) => f.path)
        });
      } finally {
        try {
          rmSync3(dir, { recursive: true, force: true });
        } catch {
        }
      }
    });
    skillsRoutes.post("/import", async (c) => {
      const body = await c.req.json().catch(() => ({}));
      const name = String(body?.name ?? "").trim();
      if (!name) return c.json({ error: "The skill needs a name." }, 400);
      const record = {
        id: String(body?.id ?? `imp_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 7)}`),
        kind: "skill",
        title: name.slice(0, 200),
        snippet: String(body?.description ?? "").slice(0, 4e3),
        tags: Array.isArray(body?.tags) ? body.tags.slice(0, 12) : ["skill"],
        savedAt: Date.now(),
        extra: { source: body?.source ?? "imported", files: Number(body?.files) || 0, security: body?.security ?? null }
      };
      db.insertLibraryItem(record);
      return c.json({ ok: true, record });
    });
  }
});

// src/routes/search.ts
var search_exports = {};
__export(search_exports, {
  searchRoutes: () => searchRoutes
});
import { Hono as Hono7 } from "hono";
function keysFrom(c) {
  try {
    const raw = c.req.header("x-re-search-keys");
    if (!raw) return {};
    const parsed = JSON.parse(raw);
    return {
      brave: typeof parsed?.brave === "string" ? parsed.brave : void 0,
      serper: typeof parsed?.serper === "string" ? parsed.serper : void 0,
      tavily: typeof parsed?.tavily === "string" ? parsed.tavily : void 0
    };
  } catch {
    return {};
  }
}
var searchRoutes;
var init_search = __esm({
  "src/routes/search.ts"() {
    "use strict";
    init_adapters();
    searchRoutes = new Hono7();
    searchRoutes.get("/", async (c) => {
      const q = c.req.query("q");
      if (!q) return c.json({ error: "Missing ?q=" }, 400);
      if (c.req.query("offline") === "1") {
        return c.json({ backend: "demo", offline: true, results: searchDemo(q) });
      }
      const keys = keysFrom(c);
      const own = c.req.query("searxng") || process.env.SEARXNG_URL || null;
      const patience = Number(c.req.query("timeout")) || void 0;
      const requested = (c.req.query("backend") ?? process.env.SEARCH_BACKEND ?? "auto").toLowerCase();
      const engineTimeout = patience ? Math.min(6e4, patience * 1e3) : void 0;
      const attempts = [];
      const note = (engine2, error) => attempts.push({ engine: engine2, ...error ? { error } : {} });
      const tryEngine = async (engine2) => {
        try {
          switch (engine2) {
            case "brave":
              return { results: await searchBrave(q, keys.brave, engineTimeout), label: "brave" };
            case "serper":
              return { results: await searchSerper(q, keys.serper, engineTimeout), label: "serper" };
            case "tavily":
              return { results: await searchTavily(q, keys.tavily, engineTimeout), label: "tavily" };
            case "ddg":
              return { results: await searchDdg(q, engineTimeout), label: "ddg" };
            case "searxng": {
              const { results, instance } = await searchSearxngAuto(q, { own, timeouts: 3, timeoutMs: engineTimeout });
              return { results, label: `searxng:${instance}` };
            }
            case "demo":
              return { results: searchDemo(q), label: "demo" };
            default:
              return null;
          }
        } catch (e) {
          note(engine2, String(e?.message ?? e));
          return null;
        }
      };
      if (requested !== "auto") {
        const hit = await tryEngine(requested);
        if (hit?.results.length) return c.json({ backend: hit.label, attempts, results: hit.results });
      }
      const sx = await tryEngine("searxng");
      if (sx?.results.length) return c.json({ backend: sx.label, attempts, results: sx.results });
      if (requested !== "ddg") {
        const ddg = await tryEngine("ddg");
        if (ddg?.results.length) return c.json({ backend: "ddg", attempts, results: ddg.results });
      }
      return c.json({ backend: "demo", attempts, results: searchDemo(q) });
    });
    searchRoutes.get("/status", async (c) => {
      const keys = keysFrom(c);
      const own = c.req.query("searxng") || process.env.SEARXNG_URL || null;
      const status = await searchStatus(keys, own);
      return c.json(status);
    });
  }
});

// src/routes/secrets.ts
function maskSecrets(text2) {
  let out = String(text2 ?? "");
  for (const re of PATTERNS) out = out.replace(re, "[REDACTED]");
  return out;
}
var PATTERNS;
var init_secrets = __esm({
  "src/routes/secrets.ts"() {
    "use strict";
    PATTERNS = [
      /\bsk-[A-Za-z0-9_-]{16,}\b/g,
      // OpenAI-style
      /\bsk-ant-[A-Za-z0-9_-]{16,}\b/g,
      // Anthropic
      /\bsk-proj-[A-Za-z0-9_-]{16,}\b/g,
      /\bAIza[0-9A-Za-z_-]{30,}\b/g,
      // Google / Gemini
      /\bghp_[A-Za-z0-9]{30,}\b/g,
      // GitHub PAT
      /\bgho_[A-Za-z0-9]{30,}\b/g,
      /\bgithub_pat_[A-Za-z0-9_]{30,}\b/g,
      /\bxox[baprs]-[A-Za-z0-9-]{10,}\b/g,
      // Slack
      /\bAKIA[0-9A-Z]{16}\b/g,
      // AWS
      /\bhf_[A-Za-z0-9]{20,}\b/g,
      // HuggingFace
      /\bnvapi-[A-Za-z0-9_-]{16,}\b/g,
      // NVIDIA NIM
      /\beyJ[A-Za-z0-9_-]{12,}\.[A-Za-z0-9_-]{12,}\.[A-Za-z0-9_-]{6,}\b/g,
      // JWT
      /-----BEGIN [A-Z ]*PRIVATE KEY-----[\s\S]{20,}?-----END [A-Z ]*PRIVATE KEY-----/g,
      /\bkey-[A-Za-z0-9]{20,}\b/g
    ];
  }
});

// src/routes/chat.ts
var chat_exports = {};
__export(chat_exports, {
  chatRoutes: () => chatRoutes,
  toGeminiContents: () => toGeminiContents
});
import { Hono as Hono8 } from "hono";
import { streamSSE } from "hono/streaming";
function toOpenAIMessages(system, messages2) {
  const out = system ? [{ role: "system", content: system }] : [];
  for (const m of messages2) {
    if (m.role === "tool") {
      out.push({ role: "tool", tool_call_id: m.toolCallId, content: typeof m.content === "string" ? m.content : JSON.stringify(m.content) });
      continue;
    }
    const msg = { role: m.role };
    if (Array.isArray(m.content)) {
      msg.content = m.content.map((p) => p.type === "image" ? { type: "image_url", image_url: { url: p.dataUrl } } : { type: "text", text: p.text });
    } else {
      msg.content = m.content ?? "";
    }
    if (m.toolCalls?.length) {
      msg.tool_calls = m.toolCalls.map((t) => {
        const out2 = { id: t.id, type: "function", function: { name: t.name, arguments: typeof t.arguments === "string" ? t.arguments : JSON.stringify(t.arguments ?? {}) } };
        const sig = t.thoughtSignature ?? t.thought_signature ?? t.extraContent?.google?.thought_signature ?? t.extra_content?.google?.thought_signature;
        if (sig) out2.extra_content = { google: { thought_signature: sig } };
        return out2;
      });
    }
    out.push(msg);
  }
  return out;
}
function toGeminiContents(messages2) {
  const out = [];
  for (const m of messages2) {
    if (m.role === "tool") {
      out.push({ role: "user", parts: [{ functionResponse: { name: m.name ?? "tool", id: m.toolCallId, response: { result: typeof m.content === "string" ? m.content : JSON.stringify(m.content) } } }] });
      continue;
    }
    const role = m.role === "assistant" ? "model" : "user";
    const parts = [];
    if (Array.isArray(m.content)) {
      for (const p of m.content) {
        if (p.type === "image") {
          const { mime, data } = splitDataUrl(p.dataUrl);
          parts.push({ inline_data: { mime_type: mime, data } });
        } else if (p.text) parts.push({ text: p.text });
      }
    } else if (typeof m.content === "string" && m.content) {
      parts.push({ text: m.content });
    }
    if (m.toolCalls?.length) {
      for (const t of m.toolCalls) {
        let args2 = t.arguments;
        if (typeof args2 === "string") {
          try {
            args2 = JSON.parse(args2);
          } catch {
            args2 = { input: args2 };
          }
        }
        const part = { functionCall: { name: t.name, args: args2 ?? {}, ...t.id ? { id: t.id } : {} } };
        const sig = t.thoughtSignature ?? t.thought_signature ?? t.extraContent?.google?.thought_signature ?? t.extra_content?.google?.thought_signature;
        if (sig) part.thoughtSignature = sig;
        parts.push(part);
      }
    }
    if (parts.length) out.push({ role, parts });
  }
  return out;
}
function toAnthropicBody(system, messages2) {
  const out = [];
  for (const m of messages2) {
    if (m.role === "tool") {
      out.push({ role: "user", content: [{ type: "tool_result", tool_use_id: m.toolCallId, content: typeof m.content === "string" ? m.content : JSON.stringify(m.content) }] });
      continue;
    }
    const content = [];
    if (Array.isArray(m.content)) {
      for (const p of m.content) {
        if (p.type === "image") {
          const { mime, data } = splitDataUrl(p.dataUrl);
          content.push({ type: "image", source: { type: "base64", media_type: mime, data } });
        } else if (p.text) content.push({ type: "text", text: p.text });
      }
    } else if (typeof m.content === "string" && m.content) {
      content.push({ type: "text", text: m.content });
    }
    if (m.role === "assistant" && m.toolCalls?.length) {
      for (const t of m.toolCalls) {
        let input = t.arguments;
        if (typeof input === "string") {
          try {
            input = JSON.parse(input);
          } catch {
            input = {};
          }
        }
        content.push({ type: "tool_use", id: t.id, name: t.name, input: input ?? {} });
      }
    }
    if (content.length) out.push({ role: m.role === "assistant" ? "assistant" : "user", content });
  }
  const merged = [];
  for (const m of out) {
    const last = merged[merged.length - 1];
    if (last && last.role === m.role) last.content = [...last.content, ...m.content];
    else merged.push(m);
  }
  return { system: system || void 0, messages: merged.filter((m) => m.role === "user" || merged.indexOf(m) > 0) };
}
var chatRoutes, splitDataUrl;
var init_chat = __esm({
  "src/routes/chat.ts"() {
    "use strict";
    init_secrets();
    chatRoutes = new Hono8();
    splitDataUrl = (dataUrl) => {
      const m = /^data:([^;]+);base64,(.*)$/s.exec(dataUrl ?? "");
      return m ? { mime: m[1], data: m[2] } : { mime: "image/png", data: dataUrl ?? "" };
    };
    chatRoutes.post("/", async (c) => {
      const body = await c.req.json();
      const kind = body.kind ?? "openai";
      const model = body.model;
      const key = body.key ?? body.apiKey ?? "";
      const base = String(body.base ?? body.baseUrl ?? "").replace(/\/+$/, "");
      const system = body.system ?? "";
      const messages2 = body.messages ?? [];
      const maxTokens = body.maxTokens ?? 1024;
      const temperature = body.temperature ?? 0.7;
      const tools = Array.isArray(body.tools) && body.tools.length ? body.tools : null;
      if (!model) return c.json({ error: "model is required" }, 400);
      if (!base) return c.json({ error: "base is required" }, 400);
      let url;
      let headers;
      let payload;
      const isNvidia = base.includes("api.nvidia.com") || kind === "nim";
      const isOpenRouter = base.includes("openrouter.ai");
      const browserish = {
        "user-agent": isNvidia ? "NVIDIA-NIM-Client/1.0" : "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
        accept: "text/event-stream"
      };
      if (kind === "anthropic") {
        url = `${base}/messages`;
        headers = {
          ...browserish,
          "content-type": "application/json",
          "x-api-key": key,
          "anthropic-version": "2023-06-01"
        };
        const conv = toAnthropicBody(system, messages2);
        payload = { model, stream: true, max_tokens: maxTokens, temperature, system: conv.system ?? "", messages: conv.messages };
        if (tools) {
          payload.tools = tools.map((t) => ({ name: t.function.name, description: t.function.description ?? "", input_schema: t.function.parameters ?? { type: "object", properties: {} } }));
        }
      } else if (kind === "gemini") {
        url = `${base}/models/${encodeURIComponent(model)}:streamGenerateContent?alt=sse`;
        headers = {
          ...browserish,
          "content-type": "application/json",
          ...key ? { "x-goog-api-key": key } : {}
        };
        payload = {
          contents: toGeminiContents(messages2),
          generationConfig: { temperature, maxOutputTokens: maxTokens }
        };
        if (system) payload.systemInstruction = { parts: [{ text: system }] };
        if (tools) {
          payload.tools = [{
            functionDeclarations: tools.map((t) => ({
              name: t.function.name,
              description: t.function.description ?? "",
              parameters: t.function.parameters ?? { type: "object", properties: {} }
            }))
          }];
        }
      } else {
        url = `${base}/chat/completions`;
        headers = {
          ...browserish,
          "content-type": "application/json",
          ...key ? { authorization: `Bearer ${key}` } : {},
          ...isNvidia && key ? { "x-nvidia-api-key": key } : {},
          ...isOpenRouter ? { "HTTP-Referer": "https://researchengine.local", "X-OpenRouter-Title": "Research Engine" } : {}
        };
        payload = {
          model,
          stream: true,
          max_tokens: maxTokens,
          temperature,
          messages: toOpenAIMessages(system, messages2),
          // Ask for the token counts with the stream, so the UI can show what a
          // response actually cost instead of guessing from character counts.
          stream_options: { include_usage: true }
        };
        if (tools) {
          payload.tools = tools;
          payload.tool_choice = "auto";
        }
        if (isNvidia && /deepseek|reasoning|qwq|thought|thinking|nemotron/i.test(model)) {
          payload.chat_template_kwargs = { enable_thinking: true, thinking: true };
        }
      }
      const send = (body2) => fetch(url, {
        method: "POST",
        headers,
        body: JSON.stringify(body2),
        signal: c.req.raw.signal
        // client abort kills the upstream call
      });
      let upstream = await send(payload);
      if (!upstream.ok && payload.stream_options && upstream.status >= 400 && upstream.status < 500) {
        const peek = await upstream.clone().text().catch(() => "");
        if (/stream_options|unknown|unrecognized|additional propert|unsupported parameter/i.test(peek)) {
          delete payload.stream_options;
          upstream = await send(payload);
        }
      }
      if (!upstream.ok || !upstream.body) {
        const errText = await upstream.text().catch(() => "");
        let msg = `${upstream.status}`;
        try {
          const j = JSON.parse(errText);
          msg = j?.error?.message ?? j?.detail ?? j?.message ?? msg;
        } catch {
        }
        if (upstream.status === 403 && isNvidia) {
          msg += " \u2014 NVIDIA rejected this key for chat. GET /v1/models can still work when inference is not enabled. Check that your NVIDIA organization has Public API Endpoints access, accept the model terms on its catalog page, regenerate the nvapi key, and try a currently chat-capable model. Research Engine already sends NVIDIA-NIM-Client/1.0, Bearer, and X-NVIDIA-API-Key headers.";
        }
        return c.json({ error: maskSecrets(msg) }, upstream.status);
      }
      c.header("Content-Type", "text/event-stream");
      c.header("Cache-Control", "no-cache");
      return streamSSE(c, async (stream) => {
        const reader = upstream.body.getReader();
        const td = new TextDecoder();
        try {
          for (; ; ) {
            const { done, value } = await reader.read();
            if (done) break;
            await stream.write(td.decode(value, { stream: true }));
          }
        } catch {
        }
      });
    });
  }
});

// src/routes/documents.ts
var documents_exports = {};
__export(documents_exports, {
  documentRoutes: () => documentRoutes
});
import { Hono as Hono9 } from "hono";
var documentRoutes;
var init_documents = __esm({
  async "src/routes/documents.ts"() {
    "use strict";
    await init_db();
    documentRoutes = new Hono9();
    documentRoutes.post("/", async (c) => {
      const body = await c.req.json();
      const { id, name, kind = "file", text: text2 = "" } = body;
      if (!id || !name) return c.json({ error: "id and name are required" }, 400);
      db.insertDocument({ id, name, kind, text: text2, addedAt: Date.now() });
      return c.json({ ok: true, id });
    });
    documentRoutes.get("/", (c) => c.json({ documents: db.listDocuments() }));
  }
});

// src/routes/ollama.ts
var ollama_exports = {};
__export(ollama_exports, {
  ollamaRoutes: () => ollamaRoutes
});
import { Hono as Hono10 } from "hono";
var ollamaRoutes;
var init_ollama = __esm({
  "src/routes/ollama.ts"() {
    "use strict";
    ollamaRoutes = new Hono10();
    ollamaRoutes.get("/tags", async (c) => {
      const base = (process.env.OLLAMA_URL ?? "http://localhost:11434").replace(/\/$/, "");
      try {
        const res = await fetch(`${base}/api/tags`);
        if (!res.ok) return c.json({ error: `Ollama responded ${res.status}` }, 502);
        return c.json(await res.json());
      } catch (e) {
        return c.json({ error: `Cannot reach Ollama at ${base}: ${e.message}` }, 502);
      }
    });
  }
});

// src/services/integrations/index.ts
function credsFrom(header) {
  if (!header) return {};
  try {
    const parsed = JSON.parse(header);
    if (!parsed || typeof parsed !== "object") return {};
    const out = {};
    for (const [k, v] of Object.entries(parsed)) {
      if (!v || typeof v !== "object") continue;
      const creds = {};
      for (const field of ["token", "refreshToken", "clientId", "clientSecret", "base"]) {
        const raw = v[field];
        if (typeof raw === "string" && raw) creds[field] = raw;
      }
      if (Object.keys(creds).length) out[k] = creds;
    }
    return out;
  } catch {
    return {};
  }
}
async function jfetch(url, init = {}, what = "The service") {
  try {
    const headers = new Headers(init.headers);
    if (init.json !== void 0) headers.set("content-type", "application/json");
    const res = await fetch(url, {
      ...init,
      headers,
      body: init.json !== void 0 ? JSON.stringify(init.json) : init.body,
      signal: AbortSignal.timeout(TIMEOUT_MS2)
    });
    const text2 = await res.text();
    let body = null;
    try {
      body = text2 ? JSON.parse(text2) : null;
    } catch {
      body = null;
    }
    if (!res.ok) {
      const mapped = mapStatus(res.status, what);
      const detail = typeof body?.error?.message === "string" ? body.error.message : typeof body?.message === "string" ? body.message : "";
      const extra = detail && detail.length < 200 && !mapped.error.includes(detail) ? ` ${detail}` : "";
      return { ok: false, ...mapped, error: `${mapped.error}${extra}`, status: res.status };
    }
    return { ok: true, status: res.status, body, text: text2, res };
  } catch (e) {
    const msg = String(e?.name === "TimeoutError" ? `${what} did not answer in ${TIMEOUT_MS2 / 1e3}s.` : e?.message ?? e);
    return { ok: false, error: msg, needs: "network" };
  }
}
async function googleToken(creds) {
  if (creds.token) return { ok: true, data: creds.token };
  if (!creds.refreshToken || !creds.clientId || !creds.clientSecret) {
    return { ok: false, error: "This Google integration needs an access token, or a refresh token with a client id and secret.", needs: "auth" };
  }
  const out = await jfetch("https://oauth2.googleapis.com/token", {
    method: "POST",
    headers: { "content-type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      client_id: creds.clientId,
      client_secret: creds.clientSecret,
      refresh_token: creds.refreshToken,
      grant_type: "refresh_token"
    }).toString()
  }, "Google sign-in");
  if (!out.ok) return { ok: false, error: out.error, needs: out.needs ?? "auth" };
  const token = out.body?.access_token;
  if (!token) return { ok: false, error: "Google did not return an access token.", needs: "auth" };
  return { ok: true, data: token };
}
async function driveSearch(q, creds, limit) {
  const token = await googleToken(creds);
  if (!token.ok) return { ok: false, error: token.error, needs: token.needs };
  const escaped = q.replace(/'/g, "\\'");
  const query = q ? `(name contains '${escaped}' or fullText contains '${escaped}') and trashed = false` : "trashed = false";
  const url = "https://www.googleapis.com/drive/v3/files?" + new URLSearchParams({
    q: query,
    pageSize: String(limit),
    orderBy: "modifiedTime desc",
    fields: "files(id,name,mimeType,modifiedTime,webViewLink,size,owners(displayName))"
  });
  const out = await jfetch(url, { headers: { authorization: `Bearer ${token.data}` } }, "Google Drive");
  if (!out.ok) return { ok: false, error: out.error, needs: out.needs };
  const files = Array.isArray(out.body?.files) ? out.body.files : [];
  return {
    ok: true,
    data: files.map((f) => ({
      integration: "drive",
      id: String(f.id),
      title: String(f.name ?? "Untitled"),
      subtitle: `${String(f.mimeType ?? "").replace("application/vnd.google-apps.", "Google ")}${f.owners?.[0]?.displayName ? ` \xB7 ${f.owners[0].displayName}` : ""}`,
      url: f.webViewLink,
      date: f.modifiedTime,
      kind: "file"
    }))
  };
}
async function driveRead(id, creds) {
  const token = await googleToken(creds);
  if (!token.ok) return { ok: false, error: token.error, needs: token.needs };
  const meta2 = await jfetch(`https://www.googleapis.com/drive/v3/files/${encodeURIComponent(id)}?fields=id,name,mimeType,webViewLink,modifiedTime`, {
    headers: { authorization: `Bearer ${token.data}` }
  }, "Google Drive");
  if (!meta2.ok) return { ok: false, error: meta2.error, needs: meta2.needs };
  const mime = String(meta2.body?.mimeType ?? "");
  const isDoc = mime.startsWith("application/vnd.google-apps");
  const url = isDoc ? `https://www.googleapis.com/drive/v3/files/${encodeURIComponent(id)}/export?mimeType=text/plain` : `https://www.googleapis.com/drive/v3/files/${encodeURIComponent(id)}?alt=media`;
  const body = await jfetch(url, { headers: { authorization: `Bearer ${token.data}` } }, "Google Drive");
  if (!body.ok) return { ok: false, error: body.error, needs: body.needs };
  const text2 = body.body === null ? body.text : JSON.stringify(body.body, null, 2);
  return {
    ok: true,
    data: {
      integration: "drive",
      id,
      title: String(meta2.body?.name ?? id),
      url: meta2.body?.webViewLink,
      text: text2.slice(0, 2e5),
      meta: { mimeType: mime, modifiedTime: meta2.body?.modifiedTime }
    }
  };
}
async function gmailSearch(q, creds, limit) {
  const token = await googleToken(creds);
  if (!token.ok) return { ok: false, error: token.error, needs: token.needs };
  const auth = { authorization: `Bearer ${token.data}` };
  const list = await jfetch("https://gmail.googleapis.com/gmail/v1/users/me/messages?" + new URLSearchParams({ q, maxResults: String(limit) }), { headers: auth }, "Gmail");
  if (!list.ok) return { ok: false, error: list.error, needs: list.needs };
  const ids = (list.body?.messages ?? []).map((m) => String(m.id)).slice(0, limit);
  const hits = await Promise.all(ids.map(async (mid) => {
    const one = await jfetch(`https://gmail.googleapis.com/gmail/v1/users/me/messages/${mid}?format=metadata&metadataHeaders=Subject&metadataHeaders=From&metadataHeaders=Date`, { headers: auth }, "Gmail");
    if (!one.ok) return null;
    const headers = one.body?.payload?.headers ?? [];
    const head = (n) => String(headers.find((h) => String(h.name).toLowerCase() === n.toLowerCase())?.value ?? "");
    return {
      integration: "gmail",
      id: mid,
      title: head("subject") || "(no subject)",
      subtitle: head("from"),
      snippet: String(one.body?.snippet ?? "").slice(0, 300),
      date: new Date(Number(one.body?.internalDate ?? Date.now())).toISOString(),
      kind: "message"
    };
  }));
  return { ok: true, data: hits.filter(Boolean) };
}
function decodeBase64Url(data) {
  try {
    return Buffer.from(data.replace(/-/g, "+").replace(/_/g, "/"), "base64").toString("utf8");
  } catch {
    return "";
  }
}
function gmailText(payload) {
  if (!payload) return "";
  const mime = String(payload.mimeType ?? "");
  if (payload.body?.data && (mime === "text/plain" || !mime.startsWith("multipart"))) return decodeBase64Url(payload.body.data);
  const parts = payload.parts ?? [];
  const plain = parts.filter((p) => String(p.mimeType) === "text/plain").map(gmailText).filter(Boolean);
  if (plain.length) return plain.join("\n\n");
  const html = parts.filter((p) => String(p.mimeType) === "text/html").map(gmailText).join("\n\n");
  if (html) return html.replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim();
  return parts.map(gmailText).filter(Boolean).join("\n\n");
}
async function gmailRead(id, creds) {
  const token = await googleToken(creds);
  if (!token.ok) return { ok: false, error: token.error, needs: token.needs };
  const one = await jfetch(`https://gmail.googleapis.com/gmail/v1/users/me/messages/${encodeURIComponent(id)}?format=full`, {
    headers: { authorization: `Bearer ${token.data}` }
  }, "Gmail");
  if (!one.ok) return { ok: false, error: one.error, needs: one.needs };
  const headers = one.body?.payload?.headers ?? [];
  const head = (n) => String(headers.find((h) => String(h.name).toLowerCase() === n.toLowerCase())?.value ?? "");
  const text2 = gmailText(one.body?.payload) || String(one.body?.snippet ?? "");
  return {
    ok: true,
    data: {
      integration: "gmail",
      id,
      title: head("subject") || "(no subject)",
      text: `From: ${head("from")}
To: ${head("to")}
Date: ${head("date")}

${text2}`.slice(0, 2e5),
      meta: { labels: one.body?.labelIds ?? [], threadId: one.body?.threadId }
    }
  };
}
async function gcalSearch(q, creds, limit) {
  const token = await googleToken(creds);
  if (!token.ok) return { ok: false, error: token.error, needs: token.needs };
  const params = {
    singleEvents: "true",
    orderBy: "startTime",
    maxResults: String(limit),
    timeMin: new Date(Date.now() - 30 * 24 * 3600 * 1e3).toISOString()
  };
  if (q) params.q = q;
  const out = await jfetch("https://www.googleapis.com/calendar/v3/calendars/primary/events?" + new URLSearchParams(params), {
    headers: { authorization: `Bearer ${token.data}` }
  }, "Google Calendar");
  if (!out.ok) return { ok: false, error: out.error, needs: out.needs };
  const items = out.body?.items ?? [];
  return {
    ok: true,
    data: items.map((e) => ({
      integration: "gcal",
      id: String(e.id),
      title: String(e.summary ?? "(no title)"),
      subtitle: e.location ? String(e.location) : e.attendees?.length ? `${e.attendees.length} invited` : "",
      snippet: String(e.description ?? "").slice(0, 300),
      url: e.htmlLink,
      date: e.start?.dateTime ?? e.start?.date,
      kind: "event"
    }))
  };
}
async function gcalRead(id, creds) {
  const token = await googleToken(creds);
  if (!token.ok) return { ok: false, error: token.error, needs: token.needs };
  const out = await jfetch(`https://www.googleapis.com/calendar/v3/calendars/primary/events/${encodeURIComponent(id)}`, {
    headers: { authorization: `Bearer ${token.data}` }
  }, "Google Calendar");
  if (!out.ok) return { ok: false, error: out.error, needs: out.needs };
  const e = out.body ?? {};
  const when = e.start?.dateTime ?? e.start?.date ?? "";
  const attendees = (e.attendees ?? []).map((a) => a.email).filter(Boolean).join(", ");
  return {
    ok: true,
    data: {
      integration: "gcal",
      id,
      title: String(e.summary ?? "(no title)"),
      url: e.htmlLink,
      text: [
        `When: ${when}${e.end?.dateTime ? ` \u2013 ${e.end.dateTime}` : ""}`,
        e.location ? `Where: ${e.location}` : "",
        attendees ? `With: ${attendees}` : "",
        e.description ? `
${String(e.description)}` : ""
      ].filter(Boolean).join("\n").slice(0, 1e5),
      meta: { organizer: e.organizer?.email, status: e.status }
    }
  };
}
async function githubSearch(q, creds, limit) {
  if (!creds.token) return { ok: false, error: "GitHub needs a personal access token.", needs: "auth" };
  const api = (creds.base ?? "https://api.github.com").replace(/\/$/, "");
  const headers = { authorization: `Bearer ${creds.token}`, accept: "application/vnd.github+json", "user-agent": "research-engine" };
  const [issues, code] = await Promise.all([
    jfetch(`${api}/search/issues?${new URLSearchParams({ q, per_page: String(Math.ceil(limit / 2)) })}`, { headers }, "GitHub"),
    q ? jfetch(`${api}/search/code?${new URLSearchParams({ q, per_page: String(Math.floor(limit / 2)) })}`, { headers }, "GitHub") : Promise.resolve(null)
  ]);
  if (!issues.ok) return { ok: false, error: issues.error, needs: issues.needs };
  const hits = (issues.body?.items ?? []).map((i) => ({
    integration: "github",
    id: `issue:${i.number}`,
    title: String(i.title ?? "(untitled)"),
    subtitle: `${i.repository_url?.split("/").slice(-2).join("/") ?? ""} \xB7 ${i.pull_request ? "pull request" : "issue"} \xB7 ${i.state}`,
    url: i.html_url,
    snippet: String(i.body ?? "").slice(0, 300),
    date: i.updated_at,
    kind: "issue"
  }));
  if (code && code.ok) {
    for (const c of code.body?.items ?? []) {
      hits.push({
        integration: "github",
        id: `code:${c.repository?.full_name}:${c.path}`,
        title: String(c.path),
        subtitle: `${c.repository?.full_name ?? ""} \xB7 code`,
        url: c.html_url,
        kind: "file"
      });
    }
  } else if (code && !code.ok && code.needs === "auth") {
  }
  return { ok: true, data: hits };
}
async function githubRead(id, creds) {
  if (!creds.token) return { ok: false, error: "GitHub needs a personal access token.", needs: "auth" };
  const api = (creds.base ?? "https://api.github.com").replace(/\/$/, "");
  const headers = { authorization: `Bearer ${creds.token}`, accept: "application/vnd.github+json", "user-agent": "research-engine" };
  if (id.startsWith("code:")) {
    const [, repo, ...rest] = id.split(":");
    const path = rest.join(":");
    const out = await jfetch(`${api}/repos/${repo}/contents/${path}`, { headers }, "GitHub");
    if (!out.ok) return { ok: false, error: out.error, needs: out.needs };
    const text2 = out.body?.content ? decodeBase64Url(String(out.body.content)) : "";
    return { ok: true, data: { integration: "github", id, title: `${repo}/${path}`, url: out.body?.html_url, text: text2.slice(0, 2e5) } };
  }
  return { ok: false, error: "Open an issue or a file from a GitHub search result to read it." };
}
async function notionSearch(q, creds, limit) {
  if (!creds.token) return { ok: false, error: "Notion needs an internal integration token.", needs: "auth" };
  const api = (creds.base ?? "https://api.notion.com").replace(/\/$/, "");
  const out = await jfetch(`${api}/v1/search`, {
    method: "POST",
    headers: { authorization: `Bearer ${creds.token}`, "notion-version": "2022-06-28" },
    json: { query: q, page_size: limit }
  }, "Notion");
  if (!out.ok) return { ok: false, error: out.error, needs: out.needs };
  const results = out.body?.results ?? [];
  return {
    ok: true,
    data: results.map((r) => {
      const title = (r.properties?.title?.title ?? r.properties?.Name?.title ?? []).map((t) => t.plain_text).join("") || (r.title ?? []).map((t) => t.plain_text).join("") || "(untitled)";
      return {
        integration: "notion",
        id: String(r.id),
        title: title || "(untitled)",
        subtitle: r.object === "database" ? "database" : "page",
        url: r.url,
        date: r.last_edited_time,
        kind: "page"
      };
    })
  };
}
async function notionRead(id, creds) {
  if (!creds.token) return { ok: false, error: "Notion needs an internal integration token.", needs: "auth" };
  const api = (creds.base ?? "https://api.notion.com").replace(/\/$/, "");
  const headers = { authorization: `Bearer ${creds.token}`, "notion-version": "2022-06-28" };
  const out = await jfetch(`${api}/v1/blocks/${encodeURIComponent(id)}/children?page_size=100`, { headers }, "Notion");
  if (!out.ok) return { ok: false, error: out.error, needs: out.needs };
  const line = (b) => {
    const rich = b[b.type]?.rich_text ?? [];
    const text3 = rich.map((r) => r.plain_text).join("");
    return b.type === "bulleted_list_item" || b.type === "numbered_list_item" ? `- ${text3}` : text3;
  };
  const text2 = (out.body?.results ?? []).map(line).filter(Boolean).join("\n");
  return { ok: true, data: { integration: "notion", id, title: "Notion page", text: text2.slice(0, 2e5) } };
}
async function slackSearch(q, creds, limit) {
  if (!creds.token) return { ok: false, error: "Slack needs a user token with search:read.", needs: "auth" };
  const api = (creds.base ?? "https://slack.com/api").replace(/\/$/, "");
  const out = await jfetch(`${api}/search.messages?${new URLSearchParams({ query: q, count: String(limit) })}`, {
    headers: { authorization: `Bearer ${creds.token}` }
  }, "Slack");
  if (!out.ok) return { ok: false, error: out.error, needs: out.needs };
  if (out.body?.ok === false) {
    const err = String(out.body?.error ?? "unknown_error");
    return { ok: false, error: `Slack: ${err}${err === "not_allowed_token_type" ? " \u2014 use a user token with search:read." : ""}`, needs: "auth" };
  }
  const matches2 = out.body?.messages?.matches ?? [];
  return {
    ok: true,
    data: matches2.map((m) => ({
      integration: "slack",
      id: `${m.channel?.id ?? "ch"}:${m.ts}`,
      title: String(m.text ?? "").slice(0, 120) || "(message)",
      subtitle: `#${m.channel?.name ?? "channel"}${m.username ? ` \xB7 ${m.username}` : ""}`,
      snippet: String(m.text ?? "").slice(0, 300),
      url: m.permalink,
      date: m.ts ? new Date(Number(m.ts) * 1e3).toISOString() : void 0,
      kind: "message"
    }))
  };
}
async function slackRead(id, creds) {
  if (!creds.token) return { ok: false, error: "Slack needs a user token with search:read.", needs: "auth" };
  const api = (creds.base ?? "https://slack.com/api").replace(/\/$/, "");
  const [channel, ts] = id.split(":");
  const out = await jfetch(`${api}/conversations.replies?${new URLSearchParams({ channel, ts })}`, {
    headers: { authorization: `Bearer ${creds.token}` }
  }, "Slack");
  if (!out.ok) return { ok: false, error: out.error, needs: out.needs };
  if (out.body?.ok === false) return { ok: false, error: `Slack: ${String(out.body?.error ?? "unknown_error")}`, needs: "auth" };
  const msgs = out.body?.messages ?? [];
  return {
    ok: true,
    data: {
      integration: "slack",
      id,
      title: `Slack thread (${msgs.length} message${msgs.length === 1 ? "" : "s"})`,
      text: msgs.map((m) => `${m.user ?? "someone"}: ${m.text ?? ""}`).join("\n").slice(0, 1e5)
    }
  };
}
async function filesSearch(rt, q, limit) {
  const { readdir: readdir6, stat: stat5 } = await import("node:fs/promises");
  const { join: join17 } = await import("node:path");
  const root = join17(rt.dataDir, "files");
  const hits = [];
  const walk2 = async (dir, depth) => {
    if (depth > 2 || hits.length >= limit) return;
    let entries = [];
    try {
      entries = await readdir6(dir);
    } catch {
      return;
    }
    for (const name of entries) {
      if (hits.length >= limit) return;
      const full = join17(dir, name);
      let st = null;
      try {
        st = await stat5(full);
      } catch {
        continue;
      }
      if (st.isDirectory()) {
        await walk2(full, depth + 1);
        continue;
      }
      if (q && !name.toLowerCase().includes(q.toLowerCase())) continue;
      hits.push({
        integration: "files",
        id: name,
        title: name,
        subtitle: `${Math.max(1, Math.round(st.size / 1024))} KB${depth ? ` \xB7 ${full.slice(root.length + 1).split(/[\\/]/).slice(0, -1).join("/")}` : ""}`,
        date: new Date(st.mtimeMs).toISOString(),
        kind: "file"
      });
    }
  };
  await walk2(root, 0);
  return { ok: true, data: hits };
}
async function searchIntegration(rt, id, q, creds, limit = 12) {
  switch (id) {
    case "files":
      return filesSearch(rt, q, limit);
    case "drive":
      return driveSearch(q, creds, limit);
    case "gmail":
      return gmailSearch(q, creds, limit);
    case "gcal":
      return gcalSearch(q, creds, limit);
    case "github":
      return githubSearch(q, creds, limit);
    case "notion":
      return notionSearch(q, creds, limit);
    case "slack":
      return slackSearch(q, creds, limit);
    default:
      return { ok: false, error: `Unknown integration "${id}".` };
  }
}
async function readIntegration(rt, id, itemId, creds) {
  switch (id) {
    case "files": {
      const { readFile: readFile8 } = await import("node:fs/promises");
      const { join: join17, basename } = await import("node:path");
      try {
        const text2 = await readFile8(join17(rt.dataDir, "files", basename(itemId)), "utf8");
        return { ok: true, data: { integration: "files", id: itemId, title: itemId, text: text2.slice(0, 2e5) } };
      } catch (e) {
        return { ok: false, error: `Could not read ${itemId}: ${String(e?.message ?? e)}` };
      }
    }
    case "drive":
      return driveRead(itemId, creds);
    case "gmail":
      return gmailRead(itemId, creds);
    case "gcal":
      return gcalRead(itemId, creds);
    case "github":
      return githubRead(itemId, creds);
    case "notion":
      return notionRead(itemId, creds);
    case "slack":
      return slackRead(itemId, creds);
    default:
      return { ok: false, error: `Unknown integration "${id}".` };
  }
}
async function probeIntegration(id, creds) {
  switch (id) {
    case "files":
      return { ok: true, data: { detail: "Your local workspace folder \u2014 always available." } };
    case "drive":
    case "gmail":
    case "gcal": {
      const token = await googleToken(creds);
      if (!token.ok) return { ok: false, error: token.error, needs: token.needs };
      const out = await jfetch("https://www.googleapis.com/oauth2/v3/userinfo", { headers: { authorization: `Bearer ${token.data}` } }, "Google");
      if (!out.ok) return { ok: false, error: out.error, needs: out.needs };
      const scopes = out.res.headers.get("x-oauth-scopes") ?? "";
      return { ok: true, data: { account: String(out.body?.email ?? ""), detail: scopes ? `Scopes: ${scopes}` : "Signed in." } };
    }
    case "github": {
      if (!creds.token) return { ok: false, error: "GitHub needs a personal access token.", needs: "auth" };
      const api = (creds.base ?? "https://api.github.com").replace(/\/$/, "");
      const out = await jfetch(`${api}/user`, { headers: { authorization: `Bearer ${creds.token}`, "user-agent": "research-engine" } }, "GitHub");
      if (!out.ok) return { ok: false, error: out.error, needs: out.needs };
      const scopes = out.res.headers.get("x-oauth-scopes");
      return { ok: true, data: { account: String(out.body?.login ?? ""), detail: scopes ? `Scopes: ${scopes}` : `Signed in as ${String(out.body?.login ?? "")}.` } };
    }
    case "notion": {
      if (!creds.token) return { ok: false, error: "Notion needs an internal integration token.", needs: "auth" };
      const api = (creds.base ?? "https://api.notion.com").replace(/\/$/, "");
      const out = await jfetch(`${api}/v1/users/me`, { headers: { authorization: `Bearer ${creds.token}`, "notion-version": "2022-06-28" } }, "Notion");
      if (!out.ok) return { ok: false, error: out.error, needs: out.needs };
      return { ok: true, data: { account: String(out.body?.name ?? out.body?.bot?.owner?.user?.name ?? ""), detail: "Integration token accepted." } };
    }
    case "slack": {
      if (!creds.token) return { ok: false, error: "Slack needs a user token with search:read.", needs: "auth" };
      const api = (creds.base ?? "https://slack.com/api").replace(/\/$/, "");
      const out = await jfetch(`${api}/auth.test`, { headers: { authorization: `Bearer ${creds.token}` } }, "Slack");
      if (!out.ok) return { ok: false, error: out.error, needs: out.needs };
      if (out.body?.ok === false) return { ok: false, error: `Slack: ${String(out.body?.error ?? "unknown_error")}`, needs: "auth" };
      return { ok: true, data: { account: String(out.body?.user ?? ""), detail: `Team ${String(out.body?.team ?? "")}.` } };
    }
    default:
      return { ok: false, error: `Unknown integration "${id}".` };
  }
}
var INTEGRATION_DEFS, integrationDef, TIMEOUT_MS2, mapStatus;
var init_integrations = __esm({
  "src/services/integrations/index.ts"() {
    "use strict";
    INTEGRATION_DEFS = [
      {
        id: "files",
        name: "Local files",
        auth: "none",
        scopes: ["read:workspace"],
        docs: "",
        hint: "Everything in your Research Engine workspace folder. No account needed."
      },
      {
        id: "drive",
        name: "Google Drive",
        auth: "token",
        scopes: ["drive.readonly"],
        docs: "https://developers.google.com/drive/api/guides/api-specific-auth",
        hint: "A Google OAuth access token (or a refresh token + client id/secret) with drive.readonly."
      },
      {
        id: "gmail",
        name: "Gmail",
        auth: "token",
        scopes: ["gmail.readonly"],
        docs: "https://developers.google.com/gmail/api/auth/scopes",
        hint: "Same Google connection as Drive \u2014 gmail.readonly is enough to search and read mail."
      },
      {
        id: "gcal",
        name: "Google Calendar",
        auth: "token",
        scopes: ["calendar.readonly"],
        docs: "https://developers.google.com/calendar/api/guides/auth",
        hint: "calendar.readonly. Events are read only \u2014 nothing is ever written back."
      },
      {
        id: "github",
        name: "GitHub",
        auth: "token",
        scopes: ["repo:read", "issues:read"],
        docs: "https://github.com/settings/tokens",
        hint: "A fine-grained token with read-only access to the repositories you want the agent to see."
      },
      {
        id: "notion",
        name: "Notion",
        auth: "token",
        scopes: ["read_content"],
        docs: "https://www.notion.so/my-integrations",
        hint: "An internal integration token \u2014 remember to share the pages with it in Notion."
      },
      {
        id: "slack",
        name: "Slack",
        auth: "token",
        scopes: ["search:read"],
        docs: "https://api.slack.com/authentication/token-types",
        hint: "A user token with search:read (bot tokens cannot search messages)."
      }
    ];
    integrationDef = (id) => INTEGRATION_DEFS.find((d) => d.id === id);
    TIMEOUT_MS2 = 12e3;
    mapStatus = (status, what) => {
      if (status === 401 || status === 403) return { error: `${what} refused the credential (${status}). Check the token and its scopes.`, needs: "auth" };
      if (status === 404) return { error: `${what} has no such item (404).` };
      if (status === 429) return { error: `${what} is rate-limiting this token (429). Try again in a moment.`, needs: "rate-limit" };
      return { error: `${what} answered ${status}.` };
    };
  }
});

// src/routes/integrations.ts
var integrations_exports = {};
__export(integrations_exports, {
  integrationRoutes: () => integrationRoutes
});
import { Hono as Hono11 } from "hono";
function integrationRoutes(rt) {
  const r = new Hono11();
  const isId = (v) => INTEGRATION_DEFS.some((d) => d.id === v);
  const configured = (creds) => INTEGRATION_DEFS.filter((d) => d.auth === "none" || !!creds[d.id]?.token || !!creds[d.id]?.refreshToken).map((d) => d.id);
  r.get("/integrations", (c) => {
    const creds = credsFrom(c.req.header("x-re-integrations"));
    return c.json({
      integrations: INTEGRATION_DEFS.map((d) => ({
        ...d,
        // Never the token itself — only whether one arrived and how it authenticates.
        connected: d.auth === "none" ? true : !!(creds[d.id]?.token || creds[d.id]?.refreshToken),
        via: d.auth === "none" ? "local" : creds[d.id]?.refreshToken && !creds[d.id]?.token ? "refresh-token" : creds[d.id]?.token ? "access-token" : null
      }))
    });
  });
  r.get("/integrations/search", async (c) => {
    const q = (c.req.query("q") ?? "").trim();
    const creds = credsFrom(c.req.header("x-re-integrations"));
    const limit = Math.max(1, Math.min(25, Number(c.req.query("limit")) || 12));
    const asked = (c.req.query("ids") ?? "").split(",").map((s) => s.trim()).filter(Boolean);
    const ids = asked.length ? asked.filter(isId) : configured(creds);
    if (!ids.length) {
      return c.json({
        q,
        results: [],
        errors: [],
        note: "No integration is connected yet. Connect one in Settings \u2192 Integrations, or from the composer\u2019s plug menu."
      });
    }
    const settled = await Promise.all(ids.map(async (id) => {
      const out = await searchIntegration(rt, id, q, creds[id] ?? {}, limit);
      return { id, out };
    }));
    const results = settled.flatMap(({ out }) => out.ok ? out.data ?? [] : []).sort((a, b) => String(b.date ?? "").localeCompare(String(a.date ?? ""))).slice(0, limit * 2);
    const errors = settled.filter((s) => !s.out.ok).map((s) => ({
      integration: s.id,
      name: integrationDef(s.id)?.name ?? s.id,
      error: s.out.error,
      needs: s.out.needs ?? null
    }));
    return c.json({
      q,
      counts: settled.map((s) => ({ integration: s.id, n: s.out.ok ? (s.out.data ?? []).length : 0 })),
      results,
      errors,
      connected: configured(creds)
    });
  });
  r.get("/integrations/read", async (c) => {
    const integration = c.req.query("integration") ?? "";
    const id = c.req.query("id") ?? "";
    if (!isId(integration)) return c.json({ error: "Unknown integration." }, 400);
    if (!id) return c.json({ error: "Missing item id." }, 400);
    const creds = credsFrom(c.req.header("x-re-integrations"));
    const out = await readIntegration(rt, integration, id, creds[integration] ?? {});
    if (!out.ok) return c.json({ error: out.error, needs: out.needs ?? null, integration }, out.needs === "auth" ? 401 : 502);
    return c.json(out.data);
  });
  r.get("/integrations/probe", async (c) => {
    const integration = c.req.query("integration") ?? "";
    if (!isId(integration)) return c.json({ error: "Unknown integration." }, 400);
    const creds = credsFrom(c.req.header("x-re-integrations"));
    const out = await probeIntegration(integration, creds[integration] ?? {});
    if (!out.ok) return c.json({ error: out.error, needs: out.needs ?? null, integration }, out.needs === "auth" ? 401 : 502);
    return c.json({ integration, ...out.data });
  });
  return r;
}
var init_integrations2 = __esm({
  "src/routes/integrations.ts"() {
    "use strict";
    init_integrations();
  }
});

// src/routes/resources.ts
var resources_exports = {};
__export(resources_exports, {
  resourceRoutes: () => resourceRoutes
});
import { existsSync as existsSync7, statSync as statSync5 } from "node:fs";
import { join as join7 } from "node:path";
import { Hono as Hono12 } from "hono";
function resourceRoutes(rt) {
  const r = new Hono12();
  r.get("/resources", (c) => {
    const mem2 = process.memoryUsage();
    const dbFile = rt.dbPath;
    return c.json({
      ok: true,
      process: {
        rssMB: Math.round(mem2.rss / 1048576),
        heapMB: Math.round(mem2.heapUsed / 1048576),
        uptimeSec: Math.round(process.uptime()),
        node: process.version
      },
      dataDir: {
        path: rt.dataDir,
        totalMB: +(dirSize(rt.dataDir) / 1048576).toFixed(1)
      },
      db: {
        ...dbStats(),
        sizeMB: existsSync7(dbFile) ? +(statSync5(dbFile).size / 1048576).toFixed(2) : 0
      },
      cacheMB: +(dirSize(join7(rt.dataDir, "cache")) / 1048576).toFixed(1),
      profile: rt.profile,
      caps: rt.caps,
      profiles: Object.fromEntries(Object.entries(PROFILES).map(([k, v]) => [k, { description: v.description }]))
    });
  });
  r.get("/config", (c) => c.json({
    ok: true,
    port: rt.port,
    dataDir: rt.dataDir,
    profile: rt.profile,
    caps: rt.caps,
    frontendServed: !!rt.frontendDist
  }));
  r.post("/config", async (c) => {
    const body = await c.req.json().catch(() => ({}));
    if (body.profile && body.profile in PROFILES) {
      const profile = body.profile;
      rt.profile = profile;
      rt.caps = PROFILES[profile];
      saveConfig(rt.dataDir, { profile });
      return c.json({ ok: true, profile, caps: rt.caps });
    }
    return c.json({ ok: false, error: "Unknown profile" }, 400);
  });
  return r;
}
var init_resources = __esm({
  async "src/routes/resources.ts"() {
    "use strict";
    await init_db();
    init_runtime();
  }
});

// src/preview/paths.ts
import { isAbsolute as isAbsolute2, join as join8, relative as relative3, resolve as resolve5 } from "node:path";
function projectsRootOf(dataDir) {
  return resolve5(join8(dataDir, "projects"));
}
function isInternalEntry(name) {
  return INTERNAL_PREFIX.some((p) => name.startsWith(p));
}
function tidy(n) {
  return n.replace(/[. ]+$/, "");
}
function normalizeProjectName(raw) {
  const original = String(raw ?? "");
  let n = original.replace(ILLEGAL, " ").replace(/\s+/g, " ").trim();
  n = tidy(n);
  if (!n) return null;
  if (n === "." || n === "..") n = `project${n === "." ? "" : "-dot"}`;
  if (WINDOWS_DEVICE.test(n)) n = `${n}-project`;
  if (Buffer.byteLength(n, "utf8") > 128) {
    while (Buffer.byteLength(n, "utf8") > 128) n = n.slice(0, -1);
    n = tidy(n);
  }
  if (!n) return null;
  return { name: n, changed: n !== original.trim().replace(/\s+/g, " ") };
}
function normPath(p) {
  const unified = p.replace(/[\\/]+/g, "/").replace(/\/+$/, "");
  return process.platform === "win32" ? unified.toLowerCase() : unified;
}
function isWithinDir(parent, child) {
  if (normPath(parent) === normPath(child)) return true;
  const rel = relative3(parent, child);
  if (rel !== "" && !rel.startsWith("..") && !isAbsolute2(rel)) return true;
  return normPath(child).startsWith(normPath(parent) + "/");
}
function isStrictlyWithinDir(parent, child) {
  return normPath(parent) !== normPath(child) && isWithinDir(parent, child);
}
function safeProjectName(name) {
  return normalizeProjectName(name)?.name ?? null;
}
function projectDirOf(projectsRoot, name) {
  const n = safeProjectName(name);
  if (!n) return null;
  const abs = resolve5(join8(projectsRoot, n));
  return isStrictlyWithinDir(projectsRoot, abs) ? abs : null;
}
function projectDirFor(projectsRoot, name) {
  const normalized = normalizeProjectName(name);
  if (!normalized) return null;
  const abs = resolve5(join8(projectsRoot, normalized.name));
  if (!isStrictlyWithinDir(projectsRoot, abs)) return null;
  return { dir: abs, ...normalized };
}
var INTERNAL_PREFIX, ILLEGAL, WINDOWS_DEVICE;
var init_paths = __esm({
  "src/preview/paths.ts"() {
    "use strict";
    INTERNAL_PREFIX = [".import-", ".tmp-", ".trash-"];
    ILLEGAL = /[<>:"/\\|?*\u0000-\u001f\u007f]/g;
    WINDOWS_DEVICE = /^(con|prn|aux|nul|com[1-9]|lpt[1-9])(\..*)?$/i;
  }
});

// src/routes/fs.ts
var fs_exports = {};
__export(fs_exports, {
  fsRoutes: () => fsRoutes
});
import { mkdir, readFile, readdir, stat, writeFile } from "node:fs/promises";
import { dirname as dirname4, join as join9, resolve as resolve6 } from "node:path";
import { Hono as Hono13 } from "hono";
function fsRoutes(rt) {
  const r = new Hono13();
  const root = resolve6(join9(rt.dataDir, "files"));
  const safePath = (rel) => {
    if (!rel || rel.startsWith("/") || rel.includes("..")) return null;
    const abs = resolve6(join9(root, rel));
    return isWithinDir(root, abs) ? abs : null;
  };
  r.get("/fs/read", async (c) => {
    const rel = c.req.query("path") ?? "";
    const abs = safePath(rel);
    if (!abs) return c.text("Path must stay inside the Research Engine files folder.", 400);
    try {
      return c.text(await readFile(abs, "utf8"));
    } catch {
      return c.text("File not found.", 404);
    }
  });
  r.post("/fs/write", async (c) => {
    let body;
    try {
      body = await c.req.json();
    } catch {
      return c.text("Invalid JSON body.", 400);
    }
    const abs = safePath(body.path ?? "");
    if (!abs) return c.text("Path must stay inside the Research Engine files folder.", 400);
    if (typeof body.content !== "string") return c.text("Missing content.", 400);
    if (body.content.length > 2e6) return c.text("Content too large (2 MB limit).", 413);
    await mkdir(dirname4(abs), { recursive: true });
    await writeFile(abs, body.content, "utf8");
    return c.json({ ok: true, path: body.path });
  });
  r.get("/fs/read-bin", async (c) => {
    const rel = c.req.query("path") ?? "";
    const abs = safePath(rel);
    if (!abs) return c.text("Path must stay inside the Research Engine files folder.", 400);
    try {
      const buf = await readFile(abs);
      const ext = abs.toLowerCase();
      const type = ext.endsWith(".pdf") ? "application/pdf" : ext.endsWith(".docx") ? "application/vnd.openxmlformats-officedocument.wordprocessingml.document" : "application/octet-stream";
      return c.body(new Uint8Array(buf), 200, { "content-type": type });
    } catch {
      return c.text("File not found.", 404);
    }
  });
  r.get("/fs/list", async (c) => {
    await mkdir(root, { recursive: true });
    let entries = [];
    try {
      const list = await readdir(root, { withFileTypes: true });
      entries = await Promise.all(list.map(async (e) => {
        if (e.name.startsWith(".")) return null;
        const dir = e.isDirectory();
        let size = 0;
        if (!dir) {
          try {
            size = (await stat(join9(root, e.name))).size;
          } catch {
          }
        }
        return { name: e.name, dir, size };
      })).then((a) => a.filter(Boolean));
      entries.sort((x, y) => Number(y.dir) - Number(x.dir) || x.name.localeCompare(y.name));
    } catch {
    }
    return c.json({ root, files: entries });
  });
  r.post("/fs/upload", async (c) => {
    let body;
    try {
      body = await c.req.json();
    } catch {
      return c.text("Invalid JSON body.", 400);
    }
    const name = (body.name ?? "").replace(/[\\/]/g, "_").trim();
    if (!name || name.startsWith(".")) return c.text("Missing file name.", 400);
    if (typeof body.dataBase64 !== "string") return c.text("Missing dataBase64.", 400);
    const buf = Buffer.from(body.dataBase64, "base64");
    if (buf.length > 8 * 1024 * 1024) return c.text("File too large (8 MB limit).", 413);
    const abs = safePath(name);
    if (!abs) return c.text("File name must stay inside the Research Engine files folder.", 400);
    await mkdir(dirname4(abs), { recursive: true });
    await writeFile(abs, buf);
    return c.json({ ok: true, path: name, size: buf.length });
  });
  return r;
}
var init_fs = __esm({
  "src/routes/fs.ts"() {
    "use strict";
    init_paths();
  }
});

// src/routes/providers.ts
var providers_exports = {};
__export(providers_exports, {
  providerRoutes: () => providerRoutes
});
import { Hono as Hono14 } from "hono";
async function discover(kind, base, key, timeout) {
  const t0 = Date.now();
  try {
    if (kind === "ollama") {
      const res2 = await fetch(`${base}/api/tags`, { signal: AbortSignal.timeout(timeout) });
      if (!res2.ok) return { error: `Ollama responded ${res2.status}`, ms: Date.now() - t0 };
      const json2 = await res2.json();
      return { models: (json2.models ?? []).map((m) => String(m.name)), ms: Date.now() - t0 };
    }
    const headers = {
      // NVIDIA NIM UA-dialect: its gateways 403 generic user-agents.
      "user-agent": base.includes("api.nvidia.com") || kind === "nim" ? "NVIDIA-NIM-Client/1.0" : "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
      accept: "application/json"
    };
    if (base.includes("openrouter.ai")) {
      headers["HTTP-Referer"] = "https://researchengine.local";
      headers["X-OpenRouter-Title"] = "Research Engine";
    }
    if (kind === "anthropic") {
      headers["x-api-key"] = key;
      headers["anthropic-version"] = "2023-06-01";
    } else if (kind === "gemini") {
      headers["x-goog-api-key"] = key;
    } else if (key) {
      headers.authorization = `Bearer ${key}`;
    }
    const res = await fetch(`${base}/models`, { headers, signal: AbortSignal.timeout(timeout) });
    if (!res.ok) {
      let msg = `Provider responded ${res.status}`;
      try {
        const j = await res.json();
        msg = j?.error?.message ?? j?.detail ?? j?.message ?? msg;
      } catch {
      }
      if (res.status === 403 && (base.includes("api.nvidia.com") || kind === "nim")) {
        msg += " \u2014 NVIDIA may allow model listing while blocking inference. Check Public API Endpoints access, model terms, key status, and current model availability.";
      }
      return { error: maskSecrets(msg), ms: Date.now() - t0 };
    }
    const json = await res.json();
    if (kind === "gemini") {
      const models2 = (json.models ?? []).filter((m) => Array.isArray(m?.supportedGenerationMethods) && m.supportedGenerationMethods.includes("generateContent")).map((m) => String(m.name ?? "").replace(/^models\//, "")).filter(Boolean);
      return { models: models2, ms: Date.now() - t0 };
    }
    const models = (json.data ?? []).map((m) => String(m.id ?? m.name)).filter(Boolean);
    return { models, ms: Date.now() - t0 };
  } catch (e) {
    const msg = e?.name === "TimeoutError" || e?.name === "AbortError" ? `Timed out after ${Math.round(timeout / 1e3)}s` : e?.message ?? "Network error";
    return { error: msg, ms: Date.now() - t0 };
  }
}
function args(c) {
  const kind = c.req.query("kind") ?? "openai";
  const base = (c.req.query("base") ?? "").replace(/\/+$/, "");
  const key = c.req.header("x-re-key") ?? "";
  return { kind, base, key };
}
var providerRoutes, MODELS_TIMEOUT_MS, TEST_TIMEOUT_MS;
var init_providers = __esm({
  "src/routes/providers.ts"() {
    "use strict";
    init_secrets();
    providerRoutes = new Hono14();
    MODELS_TIMEOUT_MS = 8e3;
    TEST_TIMEOUT_MS = 6e3;
    providerRoutes.get("/providers/models", async (c) => {
      const { kind, base, key } = args(c);
      if (!base) return c.json({ error: "base is required" }, 400);
      const out = await discover(kind, base, key, MODELS_TIMEOUT_MS);
      if (out.error) return c.json(out, 502);
      return c.json(out);
    });
    providerRoutes.get("/providers/test", async (c) => {
      const { kind, base, key } = args(c);
      if (!base) return c.json({ error: "base is required" }, 400);
      const out = await discover(kind, base, key, TEST_TIMEOUT_MS);
      if (out.error) return c.json(out, 502);
      return c.json({ ms: out.ms });
    });
  }
});

// src/preview/worktree.ts
import { createHash as createHash3 } from "node:crypto";
import { mkdir as mkdir2, readFile as readFile2, readdir as readdir2, rm, stat as stat2, writeFile as writeFile2, copyFile } from "node:fs/promises";
import { join as join10, relative as relative4 } from "node:path";
function sha1(text2) {
  return createHash3("sha1").update(text2).digest("hex");
}
function agentIdOk(id) {
  return /^[a-z0-9][a-z0-9-]{2,39}$/.test(id);
}
async function walk(root, rel = "", out = []) {
  let entries;
  try {
    entries = await readdir2(join10(root, rel), { withFileTypes: true });
  } catch {
    return out;
  }
  for (const e of entries) {
    if (e.name.startsWith(".re-agent")) continue;
    if (e.isDirectory()) {
      if (WT_SKIP.has(e.name)) continue;
      await walk(root, rel ? `${rel}/${e.name}` : e.name, out);
    } else {
      out.push(rel ? `${rel}/${e.name}` : e.name);
    }
  }
  return out;
}
async function snapshotTree(root) {
  const files = await walk(root);
  const out = {};
  for (const rel of files.slice(0, MAX_FILES2)) {
    try {
      const st = await stat2(join10(root, rel));
      if (st.size > MAX_FILE_BYTES2) continue;
      out[rel] = sha1(await readFile2(join10(root, rel)));
    } catch {
    }
  }
  return out;
}
async function forkTree(projectDir, worktreeDir) {
  await rm(worktreeDir, { recursive: true, force: true });
  await mkdir2(worktreeDir, { recursive: true });
  const files = await walk(projectDir);
  const base = {};
  const skipped = [];
  let bytes = 0;
  for (const rel of files) {
    if (Object.keys(base).length >= MAX_FILES2) {
      skipped.push(rel);
      continue;
    }
    const src = join10(projectDir, rel);
    try {
      const st = await stat2(src);
      if (st.size > MAX_FILE_BYTES2) {
        skipped.push(rel);
        continue;
      }
      if (bytes + st.size > MAX_TOTAL_BYTES2) {
        skipped.push(rel);
        continue;
      }
      const content = await readFile2(src);
      const dest = join10(worktreeDir, rel);
      await mkdir2(join10(dest, ".."), { recursive: true });
      await writeFile2(dest, content);
      base[rel] = sha1(content);
      bytes += st.size;
    } catch {
      skipped.push(rel);
    }
  }
  await writeFile2(join10(worktreeDir, ".re-agent-base.json"), JSON.stringify(base, null, 2), "utf8");
  return { files: Object.keys(base).length, bytes, base, skipped };
}
async function readBase(worktreeDir) {
  try {
    return JSON.parse(await readFile2(join10(worktreeDir, ".re-agent-base.json"), "utf8"));
  } catch {
    return {};
  }
}
async function changesIn(worktreeDir) {
  const base = await readBase(worktreeDir);
  const now = await snapshotTree(worktreeDir);
  const paths = /* @__PURE__ */ new Set([...Object.keys(base), ...Object.keys(now)]);
  const out = [];
  for (const path of paths) {
    if (path === ".re-agent-base.json") continue;
    const was = base[path];
    const is = now[path];
    if (was && is && was === is) continue;
    if (was && !is) {
      out.push({ path, kind: "deleted", added: 0, removed: 0 });
      continue;
    }
    out.push({ path, kind: was ? "modified" : "added", added: 0, removed: 0 });
  }
  return out.sort((a, b) => a.path.localeCompare(b.path));
}
function lineDelta(baseText, nextText) {
  const a = baseText.split("\n");
  const b = nextText.split("\n");
  let head = 0;
  while (head < a.length && head < b.length && a[head] === b[head]) head++;
  let tail = 0;
  while (tail < a.length - head && tail < b.length - head && a[a.length - 1 - tail] === b[b.length - 1 - tail]) tail++;
  const midA = a.slice(head, a.length - tail);
  const midB = b.slice(head, b.length - tail);
  if (!midA.length) return { added: midB.length, removed: 0 };
  if (!midB.length) return { added: 0, removed: midA.length };
  if (midA.length * midB.length > 25e4) {
    return { added: midB.length, removed: midA.length };
  }
  let dp = new Array(midB.length + 1).fill(0);
  for (let i = 1; i <= midA.length; i++) {
    const next = new Array(midB.length + 1).fill(0);
    for (let j = 1; j <= midB.length; j++) {
      next[j] = midA[i - 1] === midB[j - 1] ? dp[j - 1] + 1 : Math.max(dp[j], next[j - 1]);
    }
    dp = next;
  }
  const common = dp[midB.length];
  return { added: midB.length - common, removed: midA.length - common };
}
async function mergeTree(opts) {
  const { worktreeDir, projectDir } = opts;
  const base = await readBase(worktreeDir);
  const changes = await changesIn(worktreeDir);
  const only = opts.only && opts.only.length ? new Set(opts.only) : null;
  const merged = [];
  const conflicts = [];
  const unchanged = [];
  const missing = [];
  for (const change of changes) {
    const path = change.path;
    if (only && !only.has(path)) {
      unchanged.push(path);
      continue;
    }
    const projectPath = join10(projectDir, path);
    const worktreePath = join10(worktreeDir, path);
    const baseHash = base[path];
    if (change.kind === "deleted") {
      let current = null;
      try {
        current = sha1(await readFile2(projectPath));
      } catch {
        current = null;
      }
      if (current === null) {
        unchanged.push(path);
        continue;
      }
      if (baseHash && current !== baseHash) {
        conflicts.push({ path, reason: "Changed in the project since this agent started \u2014 kept, nothing deleted." });
        continue;
      }
      await rm(projectPath, { force: true });
      merged.push(path);
      continue;
    }
    let agentContent;
    try {
      agentContent = await readFile2(worktreePath);
    } catch {
      missing.push(path);
      continue;
    }
    const agentHash = sha1(agentContent);
    if (baseHash && agentHash === baseHash) {
      unchanged.push(path);
      continue;
    }
    let currentHash = null;
    try {
      currentHash = sha1(await readFile2(projectPath));
    } catch {
      currentHash = null;
    }
    if (currentHash === null) {
      await mkdir2(join10(projectPath, ".."), { recursive: true });
      await writeFile2(projectPath, agentContent);
      merged.push(path);
      continue;
    }
    if (!baseHash || currentHash === baseHash || currentHash === agentHash) {
      await mkdir2(join10(projectPath, ".."), { recursive: true });
      await writeFile2(projectPath, agentContent);
      merged.push(path);
      continue;
    }
    const stamp = new Date(opts.now ?? Date.now()).toISOString().replace(/[:.]/g, "-");
    const aside = `${projectPath}.agent-conflict-${stamp}`;
    try {
      await copyFile(worktreePath, aside);
    } catch {
    }
    conflicts.push({
      path,
      reason: baseHash ? "You (or another agent) edited this file after the fork \u2014 this agent's version was kept aside." : "This file already existed in the project \u2014 this agent's version was kept aside."
    });
  }
  return { merged, conflicts, unchanged, missing };
}
function worktreePathFor(worktreesRoot, project, agent, projectIsSafe) {
  if (!agentIdOk(agent)) return null;
  if (!projectIsSafe(project)) return null;
  return join10(worktreesRoot, project, agent);
}
function describeChanges(changes) {
  if (!changes.length) return "no file changes";
  const added = changes.filter((c) => c.kind === "added").length;
  const modified = changes.filter((c) => c.kind === "modified").length;
  const deleted = changes.filter((c) => c.kind === "deleted").length;
  const bits = [added ? `${added} added` : "", modified ? `${modified} edited` : "", deleted ? `${deleted} deleted` : ""].filter(Boolean);
  return `${changes.length} file${changes.length === 1 ? "" : "s"} \u2014 ${bits.join(", ")}`;
}
var WT_SKIP, MAX_FILES2, MAX_FILE_BYTES2, MAX_TOTAL_BYTES2;
var init_worktree = __esm({
  "src/preview/worktree.ts"() {
    "use strict";
    WT_SKIP = /* @__PURE__ */ new Set([
      "node_modules",
      ".git",
      "dist",
      "build",
      ".next",
      ".nuxt",
      ".output",
      "out",
      "coverage",
      "__pycache__",
      ".venv",
      "venv",
      ".turbo",
      ".cache",
      ".parcel-cache",
      "target",
      "vendor",
      ".pytest_cache",
      ".mypy_cache",
      ".idea",
      ".vscode",
      ".gradle"
    ]);
    MAX_FILES2 = 4e3;
    MAX_FILE_BYTES2 = 4 * 1024 * 1024;
    MAX_TOTAL_BYTES2 = 64 * 1024 * 1024;
  }
});

// src/services/agent-access.ts
import { readFile as readFile3, writeFile as writeFile3, mkdir as mkdir3 } from "node:fs/promises";
import { dirname as dirname5, isAbsolute as isAbsolute3, join as join11, resolve as resolve7, sep as sep2 } from "node:path";
import { homedir as homedir3 } from "node:os";
async function getAccess(dataDir) {
  try {
    const raw = JSON.parse(await readFile3(file(dataDir), "utf8"));
    const mode = raw?.mode === "full" || raw?.mode === "selected" ? raw.mode : "project";
    const roots = Array.isArray(raw?.roots) ? raw.roots.filter((r) => typeof r === "string") : [];
    return { mode, roots };
  } catch {
    return { ...DEFAULTS };
  }
}
async function setAccess(dataDir, next) {
  const current = await getAccess(dataDir);
  const mode = next.mode === "full" || next.mode === "selected" || next.mode === "project" ? next.mode : current.mode;
  const roots = Array.isArray(next.roots) ? next.roots.map(expand).filter(Boolean) : current.roots;
  const value = { mode, roots: roots.slice(0, 32) };
  await mkdir3(dirname5(file(dataDir)), { recursive: true });
  await writeFile3(file(dataDir), JSON.stringify(value, null, 2) + "\n", "utf8");
  return value;
}
function absolutePathsIn(command) {
  const out = [];
  const re = /(?:^|[\s"'=<>(|;&])((?:~|\/|[A-Za-z]:[\\/])[^\s"'`|;&)>]*)/g;
  let m;
  while (m = re.exec(command)) {
    const p = m[1];
    if (!p || p === "/") continue;
    if (p.startsWith("/dev/") || p.startsWith("/tmp/")) continue;
    out.push(expand(p.startsWith("~") ? p : p));
  }
  return out;
}
function checkCommand(command, access, projectDir, worktreesRoot) {
  if (access.mode === "full") return { allowed: true };
  const roots = [projectDir, worktreesRoot, ...access.roots].filter(Boolean);
  const offending = absolutePathsIn(command).filter((p) => !roots.some((root) => within(root, p)));
  if (!offending.length) return { allowed: true };
  const shown = offending.slice(0, 3).join(", ");
  return {
    allowed: false,
    offending,
    reason: access.mode === "project" ? `This command reaches outside the open project (${shown}). Turn on more access in Settings \u2192 Coding & MCP, or name the knowledge it needs inside the project.` : `This command reaches outside the folders the AI was given (${shown}). Add that folder in Settings \u2192 Coding & MCP if it should be reachable.`
  };
}
function describeAccess(a, projectDir) {
  if (a.mode === "full") return "The whole computer.";
  if (a.mode === "project") return `Only the open project${projectDir ? ` (${projectDir})` : ""}.`;
  return [`The open project`, ...a.roots].join(" \xB7 ") || "Only the open project.";
}
var DEFAULTS, file, expand, within;
var init_agent_access = __esm({
  "src/services/agent-access.ts"() {
    "use strict";
    DEFAULTS = { mode: "project", roots: [] };
    file = (dataDir) => join11(dataDir, "agent-access.json");
    expand = (p) => {
      const s = String(p ?? "").trim();
      if (!s) return "";
      if (s === "~") return homedir3();
      if (s.startsWith("~/") || s.startsWith("~\\")) return join11(homedir3(), s.slice(2));
      return isAbsolute3(s) ? s : "";
    };
    within = (root, path) => {
      const r = resolve7(root);
      const p = resolve7(path);
      return p === r || p.startsWith(r.endsWith(sep2) ? r : r + sep2);
    };
  }
});

// src/services/virustotal.ts
import { readFile as readFile4, writeFile as writeFile4 } from "node:fs/promises";
import { join as join12 } from "node:path";
async function getVtKey(dataDir) {
  const env = (process.env.VIRUSTOTAL_API_KEY ?? "").trim();
  if (env) return env;
  try {
    const raw = JSON.parse(await readFile4(keyFile(dataDir), "utf8"));
    return typeof raw?.key === "string" && raw.key.trim() ? raw.key.trim() : null;
  } catch {
    return null;
  }
}
async function setVtKey(dataDir, key) {
  await writeFile4(keyFile(dataDir), JSON.stringify({ key: key.trim() }, null, 2) + "\n", "utf8");
}
async function vtFetch(path, key, init) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), TIMEOUT5);
  try {
    const res = await fetch(`${API}${path}`, {
      ...init,
      headers: { "x-apikey": key, accept: "application/json", ...init?.headers ?? {} },
      signal: ctrl.signal
    });
    if (res.status === 404) return { notFound: true };
    if (!res.ok) return { error: `HTTP ${res.status}` };
    return await res.json();
  } catch (e) {
    return { error: String(e?.message ?? e) };
  } finally {
    clearTimeout(timer);
  }
}
async function checkUrl(url, dataDir) {
  const key = await getVtKey(dataDir);
  if (!key) {
    return { status: "unconfigured", checked: "url", sentence: "VirusTotal is not configured, so this link was not checked. Add a VirusTotal API key in Settings \u2192 Coding & MCP to check downloads automatically." };
  }
  const report = await vtFetch(`/urls/${b64url(url)}`, key);
  if (report?.error) return { status: "error", checked: "url", sentence: `VirusTotal could not be reached (${report.error}), so this link was not checked.` };
  if (report?.notFound) {
    await vtFetch("/urls", key, {
      method: "POST",
      headers: { "content-type": "application/x-www-form-urlencoded" },
      body: `url=${encodeURIComponent(url)}`
    });
    return { status: "unknown", checked: "url", sentence: "VirusTotal has never seen this link, so it was submitted for analysis \u2014 nothing is known yet. The file is checked again by hash when the download finishes." };
  }
  const stats = report?.data?.attributes?.last_analysis_stats;
  const { flagged, total, status } = summarise(stats);
  const sentence = status === "clean" ? `VirusTotal: no engine flagged this link (${total} engines).` : `VirusTotal: ${flagged} of ${total} engines flagged this link \u2014 treat the download as dangerous.`;
  return { status, flagged, total, checked: "url", link: `https://www.virustotal.com/gui/url/${b64url(url)}`, sentence };
}
async function checkHash(sha256, dataDir, opts = {}) {
  const key = await getVtKey(dataDir);
  if (!key) {
    return { status: "unconfigured", checked: "hash", sentence: "VirusTotal is not configured, so the downloaded file was not checked. The SHA-256 was computed and is shown below." };
  }
  const report = await vtFetch(`/files/${sha256}`, key);
  if (report?.error) return { status: "error", checked: "hash", sentence: `VirusTotal could not be reached (${report.error}), so the file was not checked. The SHA-256 was computed and is shown below.` };
  if (report?.notFound) {
    if (opts.uploadIfUnknown && opts.path && (opts.size ?? 0) > 0 && (opts.size ?? 0) <= 32 * 1024 * 1024) {
      try {
        const bytes = await readFile4(opts.path);
        const form = new FormData();
        form.append("file", new Blob([new Uint8Array(bytes)]), "download");
        const uploaded = await vtFetch("/files", key, { method: "POST", body: form });
        if (uploaded?.data?.id) {
          return { status: "unknown", checked: "hash", sentence: "The file is new to VirusTotal; it was uploaded for analysis. The report appears at the link below in a minute or two.", link: `https://www.virustotal.com/gui/file/${sha256}` };
        }
      } catch {
      }
    }
    return { status: "unknown", checked: "hash", sentence: "VirusTotal has never seen this file (its hash is unknown), so nothing is known about it. Uploading it for analysis is off unless you enabled it.", link: `https://www.virustotal.com/gui/file/${sha256}` };
  }
  const stats = report?.data?.attributes?.last_analysis_stats;
  const { flagged, total, status } = summarise(stats);
  const name = report?.data?.attributes?.meaningful_name;
  const sentence = status === "clean" ? `VirusTotal: no engine flagged the downloaded file${name ? ` (${name})` : ""} (${total} engines).` : `VirusTotal: ${flagged} of ${total} engines flagged the downloaded file${name ? ` (${name})` : ""} \u2014 do not run it.`;
  return { status, flagged, total, checked: "hash", sentence, link: `https://www.virustotal.com/gui/file/${sha256}` };
}
var API, TIMEOUT5, keyFile, b64url, summarise;
var init_virustotal = __esm({
  "src/services/virustotal.ts"() {
    "use strict";
    API = "https://www.virustotal.com/api/v3";
    TIMEOUT5 = 2e4;
    keyFile = (dataDir) => join12(dataDir, "virustotal.json");
    b64url = (s) => Buffer.from(s).toString("base64").replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
    summarise = (stats) => {
      const malicious = Number(stats?.malicious ?? 0);
      const suspicious = Number(stats?.suspicious ?? 0);
      const harmless = Number(stats?.harmless ?? 0);
      const undetected = Number(stats?.undetected ?? 0);
      const total = malicious + suspicious + harmless + undetected + Number(stats?.timeout ?? 0);
      return { flagged: malicious + suspicious, total, status: malicious > 0 ? "malicious" : suspicious > 0 ? "suspicious" : "clean" };
    };
  }
});

// src/routes/ide.ts
var ide_exports = {};
__export(ide_exports, {
  ideRoutes: () => ideRoutes
});
import { mkdir as mkdir4, readFile as readFile5, readdir as readdir3, rm as rm2, stat as stat3, writeFile as writeFile5, rename } from "node:fs/promises";
import { existsSync as existsSync8 } from "node:fs";
import { join as join13, resolve as resolve8, dirname as dirname6, relative as relative5 } from "node:path";
import { spawn as spawn4, spawnSync } from "node:child_process";
import { randomUUID as randomUUID2 } from "node:crypto";
import { Hono as Hono15 } from "hono";
import { createHash as createHash4 } from "node:crypto";
function scrubbedEnv() {
  const out = {};
  for (const [k, v] of Object.entries(process.env)) {
    if (/key|token|secret|passw|credential|auth/i.test(k)) continue;
    if (typeof v === "string") out[k] = v;
  }
  return out;
}
async function readDownloads(dataDir) {
  try {
    const raw = JSON.parse(await readFile5(logPath(dataDir), "utf8"));
    return Array.isArray(raw) ? raw.slice(-200) : [];
  } catch {
    return [];
  }
}
async function logDownload(dataDir, event) {
  try {
    const all = await readDownloads(dataDir);
    all.push(event);
    await writeFile5(logPath(dataDir), JSON.stringify(all.slice(-200), null, 2) + "\n", "utf8");
  } catch {
  }
}
function ideRoutes(rt) {
  const r = new Hono15();
  const projectsRoot = projectsRootOf(rt.dataDir);
  mkdir4(projectsRoot, { recursive: true }).catch(() => {
  });
  const projectDir = (name) => projectDirOf(projectsRoot, name);
  const worktreesRoot = join13(rt.dataDir, "worktrees");
  mkdir4(worktreesRoot, { recursive: true }).catch(() => {
  });
  const worktreeDir = (project, agent) => {
    const name = projectDirOf(projectsRoot, project);
    if (!name) return null;
    const dir = worktreePathFor(worktreesRoot, project, agent, (p) => projectDir(p) !== null);
    if (!dir) return null;
    return isStrictlyWithinDir(worktreesRoot, dir) ? dir : null;
  };
  const scopedDir = (project, agent) => {
    if (agent) {
      const wt = worktreeDir(project, agent);
      if (!wt || !existsSync8(wt)) return null;
      return wt;
    }
    return projectDir(project);
  };
  const agentParam = (c, key = "agent") => {
    const v = c.req.query(key) ?? null;
    return v && agentIdOk(v) ? v : null;
  };
  const existingFor = async (name) => {
    const wanted = name.toLowerCase();
    for (const e of await readdir3(projectsRoot, { withFileTypes: true }).catch(() => [])) {
      if (e.isDirectory() && e.name.toLowerCase() === wanted) return e.name;
    }
    return null;
  };
  const freeName = async (base) => {
    if (!await existingFor(base)) return base;
    for (let i = 2; i < 500; i++) {
      const candidate = `${base}-${i}`;
      if (!await existingFor(candidate)) return candidate;
    }
    return `${base}-${Date.now()}`;
  };
  const safeRel = (dir, rel) => {
    if (!rel || rel.startsWith("/") || rel.includes("\0")) return null;
    if (rel.split(/[/\\]/).some((seg) => seg === "..")) return null;
    const abs = resolve8(join13(dir, rel));
    return isStrictlyWithinDir(dir, abs) ? abs : null;
  };
  r.get("/ide/projects", async (c) => {
    await mkdir4(projectsRoot, { recursive: true });
    const out = [];
    for (const e of await readdir3(projectsRoot, { withFileTypes: true })) {
      if (!e.isDirectory() || isInternalEntry(e.name)) continue;
      const dir = join13(projectsRoot, e.name);
      let files = 0, size = 0;
      const walk2 = async (d, depth) => {
        if (depth > 6) return;
        for (const f of await readdir3(d, { withFileTypes: true })) {
          if (f.name === "node_modules" || f.name === ".git" || f.name.startsWith(".")) continue;
          const p = join13(d, f.name);
          if (f.isDirectory()) await walk2(p, depth + 1);
          else {
            files++;
            try {
              size += (await stat3(p)).size;
            } catch {
            }
          }
        }
      };
      await walk2(dir, 0).catch(() => {
      });
      let mtime = 0;
      try {
        mtime = (await stat3(dir)).mtimeMs;
      } catch {
      }
      out.push({ name: e.name, files, size, mtime, git: existsSync8(join13(dir, ".git")) });
    }
    return c.json({ projects: out.sort((a, b) => b.mtime - a.mtime) });
  });
  r.post("/ide/projects", async (c) => {
    let body;
    try {
      body = await c.req.json();
    } catch {
      return c.json({ error: "Invalid JSON body." }, 400);
    }
    const requested = normalizeProjectName(String(body.name ?? body.projectName ?? ""));
    const invented = !requested;
    const fallbackName = normalizeProjectName(String(body.fallback ?? ""));
    const base = (requested ?? fallbackName ?? { name: "untitled-project" }).name;
    const wantsUnique = !!body.unique || invented;
    const name = wantsUnique ? await freeName(base) : base;
    const dir = join13(projectsRoot, name);
    const existing = wantsUnique ? null : await existingFor(name);
    if (existing) {
      return c.json({
        error: `A project called \u201C${existing}\u201D already exists.`,
        code: "exists",
        existing
      }, 409);
    }
    await mkdir4(dir, { recursive: true });
    let written = 0;
    for (const [rel, content] of Object.entries(body.files ?? {})) {
      const abs = safeRel(dir, rel);
      if (!abs || typeof content !== "string" || content.length > 5e5) continue;
      await mkdir4(dirname6(abs), { recursive: true });
      await writeFile5(abs, content, "utf8");
      written++;
    }
    return c.json({ ok: true, name, renamed: name !== base, invented, files: written });
  });
  r.delete("/ide/projects/:name", async (c) => {
    const dir = projectDir(c.req.param("name"));
    if (!dir || !existsSync8(dir)) return c.json({ error: "Project not found." }, 404);
    await rm2(dir, { recursive: true, force: true });
    return c.json({ ok: true });
  });
  r.post("/ide/projects/rename", async (c) => {
    let body;
    try {
      body = await c.req.json();
    } catch {
      return c.json({ error: "Invalid JSON body." }, 400);
    }
    const fromDir = projectDir(body.from ?? body.project ?? "");
    if (!fromDir || !existsSync8(fromDir)) return c.json({ error: "Project not found." }, 404);
    const currentName = await existingFor(String(body.from ?? body.project ?? ""));
    const target = projectDirFor(projectsRoot, body.to ?? "");
    if (!target) {
      return c.json({ ok: true, name: currentName, unchanged: true, kept: true, code: "bad_name" });
    }
    const toName = target.name;
    const toDir = target.dir;
    if (toDir === fromDir) return c.json({ ok: true, name: toName, unchanged: true });
    const fromName = currentName;
    const sameTarget = !!fromName && fromName.toLowerCase() === toName.toLowerCase();
    const taken = await existingFor(toName);
    if (taken && !sameTarget) {
      return c.json({ error: `A project called \u201C${taken}\u201D already exists.`, code: "exists", existing: taken }, 409);
    }
    try {
      await rename(fromDir, toDir);
      return c.json({ ok: true, name: toName });
    } catch (e) {
      return c.json({ error: String(e?.message ?? e) }, 500);
    }
  });
  r.post("/ide/import", async (c) => {
    let body;
    try {
      body = await c.req.json();
    } catch {
      return c.json({ error: "Invalid JSON body." }, 400);
    }
    const wanted = projectDirFor(projectsRoot, body.name ?? "") ?? projectDirFor(projectsRoot, "imported-project");
    const name = await freeName(wanted.name);
    const dir = name === wanted.name ? wanted.dir : projectDirFor(projectsRoot, name).dir;
    const buf = Buffer.from(body.dataBase64 ?? "", "base64");
    if (!buf.length || buf.length > IMPORT_CAP) return c.json({ error: "Archive missing or larger than 24 MB." }, 413);
    const fn = (body.fileName ?? "project.zip").toLowerCase();
    const isZip = fn.endsWith(".zip");
    const isTar = fn.endsWith(".tar.gz") || fn.endsWith(".tgz") || fn.endsWith(".tar");
    if (!isZip && !isTar) return c.json({ error: "Upload a .zip, .tar.gz or .tgz archive." }, 400);
    const tmp = join13(projectsRoot, `.import-${randomUUID2()}`);
    await mkdir4(tmp, { recursive: true });
    const archive = join13(tmp, isZip ? "up.zip" : "up.tar.gz");
    try {
      await writeFile5(archive, buf);
      const res = isZip ? spawnSync("unzip", ["-q", "-o", archive, "-d", tmp], { timeout: 6e4 }) : spawnSync("tar", ["-xf", archive, "-C", tmp], { timeout: 6e4 });
      if (res.status !== 0) return c.json({ error: "Could not extract the archive (it may be corrupted or password-protected)." }, 400);
      await rm2(archive, { force: true });
      let entries = (await readdir3(tmp)).filter((n) => !n.startsWith("."));
      if (entries.length === 1 && (await stat3(join13(tmp, entries[0]))).isDirectory()) {
        const inner = join13(tmp, entries[0]);
        for (const f of await readdir3(inner)) await rename(join13(inner, f), join13(tmp, f));
        await rm2(inner, { force: true });
      }
      await rename(tmp, dir);
      return c.json({ ok: true, name, renamed: name !== wanted.name });
    } catch (e) {
      await rm2(tmp, { recursive: true, force: true }).catch(() => {
      });
      return c.json({ error: String(e?.message ?? e) }, 500);
    }
  });
  r.get("/ide/tree", async (c) => {
    const dir = scopedDir(c.req.query("project") ?? "", agentParam(c));
    if (!dir || !existsSync8(dir)) return c.json({ error: "Project not found." }, 404);
    const SKIP = /* @__PURE__ */ new Set(["node_modules", ".git", "dist", "build", ".next", "__pycache__", ".venv"]);
    const walk2 = async (d, rel, depth) => {
      if (depth > 8) return [];
      const out = [];
      for (const e of await readdir3(d, { withFileTypes: true })) {
        if (SKIP.has(e.name)) continue;
        const p = join13(d, e.name);
        const rp = rel ? `${rel}/${e.name}` : e.name;
        if (e.isDirectory()) out.push({ name: e.name, path: rp, dir: true, children: await walk2(p, rp, depth + 1) });
        else out.push({ name: e.name, path: rp, dir: false });
      }
      return out.sort((a, b) => Number(b.dir) - Number(a.dir) || a.name.localeCompare(b.name));
    };
    return c.json({ tree: await walk2(dir, "", 0) });
  });
  r.get("/ide/file", async (c) => {
    const dir = scopedDir(c.req.query("project") ?? "", agentParam(c));
    const abs = dir ? safeRel(dir, c.req.query("path") ?? "") : null;
    if (!abs) return c.json({ error: "Path must stay inside the project." }, 400);
    try {
      const st = await stat3(abs);
      if (st.size > 1e6) return c.json({ error: "File too large to edit here (1 MB limit)." }, 413);
      return c.json({ content: await readFile5(abs, "utf8") });
    } catch {
      return c.json({ error: "File not found." }, 404);
    }
  });
  r.post("/ide/file", async (c) => {
    let body;
    try {
      body = await c.req.json();
    } catch {
      return c.json({ error: "Invalid JSON body." }, 400);
    }
    const dir = scopedDir(body.project ?? "", body.agent && agentIdOk(body.agent) ? body.agent : null);
    const abs = dir ? safeRel(dir, body.path ?? "") : null;
    if (!abs) return c.json({ error: "Path must stay inside the project." }, 400);
    if (typeof body.content !== "string" || body.content.length > 1e6) return c.json({ error: "Content missing or over 1 MB." }, 413);
    await mkdir4(dirname6(abs), { recursive: true });
    let before = "";
    let created = true;
    try {
      before = await readFile5(abs, "utf8");
      created = false;
    } catch {
      before = "";
    }
    await writeFile5(abs, body.content, "utf8");
    const delta = created ? { added: body.content.split("\n").length, removed: 0 } : lineDelta(before, body.content);
    return c.json({ ok: true, created, added: delta.added, removed: delta.removed, bytes: body.content.length });
  });
  r.delete("/ide/file", async (c) => {
    const dir = scopedDir(c.req.query("project") ?? "", agentParam(c));
    const abs = dir ? safeRel(dir, c.req.query("path") ?? "") : null;
    if (!abs) return c.json({ error: "Path must stay inside the project." }, 400);
    if (!existsSync8(abs)) return c.json({ error: "File not found." }, 404);
    await rm2(abs, { recursive: true, force: true });
    return c.json({ ok: true });
  });
  r.get("/ide/search", async (c) => {
    const dir = scopedDir(c.req.query("project") ?? "", agentParam(c));
    if (!dir || !existsSync8(dir)) return c.json({ error: "Project not found." }, 404);
    const q = (c.req.query("q") ?? "").trim();
    if (q.length < 2) return c.json({ results: [], note: "Type at least 2 characters." });
    const SKIP = /* @__PURE__ */ new Set(["node_modules", ".git", "dist", "build", ".next", "__pycache__", ".venv", "coverage", ".turbo", "out"]);
    const results = [];
    const needle = q.toLowerCase();
    const walk2 = async (d, rel, depth) => {
      if (depth > 8 || results.length >= 200) return;
      let entries;
      try {
        entries = await readdir3(d, { withFileTypes: true });
      } catch {
        return;
      }
      for (const e of entries) {
        if (results.length >= 200) return;
        if (SKIP.has(e.name) || e.name.startsWith(".")) continue;
        const abs = join13(d, e.name);
        const rp = rel ? rel + "/" + e.name : e.name;
        if (e.isDirectory()) {
          await walk2(abs, rp, depth + 1);
          continue;
        }
        if (/^(.*\.(png|jpg|jpeg|gif|webp|ico|woff2?|ttf|pdf|zip|gz|mp4|mp3|so|node|dylib))$/i.test(e.name)) continue;
        if (rp.toLowerCase().includes(needle) && results.length < 40) results.push({ path: rp, line: 0, text: "file name match", kind: "file" });
        let text2 = "";
        try {
          const st = await stat3(abs);
          if (st.size > 512 * 1024) continue;
          text2 = await readFile5(abs, "utf8");
        } catch {
          continue;
        }
        if (text2.indexOf("\0") !== -1) continue;
        const lines = text2.split("\n");
        for (let i = 0; i < lines.length && results.length < 200; i++) {
          const idx = lines[i].toLowerCase().indexOf(needle);
          if (idx === -1) continue;
          results.push({ path: rp, line: i + 1, text: lines[i].trim().slice(0, 200), kind: "match" });
        }
      }
    };
    await walk2(dir, "", 0);
    return c.json({ results, truncated: results.length >= 200 });
  });
  r.post("/ide/clone", async (c) => {
    let body;
    try {
      body = await c.req.json();
    } catch {
      return c.json({ error: "Invalid JSON body." }, 400);
    }
    const parent = projectDir(body.project ?? "");
    if (!parent || !existsSync8(parent)) return c.json({ error: "Project not found." }, 404);
    const url = String(body.url ?? "").trim();
    if (!/^https?:\/\//i.test(url)) return c.json({ error: "A clone needs an http(s) Git URL." }, 400);
    if (!body.confirmed) return c.json({ requiresConfirm: true, reason: "Clone a repository into this project. The hosting link is checked with VirusTotal first; nothing from it is executed." });
    const before = await checkUrl(url, rt.dataDir);
    if (before.status === "malicious") {
      await logDownload(rt.dataDir, { kind: "command", at: Date.now(), project: body.project ?? "", url, command: `git clone ${url}`, vt: "malicious", flagged: before.flagged, total: before.total, note: "Refused: VirusTotal flagged the link.", refused: true });
      return c.json({ refused: true, reason: before.sentence, before, link: before.link });
    }
    const dirName = ((body.name ?? url.replace(/\.git$/, "").split("/").pop() ?? "repo").replace(/[^\w.\-]+/g, "_") || "repo").slice(0, 80);
    const res = spawnSync("git", ["clone", "--depth", "1", url, dirName], { cwd: parent, env: scrubbedEnv(), timeout: 12e4, maxBuffer: 4 * 1024 * 1024 });
    const out = { exit: res.status, stdout: (res.stdout ?? "").toString().slice(0, OUTPUT_CAP), stderr: (res.stderr ?? "").toString().slice(0, 8e3) };
    await logDownload(rt.dataDir, {
      kind: "command",
      at: Date.now(),
      project: body.project ?? "",
      url,
      command: `git clone --depth 1 ${url} ${dirName}`,
      vt: before.status,
      note: `${before.sentence} Clone exited ${out.exit}. Nothing from the repository was executed.`
    });
    return c.json({ ...out, dir: dirName, before, download: true, downloadNote: `Cloned into ${dirName}. Report the VirusTotal result (${before.status}) and say that nothing from the repository has been run.` });
  });
  r.post("/ide/exec", async (c) => {
    let body;
    try {
      body = await c.req.json();
    } catch {
      return c.json({ error: "Invalid JSON body." }, 400);
    }
    const dir = scopedDir(body.project ?? "", body.agent && agentIdOk(body.agent) ? body.agent : null);
    const command = (body.command ?? "").trim();
    if (!dir || !existsSync8(dir)) return c.json({ error: "Project not found." }, 404);
    if (!command || command.length > 2e3) return c.json({ error: "Empty or oversized command." }, 400);
    const denied = DENY.find((re) => re.test(command));
    if (denied) return c.json({ blocked: true, reason: "This command matches a hard safety rule and can never run from Research Engine." }, 200);
    const access = await getAccess(rt.dataDir);
    const verdict = checkCommand(command, access, dir, worktreesRoot);
    if (!verdict.allowed) {
      return c.json({
        blocked: true,
        blockedBy: "access",
        reason: verdict.reason,
        access: { mode: access.mode, roots: access.roots, reaches: describeAccess(access, dir) },
        offending: verdict.offending
      }, 200);
    }
    const guarded = NEEDS_CONFIRM.find((re) => re.test(command));
    if (guarded && !body.confirmed) return c.json({ requiresConfirm: true, reason: "This command modifies files, installs packages, or touches git history. Review and approve it." }, 200);
    const downloadish = /\b(git\s+clone|curl|wget|npm\s+(i|install|add)|pnpm\s+(i|install|add)|yarn\s+add|bun\s+(i|install|add)|pip3?\s+install|npx\s+create|npx\s+degit|brew\s+install)\b/.test(command);
    const timeout = Math.min(body.timeoutMs ?? EXEC_TIMEOUT_MS, EXEC_TIMEOUT_MS);
    const t0 = Date.now();
    const out = await new Promise((res) => {
      const child = spawn4("/bin/sh", ["-c", command], { cwd: dir, env: scrubbedEnv(), timeout });
      let stdout = "", stderr = "", timedOut = false;
      const to = setTimeout(() => {
        timedOut = true;
        child.kill("SIGKILL");
      }, timeout);
      child.stdout.on("data", (d) => {
        if (stdout.length < OUTPUT_CAP) stdout += d.toString();
      });
      child.stderr.on("data", (d) => {
        if (stderr.length < OUTPUT_CAP) stderr += d.toString();
      });
      child.on("close", (code) => {
        clearTimeout(to);
        res({ exit: code, stdout, stderr, timedOut });
      });
      child.on("error", (e) => {
        clearTimeout(to);
        res({ exit: -1, stdout, stderr: String(e), timedOut });
      });
    });
    console.log(`[re] ide exec [${body.project}${body.agent ? ` \xB7 agent ${body.agent}` : ""}] exit=${out.exit} ${command.slice(0, 100)}`);
    let downloadNote;
    if (downloadish) {
      const vtKey = await getVtKey(rt.dataDir);
      downloadNote = vtKey ? "This command downloads or installs something. Any URL in it was checked against VirusTotal before running; report the verdict to the user in your reply, and mention that files fetched by this command are checked again by hash when downloaded through the app." : "This command downloads or installs something, and VirusTotal is not configured, so nothing was checked. Say that plainly in your reply \u2014 do not imply it was verified.";
      await logDownload(rt.dataDir, {
        kind: "command",
        at: Date.now(),
        project: body.project ?? "",
        agent: body.agent ?? null,
        command: command.slice(0, 300),
        vt: vtKey ? "configured" : "unconfigured",
        note: downloadNote
      });
    }
    return c.json({
      ...out,
      ms: Date.now() - t0,
      stdout: out.stdout.slice(0, OUTPUT_CAP),
      stderr: out.stderr.slice(0, OUTPUT_CAP),
      truncated: out.stdout.length >= OUTPUT_CAP || out.stderr.length >= OUTPUT_CAP,
      ...downloadish ? { download: true, downloadNote } : {}
    });
  });
  r.post("/ide/agents/fork", async (c) => {
    let body;
    try {
      body = await c.req.json();
    } catch {
      return c.json({ error: "Invalid JSON body." }, 400);
    }
    const project = body.project ?? "";
    const agent = body.agent ?? "";
    if (!agentIdOk(agent)) return c.json({ error: "Agent id must be 3-40 chars of a-z, 0-9 or -." }, 400);
    const src = projectDir(project);
    const dest = worktreeDir(project, agent);
    if (!src || !existsSync8(src)) return c.json({ error: "Project not found." }, 404);
    if (!dest) return c.json({ error: "Could not allocate a working copy." }, 400);
    try {
      const fork = await forkTree(src, dest);
      return c.json({ ok: true, agent, worktree: dest, files: fork.files, bytes: fork.bytes, skipped: fork.skipped.length });
    } catch (e) {
      return c.json({ error: `Could not fork the project: ${String(e?.message ?? e)}` }, 500);
    }
  });
  r.get("/ide/agents/changes", async (c) => {
    const project = c.req.query("project") ?? "";
    const agent = c.req.query("agent") ?? "";
    const dest = worktreeDir(project, agent);
    if (!dest || !existsSync8(dest)) return c.json({ error: "No working copy for that agent." }, 404);
    const changes = await changesIn(dest);
    const src = projectDir(project);
    const base = await readBase(dest);
    const files = [];
    for (const change of changes.slice(0, 200)) {
      let added = 0, removed = 0, before = "";
      try {
        before = src && base[change.path] ? await readFile5(join13(src, change.path), "utf8") : "";
      } catch {
        before = "";
      }
      try {
        const after = await readFile5(join13(dest, change.path), "utf8");
        if (change.kind === "deleted") {
          removed = before.split("\n").length;
        } else {
          const d = lineDelta(before, after);
          added = d.added;
          removed = d.removed;
        }
      } catch {
      }
      files.push({ ...change, added, removed, base: before.slice(0, 4e5) });
    }
    return c.json({ changes: files, summary: describeChanges(changes), skipped: changes.length - files.length });
  });
  r.post("/ide/agents/merge", async (c) => {
    let body;
    try {
      body = await c.req.json();
    } catch {
      return c.json({ error: "Invalid JSON body." }, 400);
    }
    const dest = worktreeDir(body.project ?? "", body.agent ?? "");
    const src = projectDir(body.project ?? "");
    if (!dest || !existsSync8(dest)) return c.json({ error: "No working copy for that agent." }, 404);
    if (!src || !existsSync8(src)) return c.json({ error: "Project not found." }, 404);
    const only = Array.isArray(body.files) ? body.files.filter((f) => typeof f === "string" && !f.includes("..")) : void 0;
    const result = await mergeTree({ worktreeDir: dest, projectDir: src, only });
    console.log(`[re] agent merge [${body.project} \xB7 ${body.agent}] ${result.merged.length} merged, ${result.conflicts.length} conflicted`);
    return c.json({
      ok: true,
      merged: result.merged,
      conflicts: result.conflicts,
      unchanged: result.unchanged.length,
      missing: result.missing,
      summary: `${result.merged.length} file${result.merged.length === 1 ? "" : "s"} merged${result.conflicts.length ? `, ${result.conflicts.length} conflict(s) kept aside` : ""}`
    });
  });
  r.post("/ide/agents/discard", async (c) => {
    let body;
    try {
      body = await c.req.json();
    } catch {
      return c.json({ error: "Invalid JSON body." }, 400);
    }
    const dest = worktreeDir(body.project ?? "", body.agent ?? "");
    if (!dest) return c.json({ error: "Unknown agent." }, 400);
    await rm2(dest, { recursive: true, force: true });
    return c.json({ ok: true });
  });
  r.get("/ide/git", async (c) => {
    const dir = projectDir(c.req.query("project") ?? "");
    if (!dir || !existsSync8(dir)) return c.json({ error: "Project not found." }, 404);
    const ALLOWED = {
      status: ["status", "--porcelain=v1", "-b"],
      log: ["log", "--oneline", "-30"],
      diff: ["diff", "--stat"],
      branches: ["branch", "-a"],
      remote: ["remote", "-v"]
    };
    const op = c.req.query("op") ?? "status";
    const args2 = ALLOWED[op];
    if (!args2) return c.json({ error: "Unknown git op." }, 400);
    if (!existsSync8(join13(dir, ".git"))) return c.json({ norepo: true });
    const res = spawnSync("git", args2, { cwd: dir, env: scrubbedEnv(), timeout: 15e3, maxBuffer: 2 * 1024 * 1024 });
    return c.json({ exit: res.status, stdout: (res.stdout ?? "").toString().slice(0, OUTPUT_CAP), stderr: (res.stderr ?? "").toString().slice(0, 4e3) });
  });
  r.post("/ide/git", async (c) => {
    let body;
    try {
      body = await c.req.json();
    } catch {
      return c.json({ error: "Invalid JSON body." }, 400);
    }
    const dir = projectDir(body.project ?? "");
    if (!dir || !existsSync8(dir)) return c.json({ error: "Project not found." }, 404);
    const run2 = (args2) => {
      const res = spawnSync("git", args2, { cwd: dir, env: scrubbedEnv(), timeout: 15e3, maxBuffer: 2 * 1024 * 1024 });
      return { exit: res.status, stdout: (res.stdout ?? "").toString().slice(0, OUTPUT_CAP), stderr: (res.stderr ?? "").toString().slice(0, 4e3) };
    };
    if (body.op === "init") return c.json(run2(["init"]));
    if (!existsSync8(join13(dir, ".git"))) return c.json({ error: "Not a git repository." }, 400);
    if (body.op === "add") return c.json(run2(["add", "-A"]));
    if (body.op === "commit") {
      const msg = (body.message ?? "").trim().slice(0, 500);
      if (!msg) return c.json({ error: "Commit message required." }, 400);
      if (!body.confirmed) return c.json({ requiresConfirm: true, reason: "Commit staged changes to local git history." });
      run2(["add", "-A"]);
      const res = spawnSync("git", [
        "-c",
        "user.name=Research Engine",
        "-c",
        "user.email=research-engine@local",
        "commit",
        "-m",
        msg
      ], { cwd: dir, env: scrubbedEnv(), timeout: 15e3, maxBuffer: 2 * 1024 * 1024 });
      return c.json({ exit: res.status, stdout: (res.stdout ?? "").toString().slice(0, OUTPUT_CAP), stderr: (res.stderr ?? "").toString().slice(0, 4e3) });
    }
    return c.json({ error: "Unknown git op." }, 400);
  });
  r.get("/agent/access", async (c) => {
    const access = await getAccess(rt.dataDir);
    return c.json({ ...access, reaches: describeAccess(access, null) });
  });
  r.post("/agent/access", async (c) => {
    let body;
    try {
      body = await c.req.json();
    } catch {
      return c.json({ error: "Invalid JSON body." }, 400);
    }
    const next = await setAccess(rt.dataDir, { mode: body.mode, roots: body.roots });
    return c.json({ ...next, reaches: describeAccess(next, null) });
  });
  r.get("/agent/virustotal", async (c) => {
    const key = await getVtKey(rt.dataDir);
    return c.json({ configured: Boolean(key), source: process.env.VIRUSTOTAL_API_KEY ? "environment" : key ? "saved" : "none" });
  });
  r.post("/agent/virustotal", async (c) => {
    let body;
    try {
      body = await c.req.json();
    } catch {
      return c.json({ error: "Invalid JSON body." }, 400);
    }
    const key = String(body.key ?? "").trim();
    if (!key) return c.json({ error: "A VirusTotal key is 64 hex characters. Paste one, or clear it by sending an empty string with `clear: true`." }, 400);
    if (!/^[0-9a-f]{64}$/i.test(key)) return c.json({ error: "That does not look like a VirusTotal API key \u2014 they are 64 hexadecimal characters." }, 400);
    await setVtKey(rt.dataDir, key);
    return c.json({ ok: true, configured: true });
  });
  r.delete("/agent/virustotal", async (c) => {
    await setVtKey(rt.dataDir, "");
    return c.json({ ok: true, configured: false });
  });
  r.get("/ide/downloads", async (c) => c.json({ events: await readDownloads(rt.dataDir) }));
  r.post("/ide/download", async (c) => {
    let body;
    try {
      body = await c.req.json();
    } catch {
      return c.json({ error: "Invalid JSON body." }, 400);
    }
    const dir = scopedDir(body.project ?? "", null);
    if (!dir || !existsSync8(dir)) return c.json({ error: "Project not found." }, 404);
    const url = String(body.url ?? "").trim();
    if (!/^https?:\/\//i.test(url)) return c.json({ error: "A download needs an http(s) URL." }, 400);
    const before = await checkUrl(url, rt.dataDir);
    if (before.status === "malicious") {
      await logDownload(rt.dataDir, { kind: "download", at: Date.now(), project: body.project ?? "", url, vt: "malicious", flagged: before.flagged, total: before.total, note: "Refused: VirusTotal flagged the link.", refused: true });
      return c.json({ refused: true, reason: before.sentence, before, link: before.link });
    }
    const safeName = (body.filename ?? url.split("/").pop() ?? "download").replace(/[^\w.\-]+/g, "_").slice(0, 120) || "download";
    const dest = join13(dir, "downloads", safeName);
    await mkdir4(dirname6(dest), { recursive: true }).catch(() => {
    });
    let bytes = 0;
    let sha256 = "";
    try {
      const res = await fetch(url, { redirect: "follow" });
      if (!res.ok) return c.json({ error: `The server answered HTTP ${res.status} for that URL.`, before });
      const buf = Buffer.from(await res.arrayBuffer());
      bytes = buf.length;
      if (bytes > 64 * 1024 * 1024) return c.json({ error: "That file is over 64 MB \u2014 download it outside the app rather than through the agent." });
      sha256 = createHash4("sha256").update(buf).digest("hex");
      await writeFile5(dest, buf);
    } catch (e) {
      return c.json({ error: `The download failed: ${String(e?.message ?? e)}`, before });
    }
    const after = await checkHash(sha256, rt.dataDir, { size: bytes, path: dest, uploadIfUnknown: body.uploadIfUnknown === true });
    await logDownload(rt.dataDir, {
      kind: "download",
      at: Date.now(),
      project: body.project ?? "",
      url,
      path: relative5(dir, dest),
      bytes,
      sha256,
      vt: after.status,
      flagged: after.flagged,
      total: after.total,
      note: after.sentence
    });
    return c.json({ ok: true, path: relative5(dir, dest), bytes, sha256, before, after });
  });
  return r;
}
var EXEC_TIMEOUT_MS, OUTPUT_CAP, IMPORT_CAP, DENY, NEEDS_CONFIRM, logPath;
var init_ide = __esm({
  "src/routes/ide.ts"() {
    "use strict";
    init_paths();
    init_worktree();
    init_agent_access();
    init_virustotal();
    EXEC_TIMEOUT_MS = 6e4;
    OUTPUT_CAP = 2e5;
    IMPORT_CAP = 24 * 1024 * 1024;
    DENY = [
      /\brm\s+(-[a-z]*\s+)*(-[a-z]*\s+)*\/(\s|$)/,
      // rm -rf /
      /\brm\s+-[a-z]*r[a-z]*\s+~\/?\s*($|;|&|\|)/,
      // rm -rf ~
      /\bsudo\b/,
      /\bsu\s+-/,
      /doas\b/,
      /\bmkfs\b/,
      /\bdd\s+if=/,
      /\bfdisk\b/,
      /\bparted\b/,
      /:\(\)\s*\{\s*:\|:&\s*\}\s*;\s*:/,
      // fork bomb
      /\bshutdown\b/,
      /\breboot\b/,
      /\bhalt\b/,
      /\bpoweroff\b/,
      /\binit\s+0/,
      /\bchmod\s+(-R\s+)?777\s+\//,
      /\bchown\s+-R\s+[^\s]+\s+\//,
      /\/dev\/(sd[a-z]|nvme|disk)/,
      /\b(curl|wget)\b[^\n|]*\|\s*(sudo\s+)?(ba)?sh/,
      // pipe-to-shell
      /\beval\s+.*\b(curl|wget)\b/,
      /\bbase64\s+(-d|--decode)[^\n]*\|\s*(ba)?sh/,
      /\bcrontab\b/,
      /\bat\s+-f/,
      /\bsystemctl\b/,
      /\blaunchctl\b/,
      /\bkill\s+(-9\s+)?1\b/,
      /\bkillall\b/,
      /\bnpm\s+publish\b/,
      /\bcargo\s+publish\b/,
      /\btwine\s+upload\b/,
      /\bgit\s+push\s+(--force\b|.*--force\b|-f\b)/,
      /\biptables\b/,
      /\bufw\b/,
      /\bifconfig\b.*\bdown\b/,
      /\broute\s+(del|add)/,
      /\buseradd\b/,
      /\buserdel\b/,
      /\bpasswd\b/,
      /\bvisudo\b/,
      /\bformat\s+[a-z]:/i,
      /\bdel\s+\/[sfq]+\s+[a-z]:\\/i,
      /\brmdir\s+\/s/i,
      /\breg\s+(delete|add)\b/i,
      /\bnet\s+user\b/i,
      />~?\/(etc|usr|bin|boot|proc|sys)\//,
      /\bssh\b.*-[iLDR]\b/,
      /\bscp\b/,
      /\brsync\b/,
      /\bnc\b.*-[elp]/,
      /\bnetcat\b/,
      /\btelnetd\b/,
      /\bminer\b/i,
      /xmrig/i
    ];
    NEEDS_CONFIRM = [
      /\brm\b/,
      /\bmv\b/,
      /\bgit\s+(push|reset|clean|checkout\s+--|restore)\b/,
      /\b(npm|yarn|pnpm|bun)\s+(install|add|remove|update|run\s+build)\b/,
      /\bpip3?\s+install\b/,
      /\bdocker\b/,
      /\bkubectl\b/,
      /\bgit\s+commit\b/,
      /\bmkdir\b/,
      /\btouch\b/,
      /\bchmod\b/,
      /\bnpx\b/,
      /\bmake\b/
    ];
    logPath = (dataDir) => join13(dataDir, "agent-downloads.json");
  }
});

// src/preview/bridge.ts
var BRIDGE_JS;
var init_bridge = __esm({
  "src/preview/bridge.ts"() {
    "use strict";
    BRIDGE_JS = String.raw`
(function () {
  if (window.__RE_DESIGN_BRIDGE__) return;
  window.__RE_DESIGN_BRIDGE__ = true;

  var HOST_SOURCE = 're-design-host';
  var BRIDGE_SOURCE = 're-design-bridge';
  var uidSeq = 0;
  var uidMap = new WeakMap();
  var consoleLog = [];
  var networkLog = [];
  var navCount = 0;
  var pickMode = false;
  var overlay = null;
  var lastError = null;
  // Shared secret handed over in the iframe URL hash, so only the IDE that
  // embedded this frame can drive it (and fake results are ignored).
  var TOKEN = (function () {
    try { var m = /re-token=([A-Za-z0-9_-]{4,40})/.exec(location.hash || ''); return m ? m[1] : ''; } catch (e) { return ''; }
  })();

  /* ---------------- console + error capture ---------------- */
  function record(level, args) {
    try {
      var parts = [];
      for (var i = 0; i < args.length; i++) {
        var a = args[i];
        if (a instanceof Error) parts.push(a.stack || a.message || String(a));
        else if (typeof a === 'object') { try { parts.push(JSON.stringify(a)); } catch (e) { parts.push(String(a)); } }
        else parts.push(String(a));
      }
      var text = parts.join(' ').slice(0, 900);
      if (level === 'error' || level === 'warn' || consoleLog.length < 400) {
        consoleLog.push({ level: level, text: text, at: Date.now(), count: 1 });
        if (consoleLog.length > 500) consoleLog.shift();
      }
    } catch (e) { /* never break the app */ }
  }
  var origError = console.error, origWarn = console.warn, origLog = console.log, origInfo = console.info;
  console.error = function () { record('error', arguments); origError.apply(console, arguments); };
  console.warn = function () { record('warn', arguments); origWarn.apply(console, arguments); };
  console.log = function () { record('log', arguments); origLog.apply(console, arguments); };
  console.info = function () { record('info', arguments); origInfo.apply(console, arguments); };
  window.addEventListener('error', function (e) {
    lastError = (e && e.message ? e.message : 'error') + (e && e.filename ? ' @ ' + String(e.filename).split('/').pop() + ':' + e.lineno : '');
    record('error', [lastError]);
  });
  window.addEventListener('unhandledrejection', function (e) {
    var r = e && e.reason;
    lastError = 'Unhandled promise rejection: ' + (r && r.message ? r.message : String(r));
    record('error', [lastError]);
  });
  try {
    var origFetch = window.fetch;
    if (origFetch) {
      window.fetch = function () {
        var url = String((arguments[0] && arguments[0].url) || arguments[0] || '');
        var t0 = Date.now();
        return origFetch.apply(this, arguments).then(function (res) {
          if (!res.ok) {
            networkLog.push({ url: url.slice(0, 300), status: res.status, ms: Date.now() - t0 });
            if (networkLog.length > 100) networkLog.shift();
          }
          return res;
        }, function (err) {
          networkLog.push({ url: url.slice(0, 300), status: 0, error: String(err && err.message || err), ms: Date.now() - t0 });
          return Promise.reject(err);
        });
      };
    }
  } catch (e) { /* ignore */ }

  /* ---------------- element identity + selectors ---------------- */
  function uid(el) {
    if (!el || el.nodeType !== 1) return null;
    var u = uidMap.get(el);
    if (!u) { u = 'e' + (++uidSeq); uidMap.set(el, u); try { el.setAttribute('data-re-uid', u); } catch (e) {} }
    return u;
  }
  function cssPath(el) {
    if (!el || el.nodeType !== 1) return '';
    if (el.id) return '#' + el.id;
    var parts = [];
    var node = el;
    while (node && node.nodeType === 1 && parts.length < 6) {
      var sel = node.tagName.toLowerCase();
      if (node.id) { parts.unshift('#' + node.id); break; }
      var cls = (node.getAttribute('class') || '').trim().split(/\s+/).filter(function (c) { return c && c.length < 30; }).slice(0, 2);
      if (cls.length) sel += '.' + cls.join('.');
      var parent = node.parentElement;
      if (parent) {
        var same = 0, idx = 1, kids = parent.children;
        for (var i = 0; i < kids.length; i++) {
          if (kids[i].tagName === node.tagName) { same++; if (kids[i] === node) idx = same; }
        }
        if (same > 1) sel += ':nth-of-type(' + idx + ')';
      }
      parts.unshift(sel);
      if (node.parentElement && node.parentElement.id) { parts.unshift('#' + node.parentElement.id); break; }
      node = node.parentElement;
    }
    return parts.join(' > ');
  }
  function resolve(target) {
    if (!target) return null;
    var s = String(target);
    if (/^e\d+$/.test(s)) {
      var found = document.querySelector('[data-re-uid="' + s + '"]');
      if (found) return found;
    }
    try { return document.querySelector(s); } catch (e) { return null; }
  }
  function isVisible(el) {
    if (!el || !el.getBoundingClientRect) return false;
    var r = el.getBoundingClientRect();
    if (r.width <= 0 || r.height <= 0) return false;
    var cs = getComputedStyle(el);
    if (cs.display === 'none' || cs.visibility === 'hidden' || Number(cs.opacity) === 0) return false;
    return true;
  }
  /** Visible text of an element. jsdom (and any engine without layout) leaves
   *  innerText empty, so textContent is the reliable fallback. */
  function textOf(el) {
    if (!el) return '';
    var t = el.innerText;
    if (!t) t = el.textContent || '';
    return String(t).replace(/\s+/g, ' ').trim();
  }
  function rectOf(el) {
    var r = el.getBoundingClientRect();
    return { x: Math.round(r.x), y: Math.round(r.y), w: Math.round(r.width), h: Math.round(r.height) };
  }
  function accessibleName(el) {
    var t = el.getAttribute && (el.getAttribute('aria-label') || '');
    if (t) return t.trim();
    if (el.tagName === 'INPUT' || el.tagName === 'SELECT' || el.tagName === 'TEXTAREA') {
      if (el.id) {
        var lab = document.querySelector('label[for="' + el.id.replace(/"/g, '') + '"]');
        if (lab && lab.textContent) return lab.textContent.trim().slice(0, 80);
      }
      var wrapLab = el.closest && el.closest('label');
      if (wrapLab && wrapLab.textContent) return wrapLab.textContent.trim().slice(0, 80);
      return el.getAttribute('placeholder') || el.getAttribute('name') || el.getAttribute('title') || '';
    }
    if (el.tagName === 'IMG') return el.getAttribute('alt') || '(no alt)';
    var txt = (el.innerText || el.textContent || '').replace(/\s+/g, ' ').trim();
    return txt.slice(0, 80);
  }
  function roleOf(el) {
    if (el.getAttribute && el.getAttribute('role')) return el.getAttribute('role');
    var t = el.tagName;
    if (t === 'A') return el.getAttribute('href') ? 'link' : 'generic';
    if (t === 'BUTTON') return 'button';
    if (t === 'INPUT') return el.type === 'submit' ? 'button' : (el.type || 'textbox');
    if (t === 'SELECT') return 'combobox';
    if (t === 'TEXTAREA') return 'textbox';
    if (/^H[1-6]$/.test(t)) return 'heading';
    if (t === 'IMG') return 'img';
    if (t === 'NAV') return 'navigation';
    if (t === 'MAIN') return 'main';
    if (t === 'HEADER') return 'banner';
    if (t === 'FOOTER') return 'contentinfo';
    if (t === 'FORM') return 'form';
    return 'generic';
  }
  function styleOf(el, props) {
    var cs = getComputedStyle(el);
    var out = {};
    for (var i = 0; i < props.length; i++) out[props[i]] = cs.getPropertyValue(props[i]);
    return out;
  }
  var STYLE_KEYS = ['display', 'position', 'width', 'height', 'font-size', 'font-weight', 'font-family',
    'line-height', 'color', 'background-color', 'border-radius', 'padding', 'margin', 'gap', 'flex-direction',
    'align-items', 'justify-content', 'overflow', 'z-index', 'text-align', 'box-shadow', 'border-width', 'border-color'];

  function parseColor(c) {
    var m = String(c).match(/rgba?\(([^)]+)\)/);
    if (!m) return null;
    var p = m[1].split(',').map(function (v) { return parseFloat(v); });
    return { r: p[0], g: p[1], b: p[2], a: p.length > 3 ? p[3] : 1 };
  }
  function lum(c) {
    if (!c) return null;
    var f = function (v) { v = v / 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); };
    return 0.2126 * f(c.r) + 0.7152 * f(c.g) + 0.0722 * f(c.b);
  }
  function effectiveBg(el) {
    var node = el;
    while (node && node.nodeType === 1) {
      var cs = getComputedStyle(node);
      var bg = parseColor(cs.backgroundColor);
      if (bg && bg.a > 0.35) return bg;
      node = node.parentElement;
    }
    return { r: 255, g: 255, b: 255, a: 1 };
  }
  function contrastOf(el) {
    var fg = parseColor(getComputedStyle(el).color);
    if (!fg) return null;
    if (!textOf(el)) return null;
    var bg = effectiveBg(el);
    var l1 = lum(fg), l2 = lum(bg);
    if (l1 == null || l2 == null) return null;
    var ratio = (Math.max(l1, l2) + 0.05) / (Math.min(l1, l2) + 0.05);
    return { ratio: Math.round(ratio * 100) / 100, fg: getComputedStyle(el).color, bg: 'rgb(' + bg.r + ',' + bg.g + ',' + bg.b + ')', passAA: ratio >= 4.5, passLargeAA: ratio >= 3 };
  }

  /* ---------------- page snapshot ---------------- */
  var KEY_SELECTOR = 'h1,h2,h3,h4,a[href],button,input,select,textarea,[role],[aria-label],img,form,main,header,footer,nav,aside,section,table,[data-testid],video,canvas,svg[width]';
  function snapshot(opts) {
    opts = opts || {};
    var maxNodes = opts.maxNodes || 140;
    var nodes = [];
    var all = document.querySelectorAll(KEY_SELECTOR);
    var vp = { w: window.innerWidth, h: window.innerHeight };
    for (var i = 0; i < all.length && nodes.length < maxNodes; i++) {
      var el = all[i];
      if (!isVisible(el)) continue;
      var r = rectOf(el);
      if (r.y > vp.h * 4) continue; // far below the fold — noise for a first pass
      var cs = getComputedStyle(el);
      var txt = textOf(el);
      nodes.push({
        uid: uid(el),
        sel: cssPath(el),
        tag: el.tagName.toLowerCase(),
        role: roleOf(el),
        name: accessibleName(el).slice(0, 90),
        text: roleOf(el) === 'generic' ? undefined : txt.slice(0, 110) || undefined,
        rect: r,
        aboveFold: r.y + r.h > 0 && r.y < vp.h,
        style: {
          fs: cs.fontSize, fw: cs.fontWeight, color: cs.color, bg: cs.backgroundColor,
          pad: cs.padding, gap: cs.gap, radius: cs.borderRadius, display: cs.display
        },
        flags: flagsFor(el, cs, r, vp)
      });
    }
    var headings = [];
    var hs = document.querySelectorAll('h1,h2,h3,h4,h5,h6');
    for (var h = 0; h < hs.length && h < 30; h++) {
      if (isVisible(hs[h])) headings.push({ tag: hs[h].tagName.toLowerCase(), text: textOf(hs[h]).slice(0, 90) });
    }
    return {
      url: location.href,
      title: document.title,
      viewport: vp,
      scroll: { x: Math.round(window.scrollX), y: Math.round(window.scrollY), height: document.documentElement.scrollHeight },
      headings: headings,
      counts: {
        interactive: document.querySelectorAll('button,a[href],input,select,textarea,[role="button"]').length,
        nodes: document.getElementsByTagName('*').length,
        images: document.images.length
      },
      elements: nodes,
      findings: audit(),
      console: consoleTail(12),
      network: networkLog.slice(-8)
    };
  }

  function flagsFor(el, cs, r, vp) {
    var flags = [];
    if (el.scrollWidth > el.clientWidth + 2 && (cs.overflow === 'hidden' || cs.textOverflow === 'ellipsis')) flags.push('text-clipped');
    if (r.w > vp.w + 1) flags.push('overflows-viewport');
    if (r.x < -1) flags.push('off-screen-left');
    if (parseFloat(cs.fontSize) < 12) flags.push('tiny-text(' + cs.fontSize + ')');
    if ((el.tagName === 'BUTTON' || el.tagName === 'A') && (r.h < 32 || r.w < 24)) flags.push('small-target(' + r.w + 'x' + r.h + ')');
    var c = contrastOf(el);
    if (c && !c.passLargeAA && textOf(el)) flags.push('low-contrast(' + c.ratio + ':1)');
    if (/^\s*0px$/.test(cs.borderRadius) === false && r.w > 0 && r.h > 0 && textOf(el) && cs.backgroundColor === 'rgba(0, 0, 0, 0)' && (el.tagName === 'DIV' || el.tagName === 'SECTION')) flags.push('transparent-text-container');
    if (el.tagName === 'IMG' && !el.getAttribute('alt')) flags.push('img-no-alt');
    if (el.tagName === 'INPUT' && !accessibleName(el)) flags.push('input-no-label');
    if (el.tagName === 'A' && el.getAttribute('href') === '#') flags.push('dead-link-href-#');
    return flags;
  }

  /** Cheap static audit across the whole document (not just the fold). */
  function audit() {
    var out = [];
    var push = function (kind, msg, sel) { if (out.length < 40) out.push({ kind: kind, msg: msg, sel: sel }); };
    var dk = document.documentElement;
    if (dk.scrollWidth > window.innerWidth + 2) push('layout', 'Document is horizontally scrollable (' + dk.scrollWidth + 'px content in ' + window.innerWidth + 'px viewport)', 'html');
    var hs = document.querySelectorAll('h1,h2,h3,h4,h5,h6');
    var prev = 0;
    for (var i = 0; i < hs.length; i++) {
      var lvl = Number(hs[i].tagName[1]);
      if (prev && lvl > prev + 1) push('a11y', 'Heading level jumps from h' + prev + ' to h' + lvl + ': "' + textOf(hs[i]).slice(0, 50) + '"', cssPath(hs[i]));
      prev = lvl;
    }
    if (!document.querySelector('h1')) push('a11y', 'Page has no h1 heading', 'body');
    if (!document.querySelector('main,[role="main"]')) push('a11y', 'No <main> landmark', 'body');
    var imgs = document.images;
    for (var j = 0; j < imgs.length && j < 60; j++) {
      if (!imgs[j].getAttribute('alt')) push('a11y', 'Image without alt text', cssPath(imgs[j]));
      if (imgs[j].naturalWidth === 0 && imgs[j].complete) push('assets', 'Broken image: ' + (imgs[j].currentSrc || imgs[j].src || '').slice(-60), cssPath(imgs[j]));
    }
    var ctrls = document.querySelectorAll('button,a[href],input,select,textarea,[role="button"]');
    var noName = 0;
    for (var k = 0; k < ctrls.length; k++) {
      if (!accessibleName(ctrls[k]) && isVisible(ctrls[k])) { noName++; if (noName <= 5) push('a11y', 'Interactive element has no accessible name (' + ctrls[k].tagName.toLowerCase() + ')', cssPath(ctrls[k])); }
    }
    var small = 0;
    for (var m = 0; m < ctrls.length; m++) {
      if (!isVisible(ctrls[m])) continue;
      var rr = ctrls[m].getBoundingClientRect();
      if (rr.height < 32 || rr.width < 24) small++;
    }
    if (small) push('touch', small + ' interactive element(s) smaller than 32px tall — hard to tap on mobile');
    for (var n = 0; n < ctrls.length && n < 200; n++) {
      if (ctrls[n].tagName === 'A' && ctrls[n].getAttribute('href') === '#') push('ux', 'Anchor with href="#" does nothing', cssPath(ctrls[n]));
      if (ctrls[n].tagName === 'IMG' && !ctrls[n].hasAttribute('width') && !ctrls[n].style.width) push('layout', 'Image without intrinsic size — can cause layout shift', cssPath(ctrls[n]));
    }
    var empties = document.querySelectorAll('div,section,article');
    var emptyCount = 0;
    for (var p = 0; p < empties.length && p < 400; p++) {
      var e = empties[p];
      if (e.children.length === 0 && !(e.textContent || '').trim() && isVisible(e)) {
        var er = e.getBoundingClientRect();
        if (er.width > 40 && er.height > 40) { emptyCount++; if (emptyCount <= 3) push('layout', 'Large empty block ' + Math.round(er.width) + 'x' + Math.round(er.height) + 'px (may be an unloaded/broken section)', cssPath(e)); }
      }
    }
    if (lastError) push('console', 'Runtime error captured: ' + lastError, '');
    var errors = consoleLog.filter(function (l) { return l.level === 'error'; });
    if (errors.length) push('console', errors.length + ' console error(s); first: ' + errors[0].text.slice(0, 160), '');
    for (var q = 0; q < networkLog.length && q < 5; q++) push('network', 'Request failed: ' + networkLog[q].status + ' ' + networkLog[q].url.slice(0, 90), '');
    return out;
  }

  /* ---------------- inspect ---------------- */
  function describe(el) {
    var cs = getComputedStyle(el);
    var r = el.getBoundingClientRect();
    var parents = [];
    var p = el.parentElement;
    while (p && parents.length < 4) { parents.push({ sel: cssPath(p), rect: rectOf(p), display: getComputedStyle(p).display }); p = p.parentElement; }
    var siblings = [];
    if (el.parentElement) {
      var kids = el.parentElement.children;
      for (var i = 0; i < kids.length && siblings.length < 8; i++) {
        if (kids[i] !== el) siblings.push({ sel: cssPath(kids[i]), rect: rectOf(kids[i]), tag: kids[i].tagName.toLowerCase() });
      }
    }
    return {
      uid: uid(el),
      sel: cssPath(el),
      tag: el.tagName.toLowerCase(),
      role: roleOf(el),
      name: accessibleName(el),
      text: textOf(el).slice(0, 400),
      rect: rectOf(el),
      box: {
        margin: cs.margin, padding: cs.padding, border: cs.borderWidth,
        contentBox: { w: el.clientWidth, h: el.clientHeight }, scroll: { w: el.scrollWidth, h: el.scrollHeight }
      },
      styles: styleOf(el, STYLE_KEYS),
      contrast: contrastOf(el),
      flags: flagsFor(el, cs, { x: r.x, y: r.y, w: r.width, h: r.height }, { w: window.innerWidth, h: window.innerHeight }),
      parents: parents,
      siblings: siblings,
      attributes: (function () {
        var a = {};
        for (var i = 0; i < el.attributes.length && i < 25; i++) {
          var at = el.attributes[i];
          if (at.name === 'style' && at.value.length > 400) a.style = at.value.slice(0, 400) + '…';
          else a[at.name] = String(at.value).slice(0, 200);
        }
        return a;
      })(),
      path: (function () {
        var chain = [], node = el;
        while (node && node.tagName && chain.length < 8) {
          chain.unshift(node.tagName.toLowerCase() + (node.id ? '#' + node.id : '') + (node.className && typeof node.className === 'string' ? '.' + node.className.trim().split(/\s+/).slice(0, 2).join('.') : ''));
          node = node.parentElement;
        }
        return chain.join(' > ');
      })()
    };
  }

  /* ---------------- interactions ---------------- */
  function fire(el, type, init) {
    try { el.dispatchEvent(new MouseEvent(type, Object.assign({ bubbles: true, cancelable: true, view: window }, init || {}))); } catch (e) {}
  }
  function clickTarget(el) {
    if (!el) return { ok: false, error: 'element not found' };
    try { if (el.scrollIntoView) el.scrollIntoView({ block: 'center', inline: 'center' }); } catch (e) {}
    var r = rectOf(el);
    var before = { url: location.href, nodes: document.getElementsByTagName('*').length };
    highlight(el, true);
    fire(el, 'mouseover'); fire(el, 'mousedown'); fire(el, 'mouseup'); fire(el, 'click');
    try { if (typeof el.click === 'function') el.click(); } catch (e) {}
    return { ok: true, before: before, rect: r, tag: el.tagName.toLowerCase(), name: accessibleName(el).slice(0, 80) };
  }
  function typeInto(el, text, submit) {
    if (!el) return { ok: false, error: 'element not found' };
    try { if (el.scrollIntoView) el.scrollIntoView({ block: 'center' }); el.focus(); } catch (e) {}
    var proto = el.tagName === 'TEXTAREA' ? window.HTMLTextAreaElement.prototype : window.HTMLInputElement.prototype;
    var setter = Object.getOwnPropertyDescriptor(proto || {}, 'value');
    if (setter && setter.set) setter.set.call(el, text); else el.value = text;
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    if (submit) {
      var form = el.form;
      fire(el, 'keydown', { key: 'Enter', keyCode: 13 });
      fire(el, 'keypress', { key: 'Enter', keyCode: 13 });
      fire(el, 'keyup', { key: 'Enter', keyCode: 13 });
      if (form && el.type !== 'textarea') { try { form.requestSubmit ? form.requestSubmit() : form.submit(); } catch (e) {} }
    }
    return { ok: true, value: el.value, tag: el.tagName.toLowerCase(), name: accessibleName(el).slice(0, 80) };
  }

  function checkOne(c) {
    var el = resolve(c.target || c.selector);
    var res = { check: c.kind, target: c.target || c.selector, pass: false };
    // Whole-page checks come first — they need no element and must not be
    // short-circuited by the "element not found" guard below.
    if (c.kind === 'count') {
      var list = []; try { list = document.querySelectorAll(c.selector || c.target); } catch (e) {}
      res.pass = list.length === Number(c.expect);
      res.detail = list.length + ' element(s) matched (expected ' + c.expect + ')';
      return res;
    }
    if (c.kind === 'noConsoleErrors') {
      var errs = consoleLog.filter(function (l) { return l.level === 'error'; });
      res.pass = errs.length === 0;
      res.detail = errs.length ? errs.length + ' console error(s): ' + errs[0].text.slice(0, 120) : 'no console errors';
      return res;
    }
    if (c.kind === 'noHorizontalScroll') {
      res.pass = document.documentElement.scrollWidth <= window.innerWidth + 2;
      res.detail = document.documentElement.scrollWidth + 'px content vs ' + window.innerWidth + 'px viewport';
      return res;
    }
    if (c.kind === 'exists') { res.pass = !!el; res.detail = el ? 'found ' + cssPath(el) : 'not found'; return res; }
    if (!el) { res.detail = 'element not found: ' + (c.target || c.selector); return res; }
    if (c.kind === 'visible') { res.pass = isVisible(el); res.detail = res.pass ? 'visible' : 'hidden or zero-size'; return res; }
    if (c.kind === 'text') {
      var have = (el.innerText || el.textContent || '').replace(/\s+/g, ' ').trim();
      var want = String(c.expect || '');
      res.pass = c.mode === 'equals' ? have === want : have.toLowerCase().indexOf(want.toLowerCase()) !== -1;
      res.detail = JSON.stringify(have.slice(0, 160)) + (res.pass ? ' contains ' : ' does NOT contain ') + JSON.stringify(want);
      return res;
    }
    if (c.kind === 'value') { res.pass = String(el.value || '') === String(c.expect || ''); res.detail = 'value is ' + JSON.stringify(String(el.value || '').slice(0, 80)); return res; }
    if (c.kind === 'style') {
      var got = getComputedStyle(el).getPropertyValue(c.prop);
      res.pass = String(got).trim() === String(c.expect).trim();
      res.detail = c.prop + ' = ' + got + ' (expected ' + c.expect + ')';
      return res;
    }
    if (c.kind === 'contrast') {
      var cc = contrastOf(el);
      res.pass = !!(cc && cc.ratio >= (Number(c.expect) || 4.5));
      res.detail = cc ? cc.ratio + ':1' : 'unknown';
      return res;
    }
    if (c.kind === 'rect') {
      var rr = rectOf(el);
      res.pass = (!c.minWidth || rr.w >= c.minWidth) && (!c.minHeight || rr.h >= c.minHeight) && (!c.maxWidth || rr.w <= c.maxWidth);
      res.detail = 'rect ' + rr.w + 'x' + rr.h;
      return res;
    }
    res.detail = 'unknown check kind: ' + c.kind;
    return res;
  }

  /* ---------------- overlay highlighting ---------------- */
  function ensureOverlay() {
    if (overlay && overlay.parentNode) return overlay;
    overlay = document.createElement('div');
    overlay.setAttribute('data-re-overlay', '1');
    overlay.style.cssText = 'position:fixed;z-index:2147483647;pointer-events:none;border:2px solid #3ddc84;background:rgba(61,220,132,0.14);border-radius:4px;transition:all .12s ease;top:0;left:0;width:0;height:0;' +
      'font:600 10px/1.2 system-ui,sans-serif;color:#05170e;box-shadow:0 6px 24px rgba(0,0,0,.35)';
    overlay.innerHTML = '<span style="position:absolute;top:-18px;left:0;background:#3ddc84;color:#05170e;padding:1px 5px;border-radius:4px;white-space:nowrap"></span>';
    (document.body || document.documentElement).appendChild(overlay);
    return overlay;
  }
  function highlight(el, keep) {
    var o = ensureOverlay();
    if (!el) { o.style.width = '0px'; o.style.height = '0px'; return { ok: true }; }
    var r = el.getBoundingClientRect();
    o.style.top = r.top + 'px'; o.style.left = r.left + 'px';
    o.style.width = r.width + 'px'; o.style.height = r.height + 'px';
    o.firstChild.textContent = el.tagName.toLowerCase() + ' · ' + Math.round(r.width) + '×' + Math.round(r.height) + (accessibleName(el) ? ' · ' + accessibleName(el).slice(0, 40) : '');
    if (!keep) setTimeout(function () { if (overlay) { overlay.style.width = '0px'; overlay.style.height = '0px'; } }, 1400);
    return { ok: true, rect: rectOf(el) };
  }
  window.addEventListener('scroll', function () { if (overlay) { overlay.style.width = '0px'; overlay.style.height = '0px'; } }, true);

  /* ---------------- pointer cursor ---------------- */
  // The design-mode pointer draws the user's own avatar where the mouse is, so
  // the system arrow has to go away while it is on. The parent page cannot do
  // that: this document is a different origin, and a cursor rule does not
  // cross the frame boundary. One injected rule does.
  var cursorStyle = null;
  var pointerWatch = false;
  var pointerMove = null;
  var pointerLast = 0;
  // The parent page cannot see the mouse once it is over this frame: mouse
  // events do not cross the boundary. Design mode's pointer needs them, so the
  // bridge reports them across, throttled to roughly one frame, and only while
  // the pointer is actually switched on.
  function watchPointer(on) {
    pointerWatch = !!on;
    if (pointerMove) { document.removeEventListener('mousemove', pointerMove, true); pointerMove = null; }
    if (!pointerWatch) return;
    pointerMove = function (e) {
      var now = Date.now();
      if (now - pointerLast < 40) return;
      pointerLast = now;
      send('pointer', { x: e.clientX, y: e.clientY, target: e.target && e.target.tagName ? e.target.tagName.toLowerCase() : '' });
    };
    document.addEventListener('mousemove', pointerMove, true);
  }
  function setPointerCursor(on) {
    if (on) {
      if (!cursorStyle) {
        cursorStyle = document.createElement('style');
        cursorStyle.setAttribute('data-re-pointer', '1');
        cursorStyle.textContent = 'html, body, *, *::before, *::after { cursor: none !important; }';
        (document.head || document.documentElement).appendChild(cursorStyle);
      }
    } else if (cursorStyle) {
      try { cursorStyle.parentNode && cursorStyle.parentNode.removeChild(cursorStyle); } catch (e) {}
      cursorStyle = null;
    }
    watchPointer(on);
    return { ok: true, pointerCursor: !!on };
  }

  /* ---------------- element picker ---------------- */
  var pickHandler = null, pickHover = null;
  function setPick(on) {
    pickMode = !!on;
    if (pickHandler) { document.removeEventListener('mousemove', pickHover, true); document.removeEventListener('click', pickHandler, true); pickHandler = null; }
    if (!pickMode) { return { ok: true, picking: false }; }
    pickHover = function (e) { if (e.target && e.target.getAttribute && e.target.getAttribute('data-re-overlay')) return; highlight(e.target, true); };
    pickHandler = function (e) {
      e.preventDefault(); e.stopPropagation();
      var el = e.target;
      setPick(false);
      highlight(el, false);
      send('picked', describe(el));
    };
    document.addEventListener('mousemove', pickHover, true);
    document.addEventListener('click', pickHandler, true);
    return { ok: true, picking: true };
  }

  /* ---------------- screenshot (DOM → SVG → canvas) ---------------- */
  var SCREENSHOT_PROPS = ['display', 'position', 'top', 'left', 'right', 'bottom', 'width', 'height', 'min-width', 'min-height',
    'max-width', 'max-height', 'margin', 'padding', 'border', 'border-width', 'border-style', 'border-color', 'border-radius',
    'background', 'background-color', 'background-image', 'background-size', 'background-position', 'background-repeat',
    'color', 'font-family', 'font-size', 'font-weight', 'font-style', 'line-height', 'letter-spacing', 'text-align',
    'text-decoration', 'text-transform', 'white-space', 'overflow', 'overflow-x', 'overflow-y', 'opacity', 'box-shadow',
    'flex-direction', 'flex-wrap', 'align-items', 'justify-content', 'gap', 'grid-template-columns', 'grid-template-rows',
    'grid-column', 'grid-row', 'transform', 'vertical-align', 'object-fit', 'list-style', 'z-index', 'visibility', 'pointer-events'];
  function inlineStyles(src, dst, depth) {
    if (depth > 22) return;
    var cs = getComputedStyle(src);
    var css = '';
    for (var i = 0; i < SCREENSHOT_PROPS.length; i++) {
      var v = cs.getPropertyValue(SCREENSHOT_PROPS[i]);
      if (!v || v === 'none' && SCREENSHOT_PROPS[i].indexOf('background') === 0) { if (SCREENSHOT_PROPS[i] === 'background-image') css += 'background-image:none;'; continue; }
      css += SCREENSHOT_PROPS[i] + ':' + v + ';';
    }
    var r = src.getBoundingClientRect();
    if (r.width > 0 && r.height > 0 && (cs.position === 'static')) css += 'box-sizing:border-box;';
    dst.setAttribute('style', css);
    if (src.tagName === 'IMG') {
      try {
        var c = document.createElement('canvas');
        c.width = src.naturalWidth || src.width; c.height = src.naturalHeight || src.height;
        c.getContext('2d').drawImage(src, 0, 0);
        dst.setAttribute('src', c.toDataURL('image/png'));
      } catch (e) { dst.setAttribute('src', src.currentSrc || src.src || ''); }
    }
    if (src.tagName === 'INPUT' || src.tagName === 'TEXTAREA') { try { dst.setAttribute('value', src.value); } catch (e) {} }
    if (src.tagName === 'CANVAS') {
      try {
        var img = document.createElement('img');
        img.setAttribute('src', src.toDataURL('image/png'));
        img.setAttribute('style', dst.getAttribute('style'));
        dst.parentNode.replaceChild(img, dst);
        return;
      } catch (e) { /* tainted canvas — skip */ }
    }
    var sc = src.children, dc = dst.children;
    for (var k = 0; k < sc.length && k < dc.length; k++) {
      if (sc[k].tagName === 'SCRIPT' || sc[k].tagName === 'NOSCRIPT' || sc[k].tagName === 'LINK') continue;
      inlineStyles(sc[k], dc[k], depth + 1);
    }
  }
  function screenshot(opts) {
    opts = opts || {};
    return new Promise(function (resolve) {
      try {
        var w = Math.max(320, window.innerWidth);
        var full = !!opts.full;
        var h = full ? Math.max(window.innerHeight, document.documentElement.scrollHeight) : window.innerHeight;
        var scale = Math.min(opts.scale || 1, 2);
        var clone = document.documentElement.cloneNode(true);
        var dead = clone.querySelectorAll('script,link[rel="preload"]');
        for (var i = 0; i < dead.length; i++) dead[i].parentNode.removeChild(dead[i]);
        var bodyClone = clone.querySelector('body') || clone;
        inlineStyles(document.body, bodyClone, 0);
        bodyClone.style.margin = '0';
        var svg = '<svg xmlns="http://www.w3.org/2000/svg" width="' + w + '" height="' + h + '" viewBox="0 0 ' + w + ' ' + h + '">' +
          '<foreignObject x="0" y="0" width="100%" height="100%">' +
          '<div xmlns="http://www.w3.org/1999/xhtml" style="width:' + w + 'px;height:' + h + 'px;overflow:hidden;background:#fff">' +
          new XMLSerializer().serializeToString(bodyClone) + '</div></foreignObject></svg>';
        var url = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg);
        var img = new Image();
        img.onload = function () {
          try {
            var canvas = document.createElement('canvas');
            canvas.width = Math.round(w * scale); canvas.height = Math.round(h * scale);
            var ctx = canvas.getContext('2d');
            ctx.fillStyle = '#ffffff'; ctx.fillRect(0, 0, canvas.width, canvas.height);
            ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
            var fmt = opts.format === 'png' ? 'image/png' : 'image/jpeg';
            resolve({ ok: true, dataUrl: canvas.toDataURL(fmt, opts.quality || 0.82), width: canvas.width, height: canvas.height, url: location.href, title: document.title });
          } catch (e) { resolve({ ok: false, error: 'canvas encode failed: ' + e.message }); }
        };
        img.onerror = function () { resolve({ ok: false, error: 'svg rasterise failed' }); };
        img.src = url;
      } catch (e) { resolve({ ok: false, error: String(e && e.message || e) }); }
    });
  }

  /* ---------------- responsive metrics ---------------- */
  function metrics() {
    var vp = { w: window.innerWidth, h: window.innerHeight };
    var overflowing = [];
    var all = document.querySelectorAll('body *');
    for (var i = 0; i < all.length && overflowing.length < 12; i++) {
      var el = all[i];
      if (!isVisible(el)) continue;
      var r = el.getBoundingClientRect();
      if (r.right > vp.w + 2 && r.width < 4000) overflowing.push({ sel: cssPath(el), right: Math.round(r.right), width: Math.round(r.width), text: (el.innerText || '').replace(/\s+/g, ' ').trim().slice(0, 50) });
    }
    var smallest = [];
    var ctrls = document.querySelectorAll('button,a[href],input,select,textarea');
    for (var j = 0; j < ctrls.length && smallest.length < 10; j++) {
      if (!isVisible(ctrls[j])) continue;
      var rr = ctrls[j].getBoundingClientRect();
      if (rr.height < 32 || rr.width < 24) smallest.push({ sel: cssPath(ctrls[j]), w: Math.round(rr.width), h: Math.round(rr.height), name: accessibleName(ctrls[j]).slice(0, 40) });
    }
    return {
      viewport: vp,
      document: { scrollWidth: document.documentElement.scrollWidth, scrollHeight: document.documentElement.scrollHeight, nodes: document.getElementsByTagName('*').length },
      horizontalOverflow: document.documentElement.scrollWidth > vp.w + 2,
      overflowingElements: overflowing,
      smallTargets: smallest,
      media: (function () {
        var m = [];
        if (!window.matchMedia) return m;
        var mq = ['(max-width:480px)', '(max-width:768px)', '(max-width:1024px)', '(min-width:1280px)'];
        for (var i = 0; i < mq.length; i++) { try { m.push({ query: mq[i], matches: window.matchMedia(mq[i]).matches }); } catch (e) {} }
        return m;
      })()
    };
  }

  function interactiveMap() {
    var sel = 'button,a[href],input,select,textarea,[role="button"],[role="tab"],[role="link"],[data-testid]';
    var out = [];
    var els = document.querySelectorAll(sel);
    for (var i = 0; i < els.length && out.length < 120; i++) {
      var el = els[i];
      if (!isVisible(el)) continue;
      var r = rectOf(el);
      var typ = el.tagName === 'INPUT' || el.tagName === 'TEXTAREA' || el.tagName === 'SELECT';
      var kind = typ ? 'input' : (el.tagName === 'A' ? 'link' : 'button');
      var name = accessibleName(el).slice(0, 70);
      if (!name && !el.getAttribute('data-testid')) continue;
      out.push({
        uid: uid(el), sel: cssPath(el), kind: kind, name: name || '(unnamed)',
        testid: el.getAttribute('data-testid') || undefined,
        rect: r, aboveFold: r.y < window.innerHeight,
        currentValue: typ ? String(el.value || '').slice(0, 60) : undefined,
        disabled: !!el.disabled,
        pressed: el.getAttribute('aria-pressed') || undefined,
        href: el.getAttribute('href') || undefined,
        type: el.getAttribute('type') || undefined
      });
    }
    return { count: out.length, controls: out };
  }

  /* ---------------- messaging ---------------- */
  function consoleTail(n) {
    var seen = {};
    var out = [];
    for (var i = consoleLog.length - 1; i >= 0 && out.length < n; i--) {
      var l = consoleLog[i];
      var key = l.level + l.text.slice(0, 60);
      if (seen[key]) { seen[key].repeat++; continue; }
      seen[key] = { level: l.level, text: l.text, at: l.at, repeat: 1 };
      out.unshift(seen[key]);
    }
    return out;
  }
  function send(type, payload, id) {
    try { window.parent.postMessage({ source: BRIDGE_SOURCE, type: type, id: id, payload: payload, token: TOKEN }, '*'); } catch (e) {}
  }
  function handle(cmd, args, id) {
    args = args || {};
    var done = function (payload) { send('result', payload, id); };
    var fail = function (msg) { send('error', { message: String(msg) }, id); };
    try {
      switch (cmd) {
        case 'ping': return done({ pong: true, url: location.href, title: document.title, viewport: { w: innerWidth, h: innerHeight }, picking: pickMode });
        case 'snapshot': return done(snapshot(args));
        case 'inspect': { var el = resolve(args.target); return el ? done(describe(el)) : fail('element not found: ' + args.target); }
        case 'query': {
          var list = [];
          try { var m = document.querySelectorAll(args.selector); for (var i = 0; i < m.length && i < 40; i++) list.push(describe(m[i])); } catch (e) { return fail('bad selector'); }
          return done({ count: list.length, matches: list });
        }
        case 'click': {
          var c = clickTarget(resolve(args.target));
          if (!c.ok) return fail(c.error);
          setTimeout(function () {
            var after = document.getElementsByTagName('*').length;
            var delta = consoleLog.slice(c.before.nodes ? -8 : -8);
            done({
              clicked: c.name || c.tag, rect: c.rect, urlBefore: c.before.url, urlAfter: location.href,
              navigated: c.before.url !== location.href,
              domDelta: after - c.before.nodes,
              console: consoleTail(6)
            });
          }, args.waitMs || 450);
          return;
        }
        case 'type': {
          var t = typeInto(resolve(args.target), String(args.text == null ? '' : args.text), !!args.submit);
          if (!t.ok) return fail(t.error);
          setTimeout(function () { done({ typed: t.value, target: t.name, urlAfter: location.href, console: consoleTail(6) }); }, args.waitMs || 400);
          return;
        }
        case 'press': {
          var focused = document.activeElement;
          var ev = { key: args.key || 'Enter', code: args.key || 'Enter', keyCode: args.key === 'Tab' ? 9 : 13, bubbles: true };
          fire(focused, 'keydown', ev); fire(focused, 'keyup', ev);
          if (args.key === 'Escape') { var d = document.querySelector('[role="dialog"],dialog'); if (d && d.close) try { d.close(); } catch (e) {} }
          return done({ ok: true, focused: focused ? cssPath(focused) : null, urlAfter: location.href });
        }
        case 'scrollTo': { var s = resolve(args.target); if (!s) return fail('element not found'); if (s.scrollIntoView) s.scrollIntoView({ block: args.block || 'center', behavior: 'auto' }); return done({ ok: true, scrollY: Math.round(window.scrollY) }); }
        case 'scrollBy': { window.scrollBy(0, args.y || 0); return done({ ok: true, scrollY: Math.round(window.scrollY) }); }
        case 'assert': {
          var checks = (args.checks || []).map(checkOne);
          return done({ passed: checks.filter(function (c) { return c.pass; }).length, total: checks.length, results: checks, allPassed: checks.every(function (c) { return c.pass; }) });
        }
        case 'highlight': { return done(highlight(args.target ? resolve(args.target) : null, !!args.keep)); }
        case 'pick': return done(setPick(args.on !== false));
        case 'cursor': return done(setPointerCursor(args.on !== false));
        case 'console': { var tail = consoleTail(args.limit || 40); if (args.clear) { consoleLog = []; networkLog = []; } return done({ entries: tail, network: networkLog.slice(-10) }); }
        case 'metrics': return done(metrics());
        case 'controls': return done(interactiveMap());
        case 'audit': return done({ findings: audit(), viewport: { w: innerWidth, h: innerHeight }, url: location.href });
        case 'navigate': {
          var target = String(args.url || '/');
          var before = location.href;
          if (/^https?:/i.test(target)) location.href = target;
          else location.href = target.charAt(0) === '/' ? target : '/' + target;
          return done({ navigated: true, from: before, to: location.href });
        }
        case 'reload': location.reload(); return done({ reloading: true });
        case 'screenshot': screenshot(args).then(function (r) { r && r.ok ? done(r) : fail(r && r.error || 'screenshot failed'); }); return;
        case 'report': {
          return done({ snapshot: snapshot({ maxNodes: 120 }), metrics: metrics(), controls: interactiveMap(), console: consoleTail(20), network: networkLog.slice(-10) });
        }
        default: return fail('unknown command: ' + cmd);
      }
    } catch (e) { fail(e && e.message || String(e)); }
  }

  window.addEventListener('message', function (e) {
    var d = e.data;
    if (!d || d.source !== HOST_SOURCE || !d.cmd) return;
    if (TOKEN && d.token !== TOKEN) return;
    handle(d.cmd, d.args, d.id);
  });
  window.addEventListener('beforeunload', function () { navCount++; try { window.parent.postMessage({ source: BRIDGE_SOURCE, type: 'unloading', payload: { url: location.href } }, '*'); } catch (e) {} });

  // Announce readiness once the DOM exists (and again after load for late listeners).
  var announce = function () { send('ready', { url: location.href, title: document.title, viewport: { w: innerWidth, h: innerHeight }, ua: navigator.userAgent }); };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', announce);
  else announce();
  window.addEventListener('load', function () { setTimeout(announce, 150); setTimeout(function () { send('idle', { url: location.href, findings: audit().slice(0, 6), console: consoleTail(6) }); }, 1200); });
})();
`;
  }
});

// src/preview/manager.ts
var manager_exports = {};
__export(manager_exports, {
  MIME: () => MIME2,
  PreviewManager: () => PreviewManager,
  findOnPath: () => findOnPath,
  injectBridge: () => injectBridge,
  pythonBin: () => pythonBin
});
import { createServer as createServer2, request as httpRequest } from "node:http";
import { createConnection } from "node:net";
import { spawn as spawn5 } from "node:child_process";
import { existsSync as existsSync9, readFileSync as readFileSync5, statSync as statSync6, createReadStream as createReadStream2 } from "node:fs";
import { readFile as readFile6, readdir as readdir4 } from "node:fs/promises";
import { join as join14, extname as extname2, normalize as normalize2, delimiter } from "node:path";
function freePort() {
  return new Promise((resolve10, reject) => {
    const srv = createServer2();
    srv.on("error", reject);
    srv.listen(0, "0.0.0.0", () => {
      const addr = srv.address();
      const port = typeof addr === "object" && addr ? addr.port : 0;
      srv.close(() => resolve10(port));
    });
  });
}
function waitForPort(port, timeoutMs = 45e3) {
  const deadline = Date.now() + timeoutMs;
  return new Promise((resolve10) => {
    const attempt = () => {
      const sock = createConnection({ port, host: "127.0.0.1" });
      const done = (ok) => {
        sock.removeAllListeners();
        sock.destroy();
        ok ? resolve10(true) : Date.now() > deadline ? resolve10(false) : setTimeout(attempt, 350);
      };
      sock.once("connect", () => done(true));
      sock.once("error", () => done(false));
      sock.setTimeout(1500, () => done(false));
    };
    attempt();
  });
}
async function planFor(dir) {
  const has = (p) => existsSync9(join14(dir, p));
  const binPath = (name) => {
    const p = join14(dir, "node_modules", ".bin", name);
    return existsSync9(p) ? p : null;
  };
  let pkg = null;
  if (has("package.json")) {
    try {
      pkg = JSON.parse(await readFile6(join14(dir, "package.json"), "utf8"));
    } catch {
      pkg = null;
    }
  }
  const deps = { ...pkg?.dependencies ?? {}, ...pkg?.devDependencies ?? {} };
  const scripts = pkg?.scripts ?? {};
  const vite = binPath("vite");
  if (vite && (deps.vite || deps["@vitejs/plugin-react"] || scripts.dev?.includes("vite"))) {
    return { kind: "vite", command: "vite --port <p> --strictPort --host 0.0.0.0", bin: vite, args: (p) => ["--port", String(p), "--strictPort", "--host", "0.0.0.0"], needsPort: true };
  }
  const next = binPath("next");
  if (next && (deps.next || scripts.dev?.includes("next"))) {
    return { kind: "next", command: "next dev -p <p> -H 0.0.0.0", bin: next, args: (p) => ["dev", "-p", String(p), "-H", "0.0.0.0"], needsPort: true };
  }
  const astro = binPath("astro");
  if (astro && (deps.astro || scripts.dev?.includes("astro"))) {
    return { kind: "astro", command: "astro dev --port <p> --host 0.0.0.0", bin: astro, args: (p) => ["dev", "--port", String(p), "--host", "0.0.0.0"], needsPort: true };
  }
  const cra = binPath("react-scripts");
  if (cra && (deps["react-scripts"] || scripts.start?.includes("react-scripts"))) {
    return { kind: "cra", command: "react-scripts start (PORT=<p>)", bin: cra, args: () => ["start"], env: { PORT: "<p>", HOST: "0.0.0.0", BROWSER: "none", DANGEROUSLY_DISABLE_HOST_CHECK: "true" }, needsPort: true };
  }
  const python = pythonBin();
  if (has("manage.py") && python) {
    return { kind: "django", command: `${python} manage.py runserver 0.0.0.0:<p>`, bin: python, args: (p) => ["manage.py", "runserver", `0.0.0.0:${p}`, "--noreload"], needsPort: true };
  }
  if (scripts.dev && has("package.json")) {
    return { kind: "npm-dev", command: "npm run dev -- --port <p>", bin: "npm", args: (p) => ["run", "dev", "--", "--port", String(p), "--host"], env: { PORT: "<p>" }, needsPort: true };
  }
  if (scripts.start && has("package.json")) {
    return { kind: "npm-start", command: "npm run start (PORT=<p>)", bin: "npm", args: () => ["run", "start"], env: { PORT: "<p>", HOST: "0.0.0.0", BROWSER: "none" }, needsPort: true };
  }
  for (const candidate of ["index.html", "public/index.html", "dist/index.html", "build/index.html"]) {
    if (has(candidate)) {
      const folder = candidate.split("/")[0];
      const root = candidate === "index.html" ? dir : join14(dir, folder);
      return {
        kind: "static",
        command: candidate === "index.html" ? "static file server (project root)" : `static server (${folder}/)`,
        bin: "",
        args: () => [],
        static: true,
        needsPort: false,
        staticRoot: root
      };
    }
  }
  if ((has("requirements.txt") || has("pyproject.toml")) && python) {
    const entry = (await readdir4(dir)).find((f) => f === "app.py" || f === "main.py");
    if (entry) return { kind: "flask", command: `${python} ${entry}`, bin: python, args: () => [entry], env: { PORT: "<p>", FLASK_RUN_PORT: "<p>" }, needsPort: true };
  }
  return null;
}
function injectBridge(html) {
  const tag = `<script data-re-design-bridge>${BRIDGE_JS}</script>`;
  if (/<head[^>]*>/i.test(html)) return html.replace(/<head([^>]*)>/i, (m) => `${m}
${tag}`);
  if (/<html[^>]*>/i.test(html)) return html.replace(/<html([^>]*)>/i, (m) => `${m}
<head>${tag}</head>`);
  return tag + html;
}
function upstreamHeaders(headers, port) {
  const out = {};
  for (const [k, v] of Object.entries(headers)) {
    const lk = k.toLowerCase();
    if (lk === "host" || lk === "accept-encoding" || lk === "origin" || lk === "referer" || lk === "connection" || lk === "content-length") continue;
    out[k] = v;
  }
  out.host = `127.0.0.1:${port}`;
  return out;
}
function createProxy(session, upstream) {
  const server = createServer2((req, res) => {
    const url = req.url || "/";
    if (url.startsWith("/__re/bridge.js")) {
      res.writeHead(200, { "content-type": "text/javascript; charset=utf-8", "cache-control": "no-store" });
      res.end(BRIDGE_JS);
      return;
    }
    const port = upstream();
    if (!port) {
      serveStatic(session, req, res);
      return;
    }
    let up;
    try {
      up = httpRequest({ host: "127.0.0.1", port, method: req.method, path: url, headers: upstreamHeaders(req.headers, port) }, (r) => {
        const headers = { ...r.headers };
        for (const h of STRIP_HEADERS) delete headers[h];
        const ct = String(r.headers["content-type"] ?? "");
        if (ct.includes("text/html") || ct.includes("application/xhtml")) {
          const chunks = [];
          let size = 0;
          r.on("data", (c) => {
            size += c.length;
            if (size < 8e6) chunks.push(c);
          });
          r.on("end", () => {
            let html = Buffer.concat(chunks).toString("utf8");
            html = injectBridge(html);
            headers["content-type"] = "text/html; charset=utf-8";
            headers["content-length"] = Buffer.byteLength(html);
            headers["cache-control"] = "no-store";
            res.writeHead(r.statusCode ?? 200, headers);
            res.end(html);
          });
          return;
        }
        headers["cache-control"] = headers["cache-control"] ?? "no-store";
        res.writeHead(r.statusCode ?? 200, headers);
        r.pipe(res);
      });
    } catch (e) {
      res.writeHead(502, { "content-type": "text/plain" });
      res.end(`preview upstream error: ${e?.message ?? e}`);
      return;
    }
    up.on("error", (e) => {
      pushLog(session, `[proxy] upstream error: ${e?.message ?? e}`);
      if (!res.headersSent) res.writeHead(502, { "content-type": "text/html; charset=utf-8" });
      res.end(`<body style="font:14px system-ui;padding:40px;background:#111;color:#eee"><h3>Preview server is not responding</h3><p>${String(e?.message ?? e)}</p><p>Check the preview log in the IDE.</p></body>`);
    });
    req.pipe(up);
  });
  server.on("upgrade", (req, socket, head) => {
    const port = upstream();
    if (!port) {
      socket.destroy();
      return;
    }
    const up = createConnection({ host: "127.0.0.1", port }, () => {
      const raw = [`${req.method} ${req.url} HTTP/1.1`];
      const headers = { ...req.headers };
      headers.host = `127.0.0.1:${port}`;
      if (headers.origin) headers.origin = `http://127.0.0.1:${port}`;
      for (const [k, v] of Object.entries(headers)) {
        if (v === void 0) continue;
        raw.push(`${k}: ${Array.isArray(v) ? v.join(", ") : v}`);
      }
      up.write(raw.join("\r\n") + "\r\n\r\n");
      if (head?.length) up.write(head);
      socket.pipe(up);
      up.pipe(socket);
    });
    up.on("error", () => socket.destroy());
    socket.on("error", () => up.destroy());
  });
  return new Promise((resolve10, reject) => {
    server.on("error", reject);
    server.listen(session.publicPort, "0.0.0.0", () => resolve10(server));
  });
}
function findOnPath(name) {
  const dirs = (process.env.PATH ?? "").split(delimiter).filter(Boolean);
  for (const d of dirs) {
    if (process.platform !== "win32") {
      const full = join14(d, name);
      if (existsSync9(full)) return full;
    } else {
      for (const ext of PATH_EXTS) {
        const full = join14(d, name + ext);
        if (existsSync9(full)) return full;
      }
      const bare = join14(d, name);
      if (existsSync9(bare)) return bare;
    }
  }
  return null;
}
function pythonBin() {
  return findOnPath("python3") ?? findOnPath("python") ?? findOnPath("py");
}
function serveStatic(session, req, res) {
  const root = session.staticRoot;
  if (!root) {
    res.writeHead(404, { "content-type": "text/plain" });
    res.end("not found");
    return;
  }
  let rel = decodeURIComponent((req.url || "/").split("?")[0]);
  if (rel.endsWith("/")) rel += "index.html";
  const safe = normalize2(rel).replace(/^(\.\.[/\\])+/, "").replace(/^\/+/, "");
  let file2 = join14(root, safe);
  try {
    if (!isWithinDir(root, file2)) throw new Error("escape");
    if (existsSync9(file2) && statSync6(file2).isDirectory()) file2 = join14(file2, "index.html");
    if (!existsSync9(file2)) {
      const index = join14(root, "index.html");
      if (existsSync9(index) && !extname2(rel)) file2 = index;
      else {
        res.writeHead(404, { "content-type": "text/plain" });
        res.end("404");
        return;
      }
    }
    const st = statSync6(file2);
    const ext = extname2(file2).toLowerCase();
    const type = MIME2[ext] ?? "application/octet-stream";
    if (type.includes("text/html")) {
      const html = injectBridge(readFileSync5(file2, "utf8"));
      res.writeHead(200, { "content-type": type, "content-length": Buffer.byteLength(html), "cache-control": "no-store" });
      res.end(html);
      return;
    }
    res.writeHead(200, { "content-type": type, "content-length": st.size, "cache-control": "no-store" });
    createReadStream2(file2).pipe(res);
  } catch {
    res.writeHead(404, { "content-type": "text/plain" });
    res.end("404");
  }
}
function pushLog(session, line) {
  for (const l of String(line).split("\n")) {
    const t = l.replace(/\u001b\[[0-9;]*m/g, "").trimEnd();
    if (!t) continue;
    session.logs.push(t.slice(0, 500));
  }
  if (session.logs.length > MAX_LOGS) session.logs.splice(0, session.logs.length - MAX_LOGS);
}
function sniffPort(text2) {
  const m = text2.match(/(?:localhost|127\.0\.0\.1|0\.0\.0\.0|\[::\]|:)(?::)?(\d{2,5})\b/);
  if (!m) return null;
  const p = Number(m[1]);
  return p > 0 && p < 65536 ? p : null;
}
function scrubbedEnv2() {
  const out = {};
  for (const [k, v] of Object.entries(process.env)) {
    if (/key|token|secret|passw|credential|auth/i.test(k)) continue;
    if (typeof v === "string") out[k] = v;
  }
  return out;
}
var MAX_LOGS, MIME2, STRIP_HEADERS, PATH_EXTS, PreviewManager;
var init_manager = __esm({
  "src/preview/manager.ts"() {
    "use strict";
    init_bridge();
    init_paths();
    MAX_LOGS = 400;
    MIME2 = {
      ".html": "text/html; charset=utf-8",
      ".js": "text/javascript; charset=utf-8",
      ".mjs": "text/javascript; charset=utf-8",
      ".css": "text/css; charset=utf-8",
      ".json": "application/json; charset=utf-8",
      ".svg": "image/svg+xml",
      ".png": "image/png",
      ".jpg": "image/jpeg",
      ".jpeg": "image/jpeg",
      ".gif": "image/gif",
      ".webp": "image/webp",
      ".ico": "image/x-icon",
      ".woff": "font/woff",
      ".woff2": "font/woff2",
      ".ttf": "font/ttf",
      ".mp4": "video/mp4",
      ".txt": "text/plain; charset=utf-8",
      ".map": "application/json"
    };
    STRIP_HEADERS = ["x-frame-options", "content-security-policy", "content-security-policy-report-only", "cross-origin-opener-policy", "cross-origin-embedder-policy", "content-length", "content-encoding", "transfer-encoding", "connection"];
    PATH_EXTS = process.platform === "win32" ? (process.env.PATHEXT ?? ".EXE;.CMD;.BAT;.COM").split(";").filter(Boolean) : [""];
    PreviewManager = class {
      sessions = /* @__PURE__ */ new Map();
      info(project) {
        const s = this.sessions.get(project);
        if (!s) return null;
        return {
          running: true,
          project: s.project,
          kind: s.kind,
          command: s.command,
          port: s.publicPort,
          internalPort: s.internalPort,
          url: `http://127.0.0.1:${s.publicPort}/`,
          startedAt: s.startedAt,
          ready: s.ready,
          error: s.error,
          logs: s.logs.slice(-120)
        };
      }
      list() {
        return [...this.sessions.keys()].map((k) => this.info(k)).filter(Boolean);
      }
      /**
       * Start (or restart) the preview for a project.
       *
       * A restart keeps the SAME public port and proxy, so the pane the user is
       * looking at does not have to be re-created — only the inner dev server is
       * replaced. That keeps the embedded iframe URL stable across AI edits.
       */
      async start(project, dir, opts = {}) {
        const existing = this.sessions.get(project);
        if (existing && !opts.restart && (existing.ready || !existing.error && existing.child)) return this.info(project);
        if (existing) {
          await this.killChild(existing);
          existing.error = null;
          existing.ready = false;
          existing.logs.push("[re] restarting preview\u2026");
          await this.bringUp(existing, dir);
          return this.info(project);
        }
        const session = {
          project,
          dir,
          kind: "starting",
          command: "",
          internalPort: null,
          publicPort: 0,
          proxy: null,
          child: null,
          staticRoot: null,
          startedAt: Date.now(),
          logs: [],
          ready: false,
          error: null
        };
        session.logs.push(`[re] preparing preview for ${project}`);
        this.sessions.set(project, session);
        session.publicPort = await freePort();
        try {
          await this.bringUp(session, dir);
          session.proxy = await createProxy(session, () => session.ready && session.internalPort ? session.internalPort : null);
          session.logs.push(`[re] preview proxy on 0.0.0.0:${session.publicPort}`);
        } catch (e) {
          session.error = String(e?.message ?? e);
          session.logs.push(`[re] preview failed: ${session.error}`);
        }
        return this.info(project);
      }
      /** Detect the stack, launch the dev server (or static server) and wait for it. */
      async bringUp(session, dir) {
        let plan = null;
        try {
          plan = await planFor(dir);
        } catch {
          plan = null;
        }
        if (!plan) {
          session.kind = "none";
          session.command = "\u2014";
          session.error = "No runnable entry point found. Add a package.json script (dev/start), an index.html, or a manage.py.";
          return;
        }
        if (plan.static) {
          session.kind = "static";
          session.command = plan.command;
          session.staticRoot = plan.staticRoot ?? dir;
          session.ready = true;
          session.logs.push(`[re] serving static files from ${session.staticRoot}`);
          return;
        }
        const port = await freePort();
        session.internalPort = port;
        const env = { ...scrubbedEnv2(), PORT: String(port), HOST: "0.0.0.0", BROWSER: "none", FORCE_COLOR: "0", CI: "1" };
        for (const [k, v] of Object.entries(plan.env ?? {})) env[k] = String(v).replace("<p>", String(port));
        const args2 = plan.args(port);
        session.kind = plan.kind;
        session.command = plan.command.replace(/<p>/g, String(port));
        session.logs.push(`[re] $ ${plan.bin} ${args2.join(" ")}`);
        const child = spawn5(plan.bin, args2, { cwd: dir, env, stdio: ["ignore", "pipe", "pipe"], detached: true, shell: process.platform === "win32" });
        session.child = child;
        child.stdout?.on("data", (d) => {
          pushLog(session, d.toString());
          const p = sniffPort(d.toString());
          if (p && !session.ready) session.internalPort = p;
        });
        child.stderr?.on("data", (d) => pushLog(session, d.toString()));
        child.on("exit", (code, signal) => {
          pushLog(session, `[re] process exited (code ${code ?? "null"}${signal ? `, ${signal}` : ""})`);
          if (code !== 0 && !session.ready) session.error = `The dev server exited with code ${code}. See the preview log.`;
          session.ready = false;
        });
        const live = await waitForPort(session.internalPort, 45e3);
        if (!live) {
          session.error = `Nothing started listening on port ${session.internalPort} after 45s. Check the preview log and the project's dev script.`;
        } else {
          session.ready = true;
          session.logs.push(`[re] dev server listening on 127.0.0.1:${session.internalPort}`);
        }
      }
      /** Only the spawned process — the proxy and its port survive a restart. */
      async killChild(s) {
        if (!s.child?.pid) return;
        try {
          process.kill(-s.child.pid, "SIGTERM");
        } catch {
          try {
            s.child.kill("SIGTERM");
          } catch {
          }
        }
        await new Promise((r) => setTimeout(r, 350));
        try {
          process.kill(-s.child.pid, "SIGKILL");
        } catch {
        }
        s.child = null;
      }
      async stop(project) {
        const s = this.sessions.get(project);
        if (!s) return false;
        this.sessions.delete(project);
        await this.kill(s);
        return true;
      }
      async kill(s) {
        try {
          s.proxy?.close();
        } catch {
        }
        await this.killChild(s);
      }
      async stopAll() {
        for (const key of [...this.sessions.keys()]) await this.stop(key);
      }
      /**
       * Synchronous teardown for process exit. Dev servers are their own process
       * group (detached), so a SIGKILL to -pid takes the whole tree with it — no
       * orphan node processes pointing at a dead proxy.
       */
      stopAllSync() {
        for (const [, s] of this.sessions) {
          try {
            s.proxy?.close();
          } catch {
          }
          if (s.child?.pid) {
            try {
              process.kill(-s.child.pid, "SIGKILL");
            } catch {
              try {
                s.child.kill("SIGKILL");
              } catch {
              }
            }
          }
        }
        this.sessions.clear();
      }
      /** Restart after the AI (or the user) changed the code. */
      async reload(project) {
        const s = this.sessions.get(project);
        if (!s) return null;
        return this.start(project, s.dir, { restart: true });
      }
      /** Absolute path of a running preview (used for logs/diagnostics). */
      dirOf(project) {
        return this.sessions.get(project)?.dir ?? null;
      }
      /**
       * Static-file previews can also be served *through the app origin*
       * (`/api/ide/preview/site`). That is the fallback path for hosts that refuse
       * to embed a page from another port; it needs the folder, nothing else.
       */
      staticRootFor(project, fallbackDir) {
        const s = this.sessions.get(project);
        if (s?.staticRoot) return s.staticRoot;
        if (fallbackDir) {
          for (const candidate of ["", "public", "dist", "build"]) {
            const root = candidate ? join14(fallbackDir, candidate) : fallbackDir;
            if (existsSync9(join14(root, "index.html"))) return root;
          }
        }
        return null;
      }
    };
  }
});

// src/routes/preview.ts
var preview_exports = {};
__export(preview_exports, {
  previewRoutes: () => previewRoutes
});
import { Hono as Hono16 } from "hono";
import { existsSync as existsSync10, statSync as statSync7, readFileSync as readFileSync6, createReadStream as createReadStream3 } from "node:fs";
import { extname as extname3, join as join15, normalize as normalize3 } from "node:path";
function previewRoutes(rt, manager) {
  const r = new Hono16();
  const projectsRoot = projectsRootOf(rt.dataDir);
  const dirFor = (name) => {
    const dir = projectDirOf(projectsRoot, name);
    return dir && existsSync10(dir) ? dir : null;
  };
  r.get("/ide/preview", (c) => c.json({ previews: manager.list() }));
  r.get("/ide/preview/status", (c) => {
    const project = c.req.query("project") ?? "";
    const info = manager.info(project);
    return c.json(info ? { ...info, running: info.running ?? true } : { running: false, project });
  });
  r.post("/ide/preview/start", async (c) => {
    let body;
    try {
      body = await c.req.json();
    } catch {
      return c.json({ error: "Invalid JSON body." }, 400);
    }
    const project = String(body.project ?? "");
    const dir = dirFor(project);
    if (!dir) return c.json({ error: "Project not found." }, 404);
    try {
      const info = await manager.start(project, dir, { restart: !!body.restart });
      return c.json({ ok: !info.error, ...info });
    } catch (e) {
      return c.json({ error: String(e?.message ?? e) }, 500);
    }
  });
  r.post("/ide/preview/stop", async (c) => {
    let body;
    try {
      body = await c.req.json();
    } catch {
      return c.json({ error: "Invalid JSON body." }, 400);
    }
    const stopped = await manager.stop(String(body.project ?? ""));
    return c.json({ ok: stopped });
  });
  r.post("/ide/preview/reload", async (c) => {
    let body;
    try {
      body = await c.req.json();
    } catch {
      return c.json({ error: "Invalid JSON body." }, 400);
    }
    const info = await manager.reload(String(body.project ?? ""));
    if (!info) return c.json({ error: "No preview running for this project." }, 404);
    return c.json({ ok: !info.error, ...info });
  });
  r.get("/ide/preview/site", (c) => {
    const project = c.req.query("project") ?? "";
    const rel = decodeURIComponent(c.req.query("path") ?? "/");
    const dir = dirFor(project);
    if (!dir) return c.json({ error: "Project not found." }, 404);
    const root = manager.staticRootFor(project, dir);
    if (!root) return c.json({ error: "This project needs a running dev server \u2014 start the preview first." }, 404);
    const prefix = `/api/ide/preview/site?project=${encodeURIComponent(project)}&path=`;
    const safe = normalize3(rel.split("?")[0]).replace(/^(\.\.[/\\])+/, "").replace(/^\/+/, "");
    let file2 = join15(root, safe);
    if (!file2.startsWith(root)) return c.json({ error: "Path escapes the project." }, 400);
    if (existsSync10(file2) && statSync7(file2).isDirectory()) file2 = join15(file2, "index.html");
    if (!existsSync10(file2)) {
      const index = join15(root, "index.html");
      if (existsSync10(index) && !extname3(safe)) file2 = index;
      else return c.text("404", 404);
    }
    const ext = extname3(file2).toLowerCase();
    const type = MIME2[ext] ?? "application/octet-stream";
    if (type.includes("text/html")) {
      let html = readFileSync6(file2, "utf8");
      html = html.replace(/(\s(?:href|src|action)=)(["'])\/(?!\/)/g, (_m, attr, q) => `${attr}${q}${prefix}`);
      html = injectBridge(html);
      return c.body(html, 200, { "content-type": "text/html; charset=utf-8", "cache-control": "no-store" });
    }
    if (type.startsWith("text/css") || type.includes("javascript")) {
      const text2 = readFileSync6(file2, "utf8").replace(/url\((["']?)\//g, `url($1${prefix}`);
      return c.body(text2, 200, { "content-type": type, "cache-control": "no-store" });
    }
    c.header("content-type", type);
    c.header("cache-control", "no-store");
    return c.body(createReadStream3(file2), 200);
  });
  r.get("/ide/preview/logs", (c) => {
    const info = manager.info(c.req.query("project") ?? "");
    return c.json({ logs: info?.logs ?? [] });
  });
  return r;
}
var init_preview = __esm({
  "src/routes/preview.ts"() {
    "use strict";
    init_manager();
    init_paths();
  }
});

// src/routes/connectors.ts
var connectors_exports = {};
__export(connectors_exports, {
  connectorRoutes: () => connectorRoutes
});
import { mkdir as mkdir5, readFile as readFile7, readdir as readdir5, rm as rm3, writeFile as writeFile6 } from "node:fs/promises";
import { join as join16, resolve as resolve9 } from "node:path";
import { randomUUID as randomUUID3 } from "node:crypto";
import { Hono as Hono17 } from "hono";
function connectorRoutes(rt) {
  const r = new Hono17();
  const root = resolve9(join16(rt.dataDir, "connectors"));
  const boxDir = (box) => join16(root, box);
  const isBox = (b) => BOXES.includes(b);
  const listItems = async (box) => {
    await mkdir5(boxDir(box), { recursive: true });
    const out = [];
    for (const f of await readdir5(boxDir(box))) {
      if (!f.endsWith(".json")) continue;
      try {
        out.push(JSON.parse(await readFile7(join16(boxDir(box), f), "utf8")));
      } catch {
      }
    }
    return out.sort((a, b) => (b.addedAt ?? b.date ?? 0) - (a.addedAt ?? a.date ?? 0));
  };
  r.get("/connectors/list", async (c) => {
    const box = c.req.query("box") ?? "";
    if (!isBox(box)) return c.json({ error: "Unknown connector box." }, 400);
    const items = await listItems(box);
    return c.json({ box, items: items.map(({ dataBase64, body, notes, ...rest }) => ({ ...rest, preview: (body ?? notes ?? "").slice(0, 160) })) });
  });
  r.get("/connectors/item", async (c) => {
    const box = c.req.query("box") ?? "";
    const id = (c.req.query("id") ?? "").replace(/[^a-zA-Z0-9_-]/g, "");
    if (!isBox(box) || !id) return c.json({ error: "Bad request." }, 400);
    try {
      const item = JSON.parse(await readFile7(join16(boxDir(box), `${id}.json`), "utf8"));
      if (box !== "drive") delete item.dataBase64;
      return c.json({ item });
    } catch {
      return c.json({ error: "Item not found." }, 404);
    }
  });
  r.get("/connectors/search", async (c) => {
    const q = (c.req.query("q") ?? "").toLowerCase();
    const box = c.req.query("box") ?? "";
    const boxes = isBox(box) ? [box] : ["drive", "mail", "calendar"];
    const hits = [];
    for (const b of boxes) {
      for (const item of await listItems(b)) {
        const hay = JSON.stringify({ ...item, dataBase64: void 0 }).toLowerCase();
        if (!q || hay.includes(q)) hits.push({ box: b, id: item.id, title: item.name ?? item.subject ?? item.title, snippet: (item.body ?? item.notes ?? item.text ?? "").slice(0, 200), date: item.date ?? item.addedAt });
      }
    }
    return c.json({ q, hits: hits.slice(0, 40) });
  });
  r.post("/connectors/add", async (c) => {
    let body;
    try {
      body = await c.req.json();
    } catch {
      return c.json({ error: "Invalid JSON body." }, 400);
    }
    const box = body.box;
    if (!isBox(box)) return c.json({ error: "Unknown connector box." }, 400);
    const id = randomUUID3().slice(0, 8);
    let item;
    if (box === "drive" || box === "files") {
      const buf = Buffer.from(body.dataBase64 ?? "", "base64");
      if (buf.length > CAPS[box]) return c.json({ error: "File larger than 8 MB." }, 413);
      if (!buf.length && !String(body.text ?? "").trim()) return c.json({ error: "Provide a file or some text." }, 400);
      item = { id, name: String(body.name ?? "file").slice(0, 200), mime: body.mime ?? (buf.length ? "application/octet-stream" : "text/plain"), text: body.text ?? null, dataBase64: buf.length ? body.dataBase64 : null, addedAt: Date.now() };
    } else if (box === "mail") {
      item = { id, from: body.from ?? "", to: body.to ?? "", subject: String(body.subject ?? "").slice(0, 300), body: String(body.body ?? "").slice(0, CAPS.mail), date: body.date ?? (/* @__PURE__ */ new Date()).toISOString(), read: false, addedAt: Date.now() };
    } else {
      item = { id, title: String(body.title ?? "").slice(0, 300), date: body.date ?? "", time: body.time ?? "", location: body.location ?? "", notes: String(body.notes ?? "").slice(0, CAPS.calendar), attendees: body.attendees ?? [], addedAt: Date.now() };
    }
    await mkdir5(boxDir(box), { recursive: true });
    await writeFile6(join16(boxDir(box), `${id}.json`), JSON.stringify(item));
    return c.json({ ok: true, id });
  });
  r.delete("/connectors/item", async (c) => {
    const box = c.req.query("box") ?? "";
    const id = (c.req.query("id") ?? "").replace(/[^a-zA-Z0-9_-]/g, "");
    if (!isBox(box) || !id) return c.json({ error: "Bad request." }, 400);
    await rm3(join16(boxDir(box), `${id}.json`), { force: true });
    return c.json({ ok: true });
  });
  return r;
}
var BOXES, CAPS;
var init_connectors = __esm({
  "src/routes/connectors.ts"() {
    "use strict";
    BOXES = ["drive", "mail", "calendar", "files"];
    CAPS = { drive: 8 * 1024 * 1024, mail: 512 * 1024, calendar: 256 * 1024, files: 8 * 1024 * 1024 };
  }
});

// src/routes/mcp.ts
var mcp_exports = {};
__export(mcp_exports, {
  mcpRoutes: () => mcpRoutes
});
import { spawn as spawn6 } from "node:child_process";
import { Hono as Hono18 } from "hono";
function scrubServer(s) {
  const command = String(s?.command ?? "").trim();
  if (!command || /[;&|`$]/.test(command)) throw new Error("Invalid MCP command");
  const args2 = Array.isArray(s?.args) ? s.args.map(String).slice(0, 24) : [];
  const env = {};
  if (s?.env && typeof s.env === "object") {
    for (const [k, v] of Object.entries(s.env)) {
      if (/^[A-Za-z_][A-Za-z0-9_]*$/.test(k) && typeof v === "string") env[k] = v;
    }
  }
  return { command, args: args2, env };
}
function mcpRoutes() {
  const r = new Hono18();
  r.post("/mcp/tools", async (c) => {
    let body;
    try {
      body = await c.req.json();
    } catch {
      return c.json({ error: "Invalid JSON body." }, 400);
    }
    const out = [];
    for (const s of body.servers ?? []) {
      let session = null;
      try {
        const { command, args: args2, env } = scrubServer(s);
        session = new McpSession(command, args2, env);
        await session.init();
        const res = await session.request("tools/list", {}, HANDSHAKE_TIMEOUT_MS);
        out.push({ serverId: s.id, serverName: s.name ?? s.id, ok: true, tools: (res?.tools ?? []).map((t) => ({ name: t.name, description: t.description ?? "", inputSchema: t.inputSchema ?? {} })) });
      } catch (e) {
        out.push({ serverId: s.id, serverName: s.name ?? s.id, ok: false, error: String(e?.message ?? e), tools: [] });
      } finally {
        session?.kill();
      }
    }
    return c.json({ servers: out });
  });
  r.post("/mcp/call", async (c) => {
    let body;
    try {
      body = await c.req.json();
    } catch {
      return c.json({ error: "Invalid JSON body." }, 400);
    }
    let session = null;
    try {
      const { command, args: args2, env } = scrubServer(body.server);
      session = new McpSession(command, args2, env);
      await session.init();
      const res = await session.request("tools/call", { name: body.name, arguments: body.arguments ?? {} });
      const text2 = (res?.content ?? []).map((p) => p?.text ?? "").join("\n").slice(0, 1e5);
      return c.json({ ok: !res?.isError, text: text2, isError: !!res?.isError });
    } catch (e) {
      return c.json({ ok: false, isError: true, text: `MCP call failed: ${String(e?.message ?? e)}` }, 200);
    } finally {
      session?.kill();
    }
  });
  return r;
}
var PROTOCOL_VERSION, HANDSHAKE_TIMEOUT_MS, CALL_TIMEOUT_MS, McpSession;
var init_mcp = __esm({
  "src/routes/mcp.ts"() {
    "use strict";
    PROTOCOL_VERSION = "2024-11-05";
    HANDSHAKE_TIMEOUT_MS = 12e3;
    CALL_TIMEOUT_MS = 3e4;
    McpSession = class {
      child;
      buf = "";
      nextId = 1;
      pending = /* @__PURE__ */ new Map();
      dead = false;
      constructor(command, args2, env) {
        this.child = spawn6(command, args2, {
          stdio: ["pipe", "pipe", "pipe"],
          env: { PATH: process.env.PATH ?? "/usr/bin:/bin", HOME: process.env.HOME ?? "", ...env }
        });
        this.child.stdout.on("data", (d) => this.onData(d.toString()));
        this.child.stderr.on("data", () => {
        });
        this.child.on("exit", () => {
          this.dead = true;
          for (const p of this.pending.values()) p.reject(new Error("MCP server exited"));
        });
        this.child.on("error", (e) => {
          this.dead = true;
          for (const p of this.pending.values()) p.reject(e);
        });
      }
      onData(chunk) {
        this.buf += chunk;
        let idx;
        while ((idx = this.buf.indexOf("\n")) >= 0) {
          const line = this.buf.slice(0, idx).trim();
          this.buf = this.buf.slice(idx + 1);
          if (!line) continue;
          try {
            const msg = JSON.parse(line);
            if (msg.id != null && this.pending.has(msg.id)) {
              const p = this.pending.get(msg.id);
              this.pending.delete(msg.id);
              if (msg.error) p.reject(new Error(msg.error?.message ?? "MCP error"));
              else p.resolve(msg.result);
            }
          } catch {
          }
        }
      }
      notify(method, params) {
        if (this.dead) return;
        this.child.stdin.write(JSON.stringify({ jsonrpc: "2.0", method, params }) + "\n");
      }
      request(method, params, timeoutMs = CALL_TIMEOUT_MS) {
        if (this.dead) return Promise.reject(new Error("MCP server not running"));
        const id = this.nextId++;
        return new Promise((resolve10, reject) => {
          const to = setTimeout(() => {
            this.pending.delete(id);
            reject(new Error(`Timed out after ${Math.round(timeoutMs / 1e3)}s`));
          }, timeoutMs);
          this.pending.set(id, {
            resolve: (v) => {
              clearTimeout(to);
              resolve10(v);
            },
            reject: (e) => {
              clearTimeout(to);
              reject(e);
            }
          });
          this.child.stdin.write(JSON.stringify({ jsonrpc: "2.0", id, method, params }) + "\n");
        });
      }
      async init() {
        const caps = await this.request("initialize", {
          protocolVersion: PROTOCOL_VERSION,
          capabilities: {},
          clientInfo: { name: "research-engine", version: "0.15" }
        }, HANDSHAKE_TIMEOUT_MS);
        this.notify("notifications/initialized");
        return caps;
      }
      kill() {
        try {
          this.child.kill("SIGKILL");
        } catch {
        }
      }
    };
  }
});

// src/routes/voice.ts
var voice_exports = {};
__export(voice_exports, {
  voiceRoutes: () => voiceRoutes
});
import { Hono as Hono19 } from "hono";
function pick(query, name) {
  const v = query[name];
  return v && v.length ? v : null;
}
var voiceRoutes, DEFAULT_TIMEOUT2;
var init_voice = __esm({
  "src/routes/voice.ts"() {
    "use strict";
    voiceRoutes = new Hono19();
    DEFAULT_TIMEOUT2 = 12e4;
    voiceRoutes.post("/voice/transcribe", async (c) => {
      const mode = c.req.query("mode") ?? "provider";
      const language = c.req.query("language") ?? "";
      const audio = await c.req.arrayBuffer();
      if (!audio.byteLength) return c.json({ error: "No audio in the request body" }, 400);
      const timeout = Number(c.req.query("timeout") ?? 0);
      const ms = Number.isFinite(timeout) && timeout >= 3e3 ? Math.min(timeout, 6e5) : DEFAULT_TIMEOUT2;
      if (mode === "local") {
        const base2 = (pick(c.req.query(), "localUrl") ?? process.env.WHISPER_URL ?? "http://127.0.0.1:8080").replace(/\/$/, "");
        const form2 = new FormData();
        form2.append("file", new Blob([audio], { type: c.req.header("content-type") ?? "audio/webm" }), "dictation.webm");
        form2.append("response_format", "json");
        form2.append("temperature", "0.0");
        if (language) form2.append("language", language);
        try {
          const res = await fetch(`${base2}/inference`, { method: "POST", body: form2, signal: AbortSignal.timeout(ms) });
          if (!res.ok) {
            const text3 = await res.text().catch(() => "");
            return c.json({ error: `Local whisper responded ${res.status}${text3 ? `: ${text3.slice(0, 200)}` : ""}` }, 502);
          }
          const json = await res.json().catch(() => ({}));
          const text2 = String(json?.text ?? json?.transcription ?? "").trim();
          return c.json({ text: text2, engine: `local:${base2}` });
        } catch (e) {
          return c.json({ error: `Could not reach the local whisper server at ${base2} (${e?.message ?? e})` }, 502);
        }
      }
      const key = pick(c.req.query(), "key") ?? c.req.header("x-re-provider-key") ?? "";
      const base = (pick(c.req.query(), "base") ?? "https://api.openai.com/v1").replace(/\/$/, "");
      const model = pick(c.req.query(), "model") ?? "whisper-1";
      if (!key) return c.json({ error: "No key for this provider \u2014 add one in Settings \u2192 Providers" }, 400);
      const form = new FormData();
      form.append("file", new Blob([audio], { type: c.req.header("content-type") ?? "audio/webm" }), "dictation.webm");
      form.append("model", model);
      if (language) form.append("language", language);
      try {
        const res = await fetch(`${base}/audio/transcriptions`, {
          method: "POST",
          headers: { authorization: `Bearer ${key}` },
          body: form,
          signal: AbortSignal.timeout(ms)
        });
        if (!res.ok) {
          const text3 = await res.text().catch(() => "");
          return c.json({ error: `${model} responded ${res.status}${text3 ? `: ${text3.slice(0, 240)}` : ""}` }, 502);
        }
        const json = await res.json().catch(() => ({}));
        const text2 = String(json?.text ?? json?.transcription ?? "").trim();
        return c.json({ text: text2, engine: `${model}` });
      } catch (e) {
        return c.json({ error: `Transcription failed: ${e?.message ?? e}` }, 502);
      }
    });
    voiceRoutes.get("/voice/status", async (c) => {
      const localUrl = (pick(c.req.query(), "localUrl") ?? process.env.WHISPER_URL ?? "").replace(/\/$/, "");
      let local = false;
      if (localUrl) {
        try {
          const res = await fetch(localUrl, { signal: AbortSignal.timeout(2500) });
          local = res.ok || res.status === 404;
        } catch {
          local = false;
        }
      }
      return c.json({ local, localUrl: localUrl || null });
    });
  }
});

// src/index.ts
init_runtime();
import { serve } from "@hono/node-server";
import { Hono as Hono20 } from "hono";
import { cors } from "hono/cors";
import { logger } from "hono/logger";

// src/static.ts
import { createReadStream, existsSync as existsSync3, readFileSync as readFileSync3, statSync as statSync3 } from "node:fs";
import { Readable } from "node:stream";
import { extname, join as join3, normalize } from "node:path";
import { brotliCompressSync, gzipSync } from "node:zlib";
import { createHash } from "node:crypto";
var MIME = {
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".mjs": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".json": "application/json",
  ".svg": "image/svg+xml",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".webp": "image/webp",
  ".ico": "image/x-icon",
  ".woff": "font/woff",
  ".woff2": "font/woff2",
  ".ttf": "font/ttf",
  ".map": "application/json",
  ".txt": "text/plain; charset=utf-8",
  ".webmanifest": "application/manifest+json"
};
var COMPRESSIBLE = /* @__PURE__ */ new Set([".html", ".js", ".mjs", ".css", ".json", ".svg", ".txt", ".webmanifest", ".map"]);
var cache2 = /* @__PURE__ */ new Map();
function load(target) {
  const st = statSync3(target);
  const hit = cache2.get(target);
  if (hit && hit.mtimeMs === st.mtimeMs && hit.size === st.size) return hit;
  const body = readFileSync3(target);
  const etag = `"${createHash("sha1").update(body).digest("base64url").slice(0, 20)}"`;
  const ext = extname(target).toLowerCase();
  const enc = {};
  if (COMPRESSIBLE.has(ext) && body.length > 1024) {
    enc.br = brotliCompressSync(body, {
      params: { 1: 5, 2: 20 }
      // quality 5, window 20 — fast enough to do inline
    });
    enc.gzip = gzipSync(body, { level: 6 });
  }
  const entry = { body, etag, mtimeMs: st.mtimeMs, size: body.length, enc };
  cache2.set(target, entry);
  return entry;
}
function staticHandler(root) {
  const indexHtml = join3(root, "index.html");
  return async (c) => {
    const url = new URL(c.req.url);
    let rel = decodeURIComponent(url.pathname).replace(/^\/+/, "");
    rel = normalize(rel).replace(/^(\.\.[/\\])+/, "");
    const file2 = rel ? join3(root, rel) : indexHtml;
    const target = existsSync3(file2) && statSync3(file2).isFile() ? file2 : indexHtml;
    if (!existsSync3(target)) return c.notFound();
    const isIndex = target === indexHtml;
    const hit = load(target);
    const headers = {
      "content-type": MIME[extname(target).toLowerCase()] ?? "application/octet-stream",
      etag: hit.etag,
      "last-modified": new Date(hit.mtimeMs).toUTCString(),
      vary: "accept-encoding"
    };
    if (isIndex) headers["cache-control"] = "no-cache";
    else if (rel.startsWith("assets/")) headers["cache-control"] = "public, max-age=31536000, immutable";
    else headers["cache-control"] = "public, max-age=3600";
    const inm = c.req.header("if-none-match");
    if (inm && inm.split(",").some((t) => t.trim() === hit.etag)) {
      return new Response(null, { status: 304, headers });
    }
    const accept = c.req.header("accept-encoding") ?? "";
    const pick2 = /\bbr\b/.test(accept) && hit.enc.br ? "br" : /\bgzip\b/.test(accept) && hit.enc.gzip ? "gzip" : "";
    if (pick2) {
      headers["content-encoding"] = pick2;
      headers["content-length"] = String(hit.enc[pick2].length);
      return new Response(new Uint8Array(hit.enc[pick2]), { status: 200, headers });
    }
    headers["content-length"] = String(hit.body.length);
    if (target === indexHtml || hit.body.length < 64 * 1024) {
      return new Response(new Uint8Array(hit.body), { status: 200, headers });
    }
    const rs = createReadStream(target);
    delete headers["content-length"];
    return new Response(Readable.toWeb(rs), { status: 200, headers });
  };
}

// src/index.ts
init_build_info();

// src/routes/update.ts
import { Hono } from "hono";
init_build_info();
import { homedir as homedir2 } from "node:os";
import { join as join5 } from "node:path";

// src/update/version.ts
function parseVersion(input) {
  const raw = String(input ?? "").trim().replace(/^v/i, "");
  const m = /^(\d+)\.(\d+)\.(\d+)(?:-([0-9A-Za-z.-]+))?(?:\+[0-9A-Za-z.-]+)?$/.exec(raw);
  if (!m) return null;
  const prerelease = (m[4] ?? "").split(".").filter((s) => s.length > 0).map((s) => /^\d+$/.test(s) ? Number(s) : s);
  return { major: Number(m[1]), minor: Number(m[2]), patch: Number(m[3]), prerelease, raw };
}
function compareVersions(a, b) {
  const pa = parseVersion(a);
  const pb = parseVersion(b);
  if (!pa && !pb) return 0;
  if (!pa) return -1;
  if (!pb) return 1;
  for (const key of ["major", "minor", "patch"]) {
    if (pa[key] !== pb[key]) return pa[key] < pb[key] ? -1 : 1;
  }
  if (!pa.prerelease.length && !pb.prerelease.length) return 0;
  if (!pa.prerelease.length) return 1;
  if (!pb.prerelease.length) return -1;
  const n = Math.max(pa.prerelease.length, pb.prerelease.length);
  for (let i = 0; i < n; i++) {
    const x = pa.prerelease[i];
    const y = pb.prerelease[i];
    if (x === void 0) return -1;
    if (y === void 0) return 1;
    if (x === y) continue;
    const xn = typeof x === "number";
    const yn = typeof y === "number";
    if (xn && yn) return x < y ? -1 : 1;
    if (xn) return -1;
    if (yn) return 1;
    return String(x) < String(y) ? -1 : 1;
  }
  return 0;
}
function isNewer(candidate, current) {
  return compareVersions(candidate, current) > 0;
}
function toReleaseInfo(r) {
  const tag = String(r.tag_name ?? "");
  const version = tag.replace(/^v/i, "");
  if (!parseVersion(version)) return null;
  return {
    version,
    tag,
    name: String(r.name ?? tag),
    notes: String(r.body ?? ""),
    publishedAt: String(r.published_at ?? ""),
    url: String(r.html_url ?? ""),
    prerelease: !!r.prerelease,
    assets: (r.assets ?? []).map((a) => ({
      name: String(a.name ?? ""),
      // The browser URL is the one that works without a token; the API URL is
      // the only one that works *with* one on a private repository. Keep both.
      url: String(a.browser_download_url ?? a.url ?? ""),
      id: typeof a.id === "number" ? a.id : void 0,
      size: Number(a.size ?? 0)
    }))
  };
}
function pickLatest(releases, channel = "beta") {
  const parsed = releases.filter((r) => !r.draft).map(toReleaseInfo).filter((r) => !!r).filter((r) => channel === "stable" ? !r.prerelease : true);
  if (!parsed.length) return null;
  return parsed.reduce((best, cur) => compareVersions(cur.version, best.version) > 0 ? cur : best);
}
function archiveNameFor(version, platform) {
  const ext = platform.startsWith("win") ? "zip" : "tar.gz";
  return `research-engine-${version}-${platform}.${ext}`;
}
function platformKey(platform = process.platform, arch = process.arch) {
  const os = platform === "win32" ? "win" : platform === "darwin" ? "darwin" : "linux";
  const cpu = arch === "arm64" ? "arm64" : "x64";
  return `${os}-${cpu}`;
}
function parseSha256Sums(text2) {
  const out = {};
  for (const line of String(text2 ?? "").split(/\r?\n/)) {
    const m = /^([0-9a-fA-F]{64})\s+\*?(.+?)\s*$/.exec(line);
    if (m) out[m[2]] = m[1].toLowerCase();
  }
  return out;
}

// src/update/service.ts
import { createHash as createHash2 } from "node:crypto";
import { spawn } from "node:child_process";
import { appendFileSync, cpSync, existsSync as existsSync5, mkdirSync as mkdirSync3, readFileSync as readFileSync4, renameSync, rmSync as rmSync2, statSync as statSync4, writeFileSync as writeFileSync3 } from "node:fs";
import { dirname as dirname3, isAbsolute, join as join4, relative as relative2, resolve as resolve4 } from "node:path";

// src/update/archive.ts
import { chmodSync, mkdirSync as mkdirSync2, writeFileSync as writeFileSync2, rmSync, existsSync as existsSync4 } from "node:fs";
import { dirname as dirname2, relative, resolve as resolve3, sep } from "node:path";
import { gunzipSync, inflateRawSync } from "node:zlib";
var DEFAULT_MAX_FILE = 256 * 1024 * 1024;
var DEFAULT_MAX_TOTAL = 1024 * 1024 * 1024;
function safeEntryPath(dest, entry) {
  if (typeof entry !== "string" || !entry) return null;
  if (entry.includes("\0")) return null;
  const normalized = entry.replace(/\\/g, "/");
  if (normalized.startsWith("/")) return null;
  if (/^[a-zA-Z]:/.test(normalized)) return null;
  const segments = normalized.split("/").filter((s) => s.length && s !== ".");
  if (!segments.length) return null;
  if (segments.some((s) => s === ".." || s.includes("://"))) return null;
  const full = resolve3(dest, ...segments);
  const rel = relative(resolve3(dest), full);
  if (!rel || rel.startsWith("..") || rel.includes(`..${sep}`)) return null;
  return full;
}
function stripSegments(entry, n) {
  const parts = entry.split("/").filter(Boolean);
  if (parts.length <= n) return null;
  return parts.slice(n).join("/");
}
function assertBudget(totalSoFar, fileSize, opts) {
  const maxFile = opts.maxFileBytes ?? DEFAULT_MAX_FILE;
  const maxTotal = opts.maxTotalBytes ?? DEFAULT_MAX_TOTAL;
  if (fileSize > maxFile) throw new Error(`archive entry is ${fileSize} bytes \u2014 larger than the ${maxFile} byte limit`);
  if (totalSoFar + fileSize > maxTotal) throw new Error(`archive expands past the ${maxTotal} byte limit \u2014 refusing to unpack it`);
}
function writeEntry(dest, rawEntry, data, mode, opts, state) {
  const entry = stripSegments(rawEntry, Math.max(0, opts.strip ?? 0));
  if (!entry) return;
  assertBudget(state.bytes, data.length, opts);
  const target = safeEntryPath(dest, entry);
  if (!target) throw new Error(`unsafe path in archive: ${rawEntry}`);
  mkdirSync2(dirname2(target), { recursive: true });
  writeFileSync2(target, data);
  if (mode !== void 0 && (mode & 73) !== 0) {
    try {
      chmodSync(target, mode & 511);
    } catch {
    }
  }
  state.bytes += data.length;
  state.files.push(entry);
}
function mkdirEntry(dest, rawEntry, opts) {
  const entry = stripSegments(rawEntry, Math.max(0, opts.strip ?? 0));
  if (!entry) return;
  const dir = safeEntryPath(dest, entry);
  if (dir) mkdirSync2(dir, { recursive: true });
}
var oct = (buf, start, len) => {
  if (buf[start] & 128) {
    let n = 0;
    for (let i = start; i < start + len; i++) n = n * 256 + (i === start ? buf[i] & 127 : buf[i]);
    return n;
  }
  const s = buf.subarray(start, start + len).toString("latin1").replace(/\0.*$/, "").trim();
  if (!s) return 0;
  const v = parseInt(s, 8);
  return Number.isFinite(v) ? v : 0;
};
var str = (buf, start, len) => buf.subarray(start, start + len).toString("utf8").replace(/\0.*$/, "").trim();
function tarChecksumOk(header) {
  const stored = oct(header, 148, 8);
  if (!stored) return true;
  let sum = 0;
  for (let i = 0; i < 512; i++) sum += i >= 148 && i < 156 ? 32 : header[i];
  return sum === stored;
}
function extractTar(buf, dest, opts = {}, state = { bytes: 0, files: [] }) {
  let offset = 0;
  let longName = null;
  let paxPath = null;
  let paxBytes = 0;
  while (offset + 512 <= buf.length) {
    const header = buf.subarray(offset, offset + 512);
    if (header.every((b) => b === 0)) break;
    if (!tarChecksumOk(header)) throw new Error("tar header checksum mismatch \u2014 the archive is corrupt");
    const size = oct(header, 124, 12);
    const type = String.fromCharCode(header[156] || 48);
    const prefix = str(header, 345, 155);
    const plain = prefix ? `${prefix}/${str(header, 0, 100)}` : str(header, 0, 100);
    const name = paxPath ?? longName ?? plain;
    longName = null;
    paxPath = null;
    const dataStart = offset + 512;
    if (dataStart + size > buf.length + 512) throw new Error("tar entry runs past the end of the archive");
    const data = buf.subarray(dataStart, Math.min(dataStart + size, buf.length));
    offset = dataStart + Math.ceil(size / 512) * 512;
    if (type === "L") {
      longName = data.toString("utf8").replace(/\0.*$/, "");
      continue;
    }
    if (type === "K") continue;
    if (type === "x" || type === "g") {
      paxBytes += data.length;
      assertBudget(paxBytes, data.length, opts);
      for (const rec of data.toString("utf8").split("\n")) {
        const m = /^\d+ path=(.*)$/.exec(rec);
        if (m) paxPath = m[1];
      }
      continue;
    }
    if (type === "2" || type === "1") throw new Error(`archive contains a link (${name}) \u2014 refusing to unpack it`);
    if (type === "5" || !size && name.endsWith("/")) {
      mkdirEntry(dest, name, opts);
      continue;
    }
    if (type !== "0" && type !== "\0" && type !== "7") continue;
    writeEntry(dest, name, Buffer.from(data), oct(header, 100, 8), opts, state);
  }
  return { files: state.files, bytes: state.bytes, format: "tar.gz" };
}
var u16 = (b, o) => b.readUInt16LE(o);
var u32 = (b, o) => b.readUInt32LE(o);
function extractZip(buf, dest, opts = {}, state = { bytes: 0, files: [] }) {
  const EOCD = 101010256;
  let eocd = -1;
  for (let i = buf.length - 22; i >= 0 && i > buf.length - 22 - 65536; i--) {
    if (u32(buf, i) === EOCD) {
      eocd = i;
      break;
    }
  }
  if (eocd < 0) throw new Error("not a zip archive (no end-of-central-directory record)");
  const count = u16(buf, eocd + 10);
  const cdOffset = u32(buf, eocd + 16);
  if (count === 65535 || cdOffset === 4294967295) throw new Error("zip64 archives are not supported by the updater");
  let p = cdOffset;
  for (let i = 0; i < count; i++) {
    if (u32(buf, p) !== 33639248) throw new Error("zip central directory is corrupt");
    const flags = u16(buf, p + 8);
    const method = u16(buf, p + 10);
    const compSize = u32(buf, p + 20);
    const uncompSize = u32(buf, p + 24);
    const nameLen = u16(buf, p + 28);
    const extraLen = u16(buf, p + 30);
    const commentLen = u16(buf, p + 32);
    const localOffset = u32(buf, p + 42);
    const name = buf.subarray(p + 46, p + 46 + nameLen).toString("utf8");
    p += 46 + nameLen + extraLen + commentLen;
    if (flags & 1) throw new Error(`archive entry ${name} is encrypted`);
    if (uncompSize === 4294967295 || compSize === 4294967295) throw new Error("zip64 archives are not supported by the updater");
    if (name.endsWith("/")) {
      mkdirEntry(dest, name, opts);
      continue;
    }
    if (u32(buf, localOffset) !== 67324752) throw new Error(`zip entry ${name} has no local header`);
    const dataStart = localOffset + 30 + u16(buf, localOffset + 26) + u16(buf, localOffset + 28);
    const raw = buf.subarray(dataStart, dataStart + compSize);
    let data;
    if (method === 0) data = Buffer.from(raw);
    else if (method === 8) {
      data = inflateRawSync(raw, { maxOutputLength: Math.min(uncompSize + 1024, opts.maxFileBytes ?? DEFAULT_MAX_FILE) });
    } else throw new Error(`zip entry ${name} uses unsupported compression (method ${method})`);
    if (uncompSize && data.length !== uncompSize) throw new Error(`zip entry ${name} is truncated (${data.length} of ${uncompSize} bytes)`);
    writeEntry(dest, name, data, void 0, opts, state);
  }
  return { files: state.files, bytes: state.bytes, format: "zip" };
}
function sniffFormat(buf) {
  if (buf.length > 4 && buf[0] === 31 && buf[1] === 139) return "tar.gz";
  if (buf.length > 4 && buf[0] === 80 && buf[1] === 75 && (buf[2] === 3 || buf[2] === 5 || buf[2] === 7)) return "zip";
  if (buf.length > 512 && str(buf, 257, 6).startsWith("ustar")) return "tar";
  return null;
}
function extractArchive(buffer, dest, opts = {}) {
  const format = sniffFormat(buffer);
  if (!format) throw new Error("unrecognised archive format \u2014 expected a .tar.gz or .zip release");
  mkdirSync2(dest, { recursive: true });
  const state = { bytes: 0, files: [] };
  if (format === "zip") return extractZip(buffer, dest, opts, state);
  const raw = format === "tar.gz" ? gunzipSync(buffer) : buffer;
  const out = extractTar(raw, dest, opts, state);
  return { ...out, format: "tar.gz" };
}
function rmrf(path) {
  if (!existsSync4(path)) return;
  rmSync(path, { recursive: true, force: true, maxRetries: 3 });
}

// src/update/service.ts
var REPO = "timetorepo/researchengine";
var UPDATE_DIR = ".update";
var EXIT_RESTART = 75;
var HEALTHY_AFTER_MS = 2e4;
var MAX_BOOT_ATTEMPTS = 1;
function guard(appRoot2, dataDir, target, what = "path") {
  const app = resolve4(appRoot2);
  const t = resolve4(target);
  const relApp = relative2(app, t);
  if (!relApp || relApp.startsWith("..") || isAbsolute(relApp)) {
    throw new Error(`refusing to touch ${what} outside the app folder: ${t}`);
  }
  if (dataDir) {
    const relData = relative2(resolve4(dataDir), t);
    if (!relData.startsWith("..") && !isAbsolute(relData)) {
      throw new Error(`refusing to touch ${what} inside the data directory: ${t}`);
    }
  }
  return t;
}
var updateDir = (deps) => join4(resolve4(deps.appRoot), UPDATE_DIR);
var stageDir = (deps) => join4(updateDir(deps), "stage");
var backupDir = (deps) => join4(updateDir(deps), "backup");
var pendingFile = (deps) => join4(updateDir(deps), "pending.json");
var resultFile = (deps) => join4(updateDir(deps), "last-update.json");
function readPending(deps) {
  try {
    if (!deps.appRoot) return null;
    const file2 = pendingFile(deps);
    if (!existsSync5(file2)) return null;
    return JSON.parse(readFileSync4(file2, "utf8"));
  } catch {
    return null;
  }
}
function writePending(deps, pending) {
  const file2 = guard(deps.appRoot, deps.dataDir, pendingFile(deps), "the update marker");
  mkdirSync3(dirname3(file2), { recursive: true });
  writeFileSync3(file2, JSON.stringify(pending, null, 2));
}
function clearPending(deps) {
  if (!deps.appRoot) return;
  const file2 = guard(deps.appRoot, deps.dataDir, pendingFile(deps), "the update marker");
  rmrf(file2);
}
function readOutcome(deps) {
  try {
    if (!deps.appRoot) return null;
    const file2 = resultFile(deps);
    if (!existsSync5(file2)) return null;
    return JSON.parse(readFileSync4(file2, "utf8"));
  } catch {
    return null;
  }
}
function writeOutcome(deps, outcome) {
  if (!deps.appRoot) return;
  const file2 = guard(deps.appRoot, deps.dataDir, resultFile(deps), "the update result file");
  mkdirSync3(dirname3(file2), { recursive: true });
  writeFileSync3(file2, JSON.stringify(outcome, null, 2));
}
function clearOutcome(deps) {
  if (!deps.appRoot) return;
  const file2 = guard(deps.appRoot, deps.dataDir, resultFile(deps), "the update result file");
  rmrf(file2);
}
var apiBase = (deps) => deps.apiBase ?? "https://api.github.com";
var rawBase = (deps) => deps.rawBase ?? "https://raw.githubusercontent.com";
var repoOf = (deps) => deps.repo?.trim() || REPO;
var GITHUB_HOSTS = /* @__PURE__ */ new Set(["api.github.com", "raw.githubusercontent.com", "github.com", "objects.githubusercontent.com", "codeload.github.com"]);
function authFor(deps, url) {
  if (!deps.token) return {};
  try {
    const host2 = new URL(url).hostname;
    const base = new URL(apiBase(deps)).hostname;
    return GITHUB_HOSTS.has(host2) || host2 === base ? { authorization: `Bearer ${deps.token}` } : {};
  } catch {
    return {};
  }
}
function fileUrls(deps, version, name) {
  return [
    `${rawBase(deps)}/${repoOf(deps)}/v${version}/downloads/${name}`,
    `${apiBase(deps)}/repos/${repoOf(deps)}/contents/downloads/${name}?ref=v${version}`
  ];
}
function requestFor(deps, url) {
  const isApi = url.includes("/contents/");
  return {
    url,
    init: {
      headers: {
        accept: isApi ? "application/vnd.github.raw" : "application/octet-stream",
        "user-agent": "research-engine-updater",
        ...authFor(deps, url)
      }
    }
  };
}
async function getJson(deps, url) {
  const doFetch = deps.fetchImpl ?? fetch;
  const res = await doFetch(url, {
    headers: { accept: "application/vnd.github+json", "user-agent": "research-engine-updater", ...authFor(deps, url) }
  });
  if (!res.ok) {
    if (res.status === 404 && deps.token === void 0) throw new Error("GitHub replied 404 \u2014 if this repository is private, add a read-only token in Settings \u2192 Updates");
    if (res.status === 401 || res.status === 403) throw new Error(`GitHub refused the token (${res.status}) \u2014 it needs read-only repository access`);
    throw new Error(`GitHub replied ${res.status} for ${url}`);
  }
  return await res.json();
}
function manifestReleases(json, fallbackUrl = "") {
  const raw = Array.isArray(json) ? json : Array.isArray(json?.releases) ? json.releases : [json];
  return raw.filter(Boolean).map((r) => {
    const version = String(r.version ?? r.tag_name ?? r.tag ?? "").replace(/^v/, "");
    const assets = Array.isArray(r.assets) ? r.assets : [];
    if (r.archive) {
      assets.push({
        name: String(r.archive).split("/").pop() ?? archiveNameFor(version, "linux-x64"),
        browser_download_url: String(r.archive),
        size: Number(r.size ?? 0)
      });
    }
    return {
      tag_name: r.tag_name ?? `v${version}`,
      name: r.name ?? `v${version}`,
      body: r.body ?? r.notes ?? "",
      published_at: r.published_at ?? r.publishedAt ?? "",
      html_url: r.html_url ?? r.url ?? fallbackUrl,
      prerelease: r.prerelease ?? true,
      draft: r.draft ?? false,
      assets,
      sums: r.sums ?? r.sumsUrl ?? null
    };
  });
}
async function latestRelease(deps) {
  if (deps.manifestUrl) {
    const json = await getJson(deps, deps.manifestUrl);
    const list2 = manifestReleases(json, deps.manifestUrl);
    const latest = pickLatest(list2, "beta");
    if (latest && !latest.sums) latest.sums = findSumsIn(list2);
    return latest;
  }
  const list = await getJson(deps, `${apiBase(deps)}/repos/${repoOf(deps)}/releases?per_page=30`);
  if (!Array.isArray(list)) throw new Error("unexpected release list from GitHub");
  return pickLatest(list, "beta");
}
function findSumsIn(list) {
  for (const r of list) if (r.sums) return r.sums;
  return null;
}
function hashUrlsFor(deps, version, release) {
  if (release?.sums) return [release.sums];
  return fileUrls(deps, version, "SHA256SUMS");
}
function assetUrlsFor(deps, asset) {
  const urls = [];
  if (typeof asset.id === "number") urls.push(`${apiBase(deps)}/repos/${repoOf(deps)}/releases/assets/${asset.id}`);
  if (asset.url) urls.push(asset.url);
  return urls;
}
function archiveUrlsFor(deps, version, release, asset) {
  if (asset?.urls?.length) return asset.urls;
  const name = asset?.name || archiveNameFor(version, deps.platform);
  const manifestOwned = !!deps.manifestUrl;
  const committed = manifestOwned ? [] : fileUrls(deps, version, name);
  const uploaded = asset ? assetUrlsFor(deps, asset) : [];
  const all = [...committed, ...uploaded];
  return all.filter((u, i) => !!u && all.indexOf(u) === i);
}
async function checkForUpdate(deps) {
  const latest = await latestRelease(deps);
  const name = latest ? archiveNameFor(latest.version, deps.platform) : "";
  const asset = latest?.assets.find((a) => a.name === name) ?? null;
  const portable = deps.kind === "portable" && !!deps.appRoot;
  return {
    current: deps.currentVersion,
    latest: latest?.version ?? null,
    available: !!latest && isNewer(latest.version, deps.currentVersion),
    behind: latest ? isNewer(latest.version, deps.currentVersion) ? 1 : 0 : 0,
    notes: latest?.notes ?? "",
    url: latest?.url ?? "",
    publishedAt: latest?.publishedAt ?? "",
    // The portable archive is committed inside the tagged tree, so the download
    // and its checksum come from the same immutable release.
    asset: latest && portable ? { name, urls: archiveUrlsFor(deps, latest.version, latest, asset), size: asset?.size ?? 0 } : asset ? { name: asset.name, urls: assetUrlsFor(deps, asset), size: asset.size } : null,
    hashUrls: latest ? hashUrlsFor(deps, latest.version, latest) : [],
    kind: deps.kind,
    canSelfUpdate: portable,
    reason: portable ? void 0 : deps.kind === "checkout" ? "this is a source checkout \u2014 update with git pull && npm run build" : deps.kind === "desktop" ? "the desktop app updates through its installer \u2014 Research Engine will fetch it for you" : "this build cannot update itself in place"
  };
}
function partialPathFor(deps, name) {
  const dir = join4(deps.dataDir, "updates", "partial");
  mkdirSync3(dir, { recursive: true });
  return join4(dir, `${name.replace(/[^\w.-]+/g, "_")}.part`);
}
function clearPartial(deps, name) {
  try {
    rmSync2(partialPathFor(deps, name), { force: true });
  } catch {
  }
}
async function downloadResumable(deps, url, onProgress, maxBytes = 200 * 1024 * 1024, init, partialName) {
  const doFetch = deps.fetchImpl ?? fetch;
  const path = partialName ? partialPathFor(deps, partialName) : null;
  let have = 0;
  if (path) {
    try {
      have = existsSync5(path) ? statSync4(path).size : 0;
      if (have > maxBytes) {
        rmSync2(path, { force: true });
        have = 0;
      }
    } catch {
      have = 0;
    }
  }
  const headers = { accept: "application/octet-stream", "user-agent": "research-engine-updater", ...init?.headers };
  if (have > 0) headers.range = `bytes=${have}-`;
  let res = await doFetch(url, { ...init ?? {}, headers });
  if (res.status === 416 && path && have > 0) {
    const buffer2 = readFileSync4(path);
    return { buffer: buffer2, sha256: createHash2("sha256").update(buffer2).digest("hex"), resumed: true };
  }
  if (!res.ok) throw new Error(`download failed: ${res.status} ${res.statusText}`);
  const partial = res.status === 206;
  if (!partial && have > 0 && path) {
    try {
      writeFileSync3(path, "");
    } catch {
    }
    have = 0;
  }
  const rangeTotal = (() => {
    const cr = res.headers.get("content-range");
    const m = cr?.match(/\/(\d+)\s*$/);
    return m ? Number(m[1]) : 0;
  })();
  const len = Number(res.headers.get("content-length") ?? 0);
  const total = rangeTotal || (len ? len + have : 0);
  let received = have;
  const chunks = [];
  onProgress(received, total);
  if (res.body) {
    const reader = res.body.getReader();
    for (; ; ) {
      const { done, value } = await reader.read();
      if (done) break;
      const buf = Buffer.from(value);
      received += buf.length;
      if (received > maxBytes) throw new Error(`download exceeded ${maxBytes} bytes \u2014 refusing it`);
      if (path) appendFileSync(path, buf);
      else chunks.push(buf);
      onProgress(received, total);
    }
  } else {
    const buf = Buffer.from(await res.arrayBuffer());
    received += buf.length;
    if (path) appendFileSync(path, buf);
    else chunks.push(buf);
    onProgress(received, total);
  }
  const buffer = path && existsSync5(path) ? readFileSync4(path) : Buffer.concat(chunks);
  if (buffer.length > maxBytes) throw new Error(`download exceeded ${maxBytes} bytes \u2014 refusing it`);
  return { buffer, sha256: createHash2("sha256").update(buffer).digest("hex"), resumed: have > 0 };
}
var RESUME_ATTEMPTS = Number(process.env.RE_UPDATE_ATTEMPTS ?? 4);
async function downloadAnyResumable(deps, urls, onProgress, maxBytes = 200 * 1024 * 1024, name = "update") {
  const errors = [];
  for (const url of urls) {
    const req = requestFor(deps, url);
    let attempt = 0;
    while (attempt < RESUME_ATTEMPTS) {
      attempt++;
      try {
        const out = await downloadResumable(deps, req.url, (r, t) => onProgress(r, t, attempt), maxBytes, req.init, name);
        clearPartial(deps, name);
        return { ...out, url, attempts: attempt };
      } catch (e) {
        const msg = `${new URL(url).hostname}: ${e?.message ?? e}`;
        if (attempt >= RESUME_ATTEMPTS || attempt >= urls.length * RESUME_ATTEMPTS) {
          errors.push(msg);
          break;
        }
        errors.push(msg);
        await new Promise((r) => setTimeout(r, 600 * attempt));
      }
    }
  }
  throw new Error(`could not download from any source \u2014 ${errors.slice(-4).join("; ")}`);
}
async function fetchTextAny(deps, urls) {
  const doFetch = deps.fetchImpl ?? fetch;
  const errors = [];
  for (const url of urls) {
    try {
      const req = requestFor(deps, url);
      const res = await doFetch(req.url, req.init);
      if (!res.ok) {
        errors.push(`${new URL(url).hostname}: HTTP ${res.status}`);
        continue;
      }
      return { text: await res.text(), url };
    } catch (e) {
      errors.push(`${new URL(url).hostname}: ${e?.message ?? e}`);
    }
  }
  throw new Error(`could not read the release checksum \u2014 ${errors.join("; ")}`);
}
function expectedHash(sumsText, fileName) {
  const sums = parseSha256Sums(sumsText);
  return sums[fileName] ?? null;
}
function validateStage(root, version) {
  const entry = join4(root, "server", "index.js");
  const pkgFile = join4(root, "server", "package.json");
  const index = join4(root, "frontend-dist", "index.html");
  if (!existsSync5(entry)) return { ok: false, reason: "the archive has no server/index.js" };
  if (!existsSync5(index)) return { ok: false, reason: "the archive has no frontend-dist/index.html" };
  if (!existsSync5(pkgFile)) return { ok: false, reason: "the archive has no server/package.json" };
  try {
    const pkg = JSON.parse(readFileSync4(pkgFile, "utf8"));
    if (pkg.name !== "research-engine-server") return { ok: false, reason: `the archive's server package is "${pkg.name ?? "unnamed"}", not a Research Engine server` };
    if (pkg.version && pkg.version !== version) return { ok: false, reason: `the archive says it is ${pkg.version} but this update is for ${version}` };
    return { ok: true, version: pkg.version ?? version };
  } catch (e) {
    return { ok: false, reason: `could not read the archive's server/package.json (${e?.message ?? e})` };
  }
}
var SWAPPED = ["server", "frontend-dist", "bin"];
function moveDir(from, to) {
  mkdirSync3(dirname3(to), { recursive: true });
  try {
    renameSync(from, to);
  } catch {
    cpSync(from, to, { recursive: true });
    rmrf(from);
  }
}
function swapIn(deps, stage, version, fromVersion) {
  const app = resolve4(deps.appRoot);
  const backup = guard(app, deps.dataDir, backupDir(deps), "the backup folder");
  rmrf(backup);
  mkdirSync3(backup, { recursive: true });
  const movedOut = [];
  try {
    for (const name of SWAPPED) {
      const live = guard(app, deps.dataDir, join4(app, name), `the installed ${name}`);
      const staged = guard(app, deps.dataDir, join4(stage, name), `the staged ${name}`);
      if (!existsSync5(staged)) continue;
      if (existsSync5(live)) moveDir(live, join4(backup, name));
      moveDir(staged, live);
      movedOut.push(name);
    }
  } catch (e) {
    for (const name of movedOut) {
      const live = join4(app, name);
      const saved = join4(backup, name);
      if (existsSync5(saved)) {
        rmrf(live);
        moveDir(saved, live);
      }
    }
    throw e;
  }
  const pending = {
    from: fromVersion,
    to: version,
    at: (deps.now ?? Date.now)(),
    attempts: 0,
    backup,
    platform: deps.platform
  };
  writePending(deps, pending);
  rmrf(stage);
  return pending;
}
function rollback(deps, reason) {
  const pending = readPending(deps);
  if (!deps.appRoot) throw new Error("this build has no app folder to roll back");
  const app = resolve4(deps.appRoot);
  const from = pending?.to ?? deps.currentVersion;
  const to = pending?.from ?? "";
  const backup = guard(app, deps.dataDir, pending?.backup ?? backupDir(deps), "the backup folder");
  if (!existsSync5(backup)) throw new Error("there is no previous version on disk to roll back to");
  for (const name of SWAPPED) {
    const saved = join4(backup, name);
    if (!existsSync5(saved)) continue;
    const live = guard(app, deps.dataDir, join4(app, name), `the installed ${name}`);
    rmrf(live);
    moveDir(saved, live);
  }
  rmrf(backup);
  clearPending(deps);
  const outcome = { ok: false, from, to, at: (deps.now ?? Date.now)(), restored: true, reason };
  writeOutcome(deps, outcome);
  return outcome;
}
function versionFromArchiveName(name) {
  const m = name.match(/research-engine-(\d+\.\d+\.\d+(?:-[0-9A-Za-z.]+)?)-(?:linux|win|mac)/);
  return m ? m[1] : null;
}
async function installFromFile(deps, file2, opts = {}) {
  if (busy) return { ok: false, error: "an update is already running" };
  if (deps.kind !== "portable" || !deps.appRoot) {
    return { ok: false, error: "this build cannot update itself in place" };
  }
  busy = true;
  try {
    const name = file2.name.split(/[/\\]/).pop() ?? file2.name;
    const version = opts.version?.trim() || versionFromArchiveName(name) || "";
    if (!version) {
      const error = `the file name "${name}" does not carry a version \u2014 rename it like research-engine-1.2.3-${deps.platform}.tar.gz, or pass the version`;
      setProgress({ phase: "error", error, message: error });
      return { ok: false, error };
    }
    setProgress({ phase: "verifying", pct: 0, from: deps.currentVersion, to: version, message: `Checking ${name}\u2026` });
    let sumsText = opts.sumsText ?? "";
    if (!sumsText) {
      try {
        sumsText = (await fetchTextAny(deps, hashUrlsFor(deps, version, null))).text;
      } catch (e) {
        const error = `no checksum to check ${name} against \u2014 paste the SHA256SUMS line, or let this app reach the release (${e?.message ?? e})`;
        setProgress({ phase: "error", error, message: error });
        return { ok: false, error };
      }
    }
    const want = expectedHash(sumsText, name);
    if (!want) {
      const error = `${name} is not listed in the checksums you gave \u2014 refusing to install unverified`;
      setProgress({ phase: "error", error, message: error });
      return { ok: false, error };
    }
    const sha256 = createHash2("sha256").update(file2.buffer).digest("hex");
    if (sha256 !== want) {
      const error = `checksum mismatch \u2014 expected ${want.slice(0, 12)}\u2026, got ${sha256.slice(0, 12)}\u2026 (nothing was changed)`;
      setProgress({ phase: "error", error, message: error });
      return { ok: false, error };
    }
    const stage = guard(deps.appRoot, deps.dataDir, stageDir(deps), "the staging folder");
    rmrf(stage);
    mkdirSync3(stage, { recursive: true });
    setProgress({ phase: "extracting", pct: 0, message: "Unpacking\u2026" });
    try {
      extractArchive(file2.buffer, stage, { strip: 1 });
    } catch (e) {
      rmrf(stage);
      const error = `the archive could not be unpacked: ${e?.message ?? e}`;
      setProgress({ phase: "error", error, message: error });
      return { ok: false, error };
    }
    const checkStage = validateStage(stage, version);
    if (!checkStage.ok) {
      rmrf(stage);
      const error = `the archive is not a usable build: ${checkStage.reason}`;
      setProgress({ phase: "error", error, message: error });
      return { ok: false, error };
    }
    setProgress({ phase: "swapping", pct: 100, message: "Putting the new version in place\u2026" });
    const pending = swapIn(deps, stage, version, deps.currentVersion);
    deps.log?.(`updated ${pending.from} \u2192 ${pending.to} from a local archive`);
    setProgress({
      phase: "ready",
      pct: 100,
      message: `Updated to ${version}. Restart to run it \u2014 your library was not touched.`,
      from: pending.from,
      to: pending.to
    });
    return { ok: true, pending };
  } catch (e) {
    const error = String(e?.message ?? e);
    setProgress({ phase: "error", error, message: error });
    return { ok: false, error };
  } finally {
    busy = false;
  }
}
var progress = { phase: "idle", pct: 0, received: 0, total: 0, message: "" };
var busy = false;
var isBusy = () => busy;
function setProgress(patch) {
  progress = { ...progress, ...patch };
}
async function installUpdate(deps, opts = {}) {
  if (busy) return { ok: false, error: "an update is already running" };
  if (deps.kind !== "portable" || !deps.appRoot) {
    return { ok: false, error: new Error("this build cannot update itself in place").message };
  }
  busy = true;
  try {
    setProgress({ phase: "checking", pct: 0, message: "Looking for the newest release\u2026", error: void 0 });
    const check = await checkForUpdate(deps);
    const target = opts.version ?? check.latest;
    if (!target) return { ok: false, error: "no release found" };
    if (!check.available && !opts.version) {
      setProgress({ phase: "ready", pct: 100, message: `${check.current} is already the newest release.` });
      return { ok: false, error: `${check.current} is already the newest release` };
    }
    const name = archiveNameFor(target, deps.platform);
    const urls = check.latest === target && check.asset?.name === name ? check.asset.urls : fileUrls(deps, target, name);
    const hashUrls = check.latest === target && check.hashUrls.length ? check.hashUrls : fileUrls(deps, target, "SHA256SUMS");
    setProgress({ phase: "downloading", from: deps.currentVersion, to: target, pct: 0, received: 0, total: 0, message: `Downloading ${name}\u2026` });
    let sumsText = "";
    try {
      sumsText = (await fetchTextAny(deps, hashUrls)).text;
    } catch (e) {
      const error = `could not read SHA256SUMS for ${target} (${e?.message ?? e}) \u2014 refusing to update unverified`;
      setProgress({ phase: "error", error, message: error });
      return { ok: false, error };
    }
    const want = expectedHash(sumsText, name);
    if (!want) return { ok: false, error: `${name} is not listed in SHA256SUMS for ${target} \u2014 refusing to update unverified` };
    const { buffer, sha256, resumed, attempts } = await downloadAnyResumable(deps, urls, (received, total, attempt) => {
      const pct = total ? Math.min(99, Math.round(received / total * 100)) : Math.min(95, Math.round(received / 2e5));
      const mb = (received / 1e6).toFixed(1);
      setProgress({
        phase: "downloading",
        received,
        total,
        pct,
        message: total ? `${attempt > 1 ? "Continuing" : "Downloading"} ${name} \u2014 ${pct}%${attempt > 1 ? ` (attempt ${attempt})` : ""}` : `${attempt > 1 ? "Continuing" : "Downloading"} ${name} \u2014 ${mb} MB`
      });
    }, 200 * 1024 * 1024, name);
    if (attempts > 1) {
      setProgress({ phase: "downloading", message: `The connection dropped; picked ${name} back up where it stopped.` });
    }
    setProgress({ phase: "verifying", pct: 100, message: "Checking the download against the release checksum\u2026" });
    if (sha256 !== want) {
      clearPartial(deps, name);
      const error = `checksum mismatch \u2014 expected ${want.slice(0, 12)}\u2026, got ${sha256.slice(0, 12)}\u2026 (nothing was changed)`;
      setProgress({ phase: "error", error, message: error });
      return { ok: false, error };
    }
    clearPartial(deps, name);
    const stage = guard(deps.appRoot, deps.dataDir, stageDir(deps), "the staging folder");
    rmrf(stage);
    mkdirSync3(stage, { recursive: true });
    setProgress({ phase: "extracting", pct: 0, message: "Unpacking\u2026" });
    try {
      extractArchive(buffer, stage, { strip: 1 });
    } catch (e) {
      rmrf(stage);
      const error = `the archive could not be unpacked: ${e?.message ?? e}`;
      setProgress({ phase: "error", error, message: error });
      return { ok: false, error };
    }
    const checkStage = validateStage(stage, target);
    if (!checkStage.ok) {
      rmrf(stage);
      const error = `the archive is not a usable build: ${checkStage.reason}`;
      setProgress({ phase: "error", error, message: error });
      return { ok: false, error };
    }
    setProgress({ phase: "swapping", pct: 100, message: "Putting the new version in place\u2026" });
    const pending = swapIn(deps, stage, target, deps.currentVersion);
    deps.log?.(`updated ${pending.from} \u2192 ${pending.to}; previous version kept at ${pending.backup}`);
    setProgress({
      phase: "ready",
      pct: 100,
      message: `Updated to ${target}. Restart to run it \u2014 your library was not touched.`,
      from: pending.from,
      to: pending.to
    });
    return { ok: true, pending };
  } catch (e) {
    const error = String(e?.message ?? e);
    setProgress({ phase: "error", error, message: error });
    return { ok: false, error };
  } finally {
    busy = false;
  }
}
function markHealthy(deps, pending) {
  clearPending(deps);
  writeOutcome(deps, { ok: true, from: pending.from, to: pending.to, at: (deps.now ?? Date.now)() });
  deps.log?.(`update to ${pending.to} is serving \u2014 keeping it`);
}
function noteBootAttempt(deps, pending) {
  const next = { ...pending, attempts: pending.attempts + 1 };
  writePending(deps, next);
  return next;
}
var MAX_INSTALLER_BYTES = 400 * 1024 * 1024;
async function downloadInstaller(deps, downloadDir) {
  try {
    const check = await checkForUpdate(deps);
    if (!check.latest) return { ok: false, error: "no release found" };
    if (!check.available) return { ok: false, error: `${check.current} is already the newest release` };
    const version = check.latest;
    const all = await latestRelease(deps);
    mkdirSync3(downloadDir, { recursive: true });
    const onProgress = (name2) => (received, total) => {
      setProgress({
        phase: "downloading",
        received,
        total,
        to: version,
        pct: total ? Math.round(received / total * 100) : 0,
        message: total ? `Downloading ${name2} \u2014 ${Math.round(received / total * 100)}%` : `Downloading ${name2}\u2026`
      });
    };
    const installer = all?.assets.find((a) => deps.platform.startsWith("win") ? /setup\.exe$/i.test(a.name) : deps.platform.startsWith("darwin") ? /\.dmg$/i.test(a.name) : /\.(AppImage|deb)$/i.test(a.name));
    if (installer) {
      setProgress({ phase: "downloading", message: `Downloading ${installer.name}\u2026`, pct: 0, received: 0, total: installer.size, to: version });
      const { buffer: buffer2, sha256: sha2562 } = await downloadAnyResumable(deps, assetUrlsFor(deps, installer), (r, t) => onProgress(installer.name)(r, t), MAX_INSTALLER_BYTES, installer.name);
      const file3 = join4(downloadDir, installer.name);
      writeFileSync3(file3, buffer2);
      writeFileSync3(`${file3}.sha256`, `${sha2562}  ${installer.name}
`);
      setProgress({ phase: "ready", pct: 100, message: `${installer.name} downloaded \u2014 open it to install.` });
      return { ok: true, file: file3, via: "installer", message: `${installer.name} downloaded \u2014 open it to finish the update. Your library stays where it is.` };
    }
    const name = archiveNameFor(version, deps.platform);
    const asset = all?.assets.find((a) => a.name === name) ?? null;
    const urls = archiveUrlsFor(deps, version, all, asset);
    if (!urls.length) return { ok: false, error: `the ${version} release has nothing to download for ${deps.platform}` };
    let want = null;
    try {
      const sumsText = (await fetchTextAny(deps, hashUrlsFor(deps, version, all))).text;
      want = expectedHash(sumsText, name);
    } catch {
    }
    if (want === null && !asset) return { ok: false, error: `${name} is not part of the ${version} release` };
    setProgress({ phase: "downloading", message: `Downloading ${name}\u2026`, pct: 0, received: 0, total: asset?.size ?? 0, to: version });
    const { buffer, sha256 } = await downloadAnyResumable(deps, urls, (r, t) => onProgress(name)(r, t), MAX_INSTALLER_BYTES, name);
    if (want && sha256 !== want) {
      clearPartial(deps, name);
      const error = `checksum mismatch \u2014 expected ${want.slice(0, 12)}\u2026, got ${sha256.slice(0, 12)}\u2026 (nothing was written)`;
      setProgress({ phase: "error", error, message: error });
      return { ok: false, error };
    }
    const file2 = join4(downloadDir, name);
    writeFileSync3(file2, buffer);
    writeFileSync3(`${file2}.sha256`, `${sha256}  ${name}
`);
    writeFileSync3(join4(downloadDir, `HOW-TO-INSTALL-${version}.txt`), [
      `Research Engine ${version} \u2014 ${name}`,
      "",
      "This release has no platform installer, so you have the portable build.",
      "Unpack it with:",
      "",
      name.endsWith(".zip") ? `  unzip ${name}      (then run research-engine.exe)` : `  tar -xzf ${name}   (then run ./research-engine)`,
      "",
      "Unpack it over the folder you already run Research Engine from \u2014 or into a",
      "new one. Your library, keys and settings live in the data folder",
      "(~/.research-engine) and are never part of the download.",
      "",
      "Check the download yourself with:",
      `  sha256sum -c ${name}.sha256`
    ].join("\n"));
    setProgress({ phase: "ready", pct: 100, message: `${name} downloaded to ${downloadDir}.` });
    return { ok: true, file: file2, via: "archive", message: `${name} downloaded to ${downloadDir} \u2014 unpack it over your install folder to update.` };
  } catch (e) {
    const error = String(e?.message ?? e);
    setProgress({ phase: "error", error, message: error });
    return { ok: false, error };
  }
}
function openWithOs(file2) {
  const cmd = process.platform === "win32" ? ["cmd", ["/c", "start", "", file2]] : process.platform === "darwin" ? ["open", [file2]] : ["xdg-open", [file2]];
  try {
    const child = spawn(cmd[0], cmd[1], { detached: true, stdio: "ignore" });
    child.unref();
    return true;
  } catch {
    return false;
  }
}
function updateStatus(deps) {
  const pending = readPending(deps);
  let backupVersions = [];
  try {
    if (deps.appRoot && existsSync5(backupDir(deps))) {
      backupVersions = ["previous version kept"];
    }
  } catch {
  }
  return {
    kind: deps.kind,
    appRoot: deps.appRoot,
    dataDir: deps.dataDir,
    current: deps.currentVersion,
    platform: deps.platform,
    canSelfUpdate: deps.kind === "portable" && !!deps.appRoot,
    pending,
    backupVersions,
    outcome: readOutcome(deps),
    progress
  };
}

// src/update/boot.ts
import { spawn as spawn2 } from "node:child_process";
function respawn(deps, argv = process.argv.slice(1)) {
  try {
    const child = spawn2(process.execPath, argv, {
      detached: true,
      stdio: "ignore",
      cwd: process.cwd(),
      env: process.env
    });
    child.unref();
    deps.log?.(`restarting: ${process.execPath} ${argv.join(" ")}`);
    return true;
  } catch (e) {
    deps.log?.(`could not restart automatically (${e?.message ?? e}) \u2014 start it again from your launcher`);
    return false;
  }
}
function bootUpdateCheck(deps) {
  const pending = readPending(deps);
  if (!pending) return { pending: null, shouldRollback: false, attempts: 0 };
  if (pending.attempts >= MAX_BOOT_ATTEMPTS) {
    return {
      pending,
      shouldRollback: true,
      attempts: pending.attempts,
      note: `${pending.to} did not come up after ${pending.attempts} attempts`
    };
  }
  const next = noteBootAttempt(deps, pending);
  return { pending: next, shouldRollback: false, attempts: next.attempts };
}
function scheduleHealthy(deps, plan) {
  if (!plan.pending || plan.shouldRollback) return;
  const timer = setTimeout(() => {
    try {
      markHealthy(deps, plan.pending);
    } catch (e) {
      deps.log?.(`could not finalise the update: ${e?.message ?? e}`);
    }
  }, HEALTHY_AFTER_MS);
  timer.unref?.();
}
function handleFatalWithPending(deps, error) {
  const pending = readPending(deps);
  if (!pending) return false;
  try {
    const outcome = rollback(deps, `the update to ${pending.to} failed to start: ${String(error?.message ?? error)}`);
    deps.log?.(`rolled back to ${outcome.to || "the previous version"} \u2014 ${outcome.reason}`);
    return respawn(deps);
  } catch (e) {
    deps.log?.(`rollback failed: ${e?.message ?? e} \u2014 the previous version is in ${updateDir(deps)}/backup`);
    return false;
  }
}
function rollbackAndRestart(deps, plan) {
  if (!plan.shouldRollback || !plan.pending) return false;
  try {
    const outcome = rollback(deps, plan.note ?? "the new version did not start");
    deps.log?.(`rolled back to ${outcome.to || "the previous version"}`);
    const restarted = respawn(deps);
    if (!restarted) clearPending(deps);
    return true;
  } catch (e) {
    deps.log?.(`rollback failed: ${e?.message ?? e}`);
    clearPending(deps);
    return false;
  }
}

// src/routes/update.ts
var CACHE_MS = 10 * 60 * 1e3;
function updateRoutes(rt) {
  const app = new Hono();
  const sourceOf = (c) => {
    const q = (k) => c?.req?.query?.(k) ?? void 0;
    const header = (k) => c?.req?.header?.(k) ?? void 0;
    const repo = q("repo") ?? header("x-re-update-repo") ?? process.env.RE_UPDATE_REPO ?? void 0;
    const token = q("token") ?? header("x-re-update-token") ?? process.env.RE_UPDATE_TOKEN ?? void 0;
    const manifestUrl = q("manifest") ?? header("x-re-update-manifest") ?? process.env.RE_UPDATE_MANIFEST ?? void 0;
    return { repo, token, manifestUrl };
  };
  const runningVersion = () => sourceVersion() || webBuild(rt.frontendDist)?.version || "dev";
  const depsFor = (c) => ({
    appRoot: appRoot(),
    dataDir: rt.dataDir,
    currentVersion: runningVersion(),
    platform: platformKey(),
    kind: installKind(),
    ...sourceOf(c),
    log: (m) => console.log(`[re] update: ${m}`)
  });
  const deps = depsFor();
  let cache6 = null;
  const check = async (force, d) => {
    const sourceKey = `${d.repo ?? ""}|${d.manifestUrl ?? ""}|${d.token ? "tok" : ""}`;
    if (!force && cache6 && cache6.at && cache6.value && Date.now() - cache6.at < CACHE_MS && cache6.key === sourceKey) {
      return cache6.value;
    }
    const value = await checkForUpdate(d);
    cache6 = { at: Date.now(), value, key: sourceKey };
    return value;
  };
  app.get("/update/status", (c) => {
    const d = depsFor(c);
    return c.json({
      ...updateStatus(d),
      runningVersion: runningVersion(),
      source: {
        kind: d.manifestUrl ? "manifest" : "github",
        repo: (d.repo ?? "").trim() || null,
        manifestUrl: d.manifestUrl ?? null,
        token: d.token ? "set" : "none"
      }
    });
  });
  app.get("/update/check", async (c) => {
    try {
      const value = await check(c.req.query("force") === "1", depsFor(c));
      return c.json(value);
    } catch (e) {
      return c.json({ error: `could not reach GitHub: ${String(e?.message ?? e)}` }, 502);
    }
  });
  app.post("/update/install", async (c) => {
    const body = await c.req.json().catch(() => ({}));
    if (deps.kind === "checkout") {
      return c.json({ ok: false, error: "This is a source checkout \u2014 update it with `git pull && npm run build` (or run the packaged build to get in-app updates)." }, 400);
    }
    if (deps.kind === "desktop") {
      const out2 = await downloadInstaller(depsFor(c), join5(homedir2(), "Downloads"));
      if (!out2.ok || !out2.file) return c.json({ ok: false, error: out2.error ?? "could not download the installer" }, 502);
      const opened = out2.via === "installer" ? openWithOs(out2.file) : false;
      return c.json({
        ok: true,
        kind: "desktop",
        via: out2.via ?? "installer",
        file: out2.file,
        opened,
        message: out2.message ?? (opened ? "Installer downloaded and opened \u2014 finish the install and your library will be waiting." : `Installer saved to ${out2.file} \u2014 open it to finish updating.`)
      });
    }
    if (isBusy()) return c.json({ ok: false, error: "an update is already running" }, 409);
    const d = depsFor(c);
    const out = await installUpdate(d, { version: body.version });
    if (!out.ok) return c.json({ ok: false, error: out.error, status: updateStatus(d) }, 502);
    return c.json({ ok: true, pending: out.pending, restartRequired: true, status: updateStatus(d) });
  });
  app.post("/update/install-file", async (c) => {
    const d = depsFor(c);
    const name = c.req.header("x-re-file-name") ?? c.req.query("name") ?? "";
    const sumsText = c.req.header("x-re-sums") ?? void 0;
    if (!name) return c.json({ ok: false, error: "no file name \u2014 send it in x-re-file-name" }, 400);
    const buf = Buffer.from(await c.req.arrayBuffer());
    if (!buf.length) return c.json({ ok: false, error: "the upload was empty" }, 400);
    const out = await installFromFile(d, { name, buffer: buf }, { version: c.req.query("version") ?? void 0, sumsText });
    if (!out.ok) return c.json({ ok: false, error: out.error, status: updateStatus(d) }, 502);
    return c.json({ ok: true, pending: out.pending, restartRequired: true, status: updateStatus(d) });
  });
  app.post("/update/restart", (c) => {
    const pending = updateStatus(depsFor(c)).pending;
    if (!pending) return c.json({ ok: false, error: "no update is waiting to be started" }, 400);
    setTimeout(() => {
      const restarted = respawn(deps);
      setTimeout(() => process.exit(restarted ? 0 : 1), 150);
    }, 250);
    return c.json({ ok: true, restarting: true });
  });
  app.post("/update/rollback", (c) => {
    try {
      const outcome = rollback(depsFor(c), "rolled back from Settings \u2192 Updates");
      return c.json({ ok: true, outcome, restartRequired: true });
    } catch (e) {
      return c.json({ ok: false, error: String(e?.message ?? e) }, 400);
    }
  });
  app.post("/update/dismiss", (c) => {
    clearOutcome(deps);
    return c.json({ ok: true });
  });
  app.post("/update/fatal-report", async (c) => {
    const body = await c.req.json().catch(() => ({}));
    const handled = handleFatalWithPending(deps, new Error(body.error ?? "unknown boot failure"));
    return c.json({ handled });
  });
  return app;
}

// src/routes/link.ts
import { Hono as Hono2 } from "hono";
var linkRoutes = new Hono2();
var UA = "ResearchEngine/1.0 (+link preview; respects robots.txt)";
var MAX_HTML = 512 * 1024;
var TIMEOUT = 7e3;
var CACHE_TTL = 30 * 60 * 1e3;
var ROBOTS_TTL = 6 * 60 * 60 * 1e3;
var cache3 = /* @__PURE__ */ new Map();
var robotsCache = /* @__PURE__ */ new Map();
function parseTarget(raw) {
  try {
    const u = new URL(raw);
    if (u.protocol !== "http:" && u.protocol !== "https:") return null;
    const host2 = u.hostname.toLowerCase();
    if (host2 === "localhost" || host2.endsWith(".localhost") || host2 === "::1" || host2.endsWith(".internal")) return null;
    if (/^\d+\.\d+\.\d+\.\d+$/.test(host2)) {
      const [a, b] = host2.split(".").map(Number);
      if (a === 10 || a === 127 || a === 0 || a === 192 && b === 168 || a === 172 && b >= 16 && b <= 31 || a === 169 && b === 254) return null;
    }
    return u;
  } catch {
    return null;
  }
}
async function robotsFor(origin) {
  const hit = robotsCache.get(origin);
  if (hit && Date.now() - hit.at < ROBOTS_TTL) return hit;
  try {
    const res = await fetch(`${origin}/robots.txt`, { headers: { "user-agent": UA }, signal: AbortSignal.timeout(TIMEOUT) });
    if (!res.ok) {
      const out2 = { allow: [], disallow: res.status === 401 || res.status === 403 ? ["/"] : [], at: Date.now() };
      robotsCache.set(origin, out2);
      return out2;
    }
    const text2 = (await res.text()).slice(0, 2e5);
    const allow = [];
    const disallow = [];
    let inStar = false;
    for (const raw of text2.split("\n")) {
      const line = raw.split("#")[0].trim();
      if (!line) continue;
      const [k, ...rest] = line.split(":");
      const key = k.trim().toLowerCase();
      const value = rest.join(":").trim();
      if (key === "user-agent") {
        inStar = value === "*";
        continue;
      }
      if (!inStar) continue;
      if (key === "allow" && value) allow.push(value);
      if (key === "disallow" && value) disallow.push(value);
    }
    const out = { allow, disallow, at: Date.now() };
    robotsCache.set(origin, out);
    return out;
  } catch {
    return null;
  }
}
var matches = (rule, path) => {
  const pattern = rule.replace(/[.+?^${}()|[\]\\]/g, "\\$&").replace(/\*/g, ".*").replace(/\\\$$/, "$");
  return new RegExp(`^${pattern.replace(/\$$/, "$")}`).test(path);
};
var robotsAllows = (rules, path) => {
  const best = (list) => list.filter((r) => matches(r, path)).reduce((a2, r) => Math.max(a2, r.length), -1);
  const d = best(rules.disallow);
  const a = best(rules.allow);
  if (d === -1) return true;
  return a >= d;
};
function meta(html, patterns) {
  for (const re of patterns) {
    const m = html.match(re);
    if (m?.[1]) return decodeEntities(m[1].trim());
  }
  return void 0;
}
function decodeEntities(s) {
  return s.replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&#0?39;/g, "'").replace(/&apos;/g, "'").replace(/&#(\d+);/g, (_m, d) => String.fromCharCode(Number(d)));
}
function faviconFor(u) {
  return `https://www.google.com/s2/favicons?domain=${encodeURIComponent(u.hostname)}&sz=64`;
}
linkRoutes.get("/link/preview", async (c) => {
  const raw = c.req.query("url");
  const fallbackIcon = (() => {
    try {
      return faviconFor(new URL(raw ?? "https://example.com"));
    } catch {
      return "";
    }
  })();
  if (!raw) return c.json({ ok: false, error: "Missing ?url=" }, 400);
  const target = parseTarget(raw);
  if (!target) {
    return c.json({
      ok: false,
      url: raw,
      domain: "",
      robots: "unavailable",
      favicon: fallbackIcon,
      fetchedAt: Date.now(),
      reason: "Only public http(s) links can be previewed."
    });
  }
  const key = target.toString();
  const hit = cache3.get(key);
  if (hit && Date.now() - hit.fetchedAt < CACHE_TTL) return c.json(hit);
  const base = {
    ok: true,
    url: key,
    domain: target.hostname,
    robots: "unavailable",
    favicon: faviconFor(target),
    fetchedAt: Date.now(),
    image: null,
    imageSource: null
  };
  const rules = await robotsFor(target.origin);
  if (!rules) {
    const out = { ...base, ok: false, reason: "The site could not be reached for its robots.txt, so nothing was fetched." };
    cache3.set(key, out);
    return c.json(out);
  }
  const path = `${target.pathname}${target.search}`;
  if (!robotsAllows(rules, path)) {
    const out = { ...base, ok: false, robots: "disallowed", reason: "robots.txt asks crawlers to stay out of this path." };
    cache3.set(key, out);
    return c.json(out);
  }
  try {
    const res = await fetch(key, {
      headers: { "user-agent": UA, accept: "text/html,application/xhtml+xml" },
      redirect: "follow",
      signal: AbortSignal.timeout(TIMEOUT)
    });
    if (!res.ok) {
      const out2 = { ...base, ok: false, robots: "allowed", reason: `The page answered ${res.status}.` };
      cache3.set(key, out2);
      return c.json(out2);
    }
    const contentType = res.headers.get("content-type") ?? "";
    if (!contentType.includes("html")) {
      const out2 = { ...base, ok: false, robots: "allowed", reason: "That link is not an HTML page." };
      cache3.set(key, out2);
      return c.json(out2);
    }
    const reader = res.body?.getReader();
    let html = "";
    if (reader) {
      const decoder = new TextDecoder();
      let size = 0;
      for (; ; ) {
        const { done, value } = await reader.read();
        if (done) break;
        size += value?.length ?? 0;
        html += decoder.decode(value, { stream: true });
        if (size > MAX_HTML) break;
        if (/<\/head>/i.test(html)) break;
      }
    } else {
      html = (await res.text()).slice(0, MAX_HTML);
    }
    const title = meta(html, [
      /<meta[^>]+property=["']og:title["'][^>]+content=["']([^"']+)["']/i,
      /<meta[^>]+content=["']([^"']+)["'][^>]+property=["']og:title["']/i,
      /<meta[^>]+name=["']twitter:title["'][^>]+content=["']([^"']+)["']/i,
      /<title[^>]*>([^<]+)<\/title>/i
    ]);
    const description = meta(html, [
      /<meta[^>]+property=["']og:description["'][^>]+content=["']([^"']+)["']/i,
      /<meta[^>]+content=["']([^"']+)["'][^>]+property=["']og:description["']/i,
      /<meta[^>]+name=["']description["'][^>]+content=["']([^"']+)["']/i,
      /<meta[^>]+name=["']twitter:description["'][^>]+content=["']([^"']+)["']/i
    ]);
    const siteName = meta(html, [
      /<meta[^>]+property=["']og:site_name["'][^>]+content=["']([^"']+)["']/i,
      /<meta[^>]+name=["']application-name["'][^>]+content=["']([^"']+)["']/i
    ]);
    let image = meta(html, [
      /<meta[^>]+property=["']og:image:secure_url["'][^>]+content=["']([^"']+)["']/i,
      /<meta[^>]+property=["']og:image["'][^>]+content=["']([^"']+)["']/i,
      /<meta[^>]+content=["']([^"']+)["'][^>]+property=["']og:image["']/i,
      /<meta[^>]+name=["']twitter:image["'][^>]+content=["']([^"']+)["']/i
    ]);
    if (image) {
      try {
        image = new URL(image, res.url || key).toString();
      } catch {
        image = void 0;
      }
    }
    const declaredIcon = meta(html, [/<link[^>]+rel=["'][^"']*icon[^"']*["'][^>]+href=["']([^"']+)["']/i]);
    let favicon = faviconFor(target);
    if (declaredIcon) {
      try {
        favicon = new URL(declaredIcon, res.url || key).toString();
      } catch {
      }
    }
    const out = {
      ...base,
      robots: "allowed",
      title,
      description: description?.slice(0, 300),
      siteName,
      favicon,
      image: image ?? null,
      imageSource: image ? "page" : null,
      // No og:image: hand the browser a screenshot-service URL to try. It is
      // fetched by the user's machine, not by this server, and the frontend
      // falls back to the favicon tile if even that fails.
      ...image ? {} : { screenshot: `https://api.microlink.io/?url=${encodeURIComponent(key)}&screenshot=true&meta=false&embed=screenshot.url&viewport.width=1200&viewport.height=630` }
    };
    cache3.set(key, out);
    return c.json(out);
  } catch (e) {
    const out = { ...base, ok: false, robots: "allowed", reason: `The page could not be read (${String(e?.name ?? "error")}).` };
    cache3.set(key, out);
    return c.json(out);
  }
});

// src/index.ts
var fatalDataDir = "";
async function main() {
  const rt = await resolveRuntime(process.argv.slice(2));
  fatalDataDir = rt.dataDir;
  const { healthRoutes: healthRoutes2 } = await init_health().then(() => health_exports);
  const { feedbackRoutes: feedbackRoutes2 } = await init_feedback().then(() => feedback_exports);
  const { libraryRoutes: libraryRoutes2 } = await init_library().then(() => library_exports);
  const { skillsRoutes: skillsRoutes2 } = await init_skills().then(() => skills_exports);
  const { searchRoutes: searchRoutes2 } = await Promise.resolve().then(() => (init_search(), search_exports));
  const { chatRoutes: chatRoutes2 } = await Promise.resolve().then(() => (init_chat(), chat_exports));
  const { documentRoutes: documentRoutes2 } = await init_documents().then(() => documents_exports);
  const { ollamaRoutes: ollamaRoutes2 } = await Promise.resolve().then(() => (init_ollama(), ollama_exports));
  const { integrationRoutes: integrationRoutes2 } = await Promise.resolve().then(() => (init_integrations2(), integrations_exports));
  const { resourceRoutes: resourceRoutes2 } = await init_resources().then(() => resources_exports);
  const { fsRoutes: fsRoutes2 } = await Promise.resolve().then(() => (init_fs(), fs_exports));
  const { providerRoutes: providerRoutes2 } = await Promise.resolve().then(() => (init_providers(), providers_exports));
  const { ideRoutes: ideRoutes2 } = await Promise.resolve().then(() => (init_ide(), ide_exports));
  const { previewRoutes: previewRoutes2 } = await Promise.resolve().then(() => (init_preview(), preview_exports));
  const { PreviewManager: PreviewManager3 } = await Promise.resolve().then(() => (init_manager(), manager_exports));
  const { connectorRoutes: connectorRoutes2 } = await Promise.resolve().then(() => (init_connectors(), connectors_exports));
  const { mcpRoutes: mcpRoutes2 } = await Promise.resolve().then(() => (init_mcp(), mcp_exports));
  const previews = new PreviewManager3();
  previewsForExit = previews;
  const app = new Hono20();
  app.use("*", cors());
  app.use("*", logger((msg) => console.log(`[re] ${msg}`)));
  app.route("/api", healthRoutes2(rt.frontendDist));
  app.route("/api", resourceRoutes2(rt));
  app.route("/api", fsRoutes2(rt));
  app.route("/api", ideRoutes2(rt));
  app.route("/api", previewRoutes2(rt, previews));
  app.route("/api", connectorRoutes2(rt));
  app.route("/api", mcpRoutes2());
  app.route("/api/search", searchRoutes2);
  const { voiceRoutes: voiceRoutes2 } = await Promise.resolve().then(() => (init_voice(), voice_exports));
  app.route("/api", voiceRoutes2);
  app.route("/api/chat", chatRoutes2);
  app.route("/api/documents", documentRoutes2);
  app.route("/api/ollama", ollamaRoutes2);
  app.route("/api/integrations", integrationRoutes2(rt));
  app.route("/api", providerRoutes2);
  app.route("/api", updateRoutes(rt));
  app.route("/api", linkRoutes);
  app.route("/api/feedback", feedbackRoutes2);
  app.route("/api/library", libraryRoutes2);
  app.route("/api/skills", skillsRoutes2);
  app.onError((err, c) => {
    return c.json({ error: err.message }, 500);
  });
  app.all("/api/*", (c) => {
    const path = new URL(c.req.url).pathname;
    return c.json({
      error: `This server has no route for ${c.req.method} ${path}.`,
      code: "no_such_route",
      hint: "The app and its local server are different versions \u2014 they always ship together. Restart Research Engine, or install the latest version. Settings \u2192 About shows the version this server is running.",
      server: {
        version: sourceVersion() || "dev",
        frontend: rt.frontendDist ? webBuild(rt.frontendDist)?.version ?? "unknown" : "not served"
      }
    }, 404);
  });
  app.notFound((c) => {
    const path = new URL(c.req.url).pathname;
    if (path === "/api" || path.startsWith("/api/")) {
      return c.json({ error: `No route for ${path}.`, code: "no_such_route" }, 404);
    }
    return c.text("Not found", 404);
  });
  if (rt.frontendDist) {
    const handler = staticHandler(rt.frontendDist);
    app.get("*", handler);
  }
  const updateDeps = {
    appRoot: appRoot(),
    dataDir: rt.dataDir,
    currentVersion: sourceVersion() || webBuild(rt.frontendDist)?.version || "dev",
    platform: process.platform,
    kind: installKind(),
    log: (m) => console.log(`[re] update: ${m}`)
  };
  const boot = bootUpdateCheck(updateDeps);
  if (rollbackAndRestart(updateDeps, boot)) {
    console.log("[re] rolled back a failed update \u2014 restarting the previous version");
    process.exit(EXIT_RESTART);
  }
  serve({ fetch: app.fetch, port: rt.port, hostname: rt.host }, (info) => {
    console.log(`Research Engine listening on http://${rt.host}:${info.port}`);
    console.log(`  data dir : ${rt.dataDir}`);
    console.log(`  profile  : ${rt.profile} (${rt.caps.floodWorkers} flood worker${rt.caps.floodWorkers > 1 ? "s" : ""}, ${rt.caps.concurrentStreams} concurrent stream${rt.caps.concurrentStreams > 1 ? "s" : ""})`);
    console.log(`  frontend : ${rt.frontendDist ?? "not found \u2014 API only (run `npm run build` in frontend/ for single-process mode)"}${rt.frontendDist ? webBuildNote(rt) : ""}`);
    console.log(`  database : ${rt.dbPath}`);
    if (rt.rememberedPort) console.log(`  note     : preferred port was busy \u2014 using ${info.port} (remembered in config.json)`);
    if (boot.pending) console.log(`  update   : ${boot.pending.from} \u2192 ${boot.pending.to} on trial (attempt ${boot.attempts}) \u2014 kept once this build serves pages`);
    scheduleHealthy(updateDeps, boot);
  });
}
function webBuildNote(rt) {
  const served = webBuild(rt.frontendDist);
  if (!served) return " (no build-info.json \u2014 rebuild the frontend to get a fingerprint)";
  const source = sourceVersion();
  const stale = source && served.version !== source ? ` \u2014 STALE, source is ${source} (run: npm run build)` : "";
  return ` [${served.version}]${stale}`;
}
var previewsForExit = null;
process.on("exit", () => {
  try {
    previewsForExit?.stopAllSync();
  } catch {
  }
});
for (const sig of ["SIGINT", "SIGTERM", "SIGHUP"]) {
  process.on(sig, () => {
    try {
      previewsForExit?.stopAllSync();
    } catch {
    }
    ;
    process.exit(0);
  });
}
main().catch((e) => {
  console.error("[re] fatal:", e);
  if (handleFatalWithPending({
    appRoot: appRoot(),
    dataDir: fatalDataDir,
    currentVersion: sourceVersion() || "0.0.0",
    platform: process.platform,
    kind: installKind(),
    log: (m) => console.log(`[re] update: ${m}`)
  }, e)) {
    console.log("[re] update rolled back \u2014 restarting the previous version");
    process.exit(EXIT_RESTART);
  }
  process.exit(1);
});
