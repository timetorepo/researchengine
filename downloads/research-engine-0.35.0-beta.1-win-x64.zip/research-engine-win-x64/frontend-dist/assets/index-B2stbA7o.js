import{e1 as e,e2 as a,e3 as t}from"./index-BtbLgU-2.js";const n={renderer:t,...a,...e};var o=n;export{o as default};
