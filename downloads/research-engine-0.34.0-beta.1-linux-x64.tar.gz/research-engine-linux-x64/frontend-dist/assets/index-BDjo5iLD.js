import{dV as a,dW as e,dX as t}from"./index-BQZKA3Ed.js";const n={renderer:t,...e,...a};var o=n;export{o as default};
