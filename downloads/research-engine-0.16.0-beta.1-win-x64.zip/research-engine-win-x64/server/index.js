var __defProp = Object.defineProperty;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// src/runtime.ts
import { existsSync, mkdirSync, readFileSync, writeFileSync, statSync, readdirSync } from "node:fs";
import { join, resolve } from "node:path";
import { homedir } from "node:os";
import { createServer } from "node:net";
function parseFlags(argv) {
  const f = { serve: argv[0] !== "serve" ? true : true };
  const args2 = argv.filter((a) => a !== "serve");
  for (let i = 0; i < args2.length; i++) {
    const a = args2[i];
    const val = () => args2[++i];
    if (a === "--port") f.port = Number(val());
    else if (a === "--host") f.host = val();
    else if (a === "--data-dir") f.dataDir = val();
    else if (a === "--profile") {
      const p = val();
      if (p in PROFILES) f.profile = p;
    } else if (a === "--frontend-dist") f.frontendDist = val();
    else if (a === "--help" || a === "-h") {
      console.log(`Research Engine \u2014 single-process server

Usage: research-engine serve [options]
  --port <n>          HTTP port (default 3847; auto-picks next free if busy)
  --host <addr>       Bind address (default 127.0.0.1)
  --data-dir <path>   Data directory (default ~/.research-engine)
  --profile <p>       eco | balanced | performance (default balanced)
  --frontend-dist <p> Path to built frontend (default ../frontend/dist)

Environment: RE_PORT, RE_HOST, RESEARCH_ENGINE_DATA_DIR, RE_PROFILE, FRONTEND_DIST`);
      process.exit(0);
    }
  }
  return f;
}
function configPath(dataDir) {
  return join(dataDir, "config.json");
}
function loadConfig(dataDir) {
  try {
    return JSON.parse(readFileSync(configPath(dataDir), "utf8"));
  } catch {
    return {};
  }
}
function saveConfig(dataDir, patch) {
  const merged = { ...loadConfig(dataDir), ...patch };
  writeFileSync(configPath(dataDir), JSON.stringify(merged, null, 2));
  return merged;
}
function ensureDataDir(dataDir) {
  for (const sub of ["", "media", "notebooks", "cache"]) {
    mkdirSync(join(dataDir, sub), { recursive: true });
  }
  if (!existsSync(configPath(dataDir))) writeFileSync(configPath(dataDir), "{}\n");
}
function dirSize(dir) {
  try {
    let total = 0;
    for (const entry of readdirSync(dir, { withFileTypes: true })) {
      const p = join(dir, entry.name);
      if (entry.isDirectory()) total += dirSize(p);
      else if (entry.isFile()) total += statSync(p).size;
    }
    return total;
  } catch {
    return 0;
  }
}
function portFree(port, host) {
  return new Promise((res) => {
    const srv = createServer();
    srv.once("error", () => res(false));
    srv.listen({ port, host, exclusive: true }, () => {
      srv.close(() => res(true));
    });
  });
}
async function pickPort(preferred, host) {
  for (let i = 0; i < 20; i++) {
    if (await portFree(preferred + i, host)) return preferred + i;
  }
  return preferred;
}
async function resolveRuntime(argv) {
  const flags = parseFlags(argv);
  const dataDir = resolve(flags.dataDir ?? process.env.RESEARCH_ENGINE_DATA_DIR ?? join(homedir(), ".research-engine"));
  ensureDataDir(dataDir);
  const saved = loadConfig(dataDir);
  const host = flags.host ?? process.env.RE_HOST ?? "127.0.0.1";
  const envPort = Number(process.env.RE_PORT ?? process.env.PORT ?? "");
  const isDev = import.meta.url.includes("/src/");
  const preferredPort = flags.port ?? (envPort || (isDev ? 8787 : saved.port || 3847));
  const port = await pickPort(preferredPort, host);
  const rememberedPort = port !== preferredPort;
  const profileRaw = flags.profile ?? process.env.RE_PROFILE ?? saved.profile ?? "balanced";
  const profile = profileRaw in PROFILES ? profileRaw : "balanced";
  const candidates = [
    flags.frontendDist,
    process.env.FRONTEND_DIST,
    resolve(import.meta.dirname, "../../frontend/dist"),
    resolve(process.cwd(), "frontend/dist")
  ].filter(Boolean);
  const frontendDist = candidates.find((d) => existsSync(join(d, "index.html"))) ?? null;
  const dbPath2 = process.env.DB_PATH ?? join(dataDir, "db.sqlite");
  process.env.DB_PATH = dbPath2;
  if (rememberedPort && !isDev) saveConfig(dataDir, { port });
  return { port, host, dataDir, profile, caps: PROFILES[profile], frontendDist, dbPath: dbPath2, rememberedPort };
}
var PROFILES;
var init_runtime = __esm({
  "src/runtime.ts"() {
    "use strict";
    PROFILES = {
      eco: {
        floodWorkers: 1,
        searchResults: 5,
        concurrentStreams: 1,
        backgroundIndexing: false,
        description: "1 concurrent stream, smaller retrieval, no background work. Best on \u22648 GB RAM."
      },
      balanced: {
        floodWorkers: 2,
        searchResults: 7,
        concurrentStreams: 2,
        backgroundIndexing: true,
        description: "Normal multi-tab use. Background indexing allowed."
      },
      performance: {
        floodWorkers: 4,
        searchResults: 9,
        concurrentStreams: 4,
        backgroundIndexing: true,
        description: "Parallel agents, faster preloading, larger caches."
      }
    };
  }
});

// src/db/schema.ts
var schema_exports = {};
__export(schema_exports, {
  chats: () => chats,
  citations: () => citations,
  documents: () => documents,
  messages: () => messages,
  skills: () => skills
});
import { sqliteTable, text, integer } from "drizzle-orm/sqlite-core";
var chats, messages, documents, skills, citations;
var init_schema = __esm({
  "src/db/schema.ts"() {
    "use strict";
    chats = sqliteTable("chats", {
      id: text("id").primaryKey(),
      title: text("title").notNull(),
      spaceId: text("space_id"),
      createdAt: integer("created_at").notNull(),
      updatedAt: integer("updated_at").notNull()
    });
    messages = sqliteTable("messages", {
      id: text("id").primaryKey(),
      chatId: text("chat_id").notNull(),
      role: text("role").notNull(),
      content: text("content").notNull(),
      model: text("model"),
      createdAt: integer("created_at").notNull()
    });
    documents = sqliteTable("documents", {
      id: text("id").primaryKey(),
      name: text("name").notNull(),
      kind: text("kind").notNull(),
      text: text("text").notNull(),
      addedAt: integer("added_at").notNull()
    });
    skills = sqliteTable("skills", {
      id: text("id").primaryKey(),
      name: text("name").notNull(),
      json: text("json").notNull()
    });
    citations = sqliteTable("citations", {
      id: text("id").primaryKey(),
      title: text("title").notNull(),
      url: text("url").notNull(),
      collection: text("collection"),
      savedAt: integer("saved_at").notNull()
    });
  }
});

// src/db/index.ts
function dbStats() {
  return sqlite ? { engine, file: process.env.DB_PATH ?? "./research-engine.db" } : { engine: "memory" };
}
var MIGRATION, sqlite, engine, dbPath, mem, db;
var init_db = __esm({
  async "src/db/index.ts"() {
    "use strict";
    init_schema();
    MIGRATION = `
CREATE TABLE IF NOT EXISTS chats (id TEXT PRIMARY KEY, title TEXT, space_id TEXT, created_at INTEGER, updated_at INTEGER);
CREATE TABLE IF NOT EXISTS messages (id TEXT PRIMARY KEY, chat_id TEXT, role TEXT, content TEXT, model TEXT, created_at INTEGER);
CREATE TABLE IF NOT EXISTS documents (id TEXT PRIMARY KEY, name TEXT, kind TEXT, text TEXT, added_at INTEGER);
CREATE TABLE IF NOT EXISTS skills (id TEXT PRIMARY KEY, name TEXT, json TEXT);
CREATE TABLE IF NOT EXISTS citations (id TEXT PRIMARY KEY, title TEXT, url TEXT, collection TEXT, saved_at INTEGER);
`;
    sqlite = null;
    engine = "memory";
    dbPath = process.env.DB_PATH ?? "./research-engine.db";
    try {
      const Database = (await import("better-sqlite3")).default;
      sqlite = new Database(dbPath);
      sqlite.pragma("journal_mode = WAL");
      sqlite.exec(MIGRATION);
      engine = "sqlite (better-sqlite3)";
    } catch {
      try {
        const { DatabaseSync } = await import("node:sqlite");
        sqlite = new DatabaseSync(dbPath);
        sqlite.exec("PRAGMA journal_mode = WAL");
        sqlite.exec(MIGRATION);
        engine = "sqlite (node:sqlite)";
      } catch (e2) {
        console.warn("[re] no SQLite driver available \u2014 using in-memory fallback (data will not survive a restart). (" + e2.message + ")");
      }
    }
    mem = {
      chats: /* @__PURE__ */ new Map(),
      documents: /* @__PURE__ */ new Map()
    };
    db = {
      schema: schema_exports,
      insertChat(chat) {
        if (sqlite) sqlite.prepare("INSERT OR REPLACE INTO chats VALUES (?,?,?,?,?)").run(chat.id, chat.title, chat.spaceId ?? null, chat.createdAt, chat.updatedAt);
        else mem.chats.set(chat.id, chat);
      },
      insertDocument(doc) {
        if (sqlite) sqlite.prepare("INSERT OR REPLACE INTO documents VALUES (?,?,?,?,?)").run(doc.id, doc.name, doc.kind, doc.text, doc.addedAt);
        else mem.documents.set(doc.id, doc);
      },
      listDocuments() {
        if (sqlite) return sqlite.prepare("SELECT id, name, kind, added_at as addedAt FROM documents ORDER BY added_at DESC").all();
        return [...mem.documents.values()];
      }
    };
  }
});

// src/routes/health.ts
var health_exports = {};
__export(health_exports, {
  healthRoutes: () => healthRoutes
});
import { Hono } from "hono";
var healthRoutes;
var init_health = __esm({
  async "src/routes/health.ts"() {
    "use strict";
    await init_db();
    healthRoutes = new Hono();
    healthRoutes.get(
      "/health",
      (c) => c.json({ ok: true, service: "research-engine-backend", time: (/* @__PURE__ */ new Date()).toISOString(), db: dbStats() })
    );
  }
});

// src/services/search/adapters.ts
async function searchSearxng(base, q) {
  const res = await fetch(`${base.replace(/\/$/, "")}/search?q=${encodeURIComponent(q)}&format=json`);
  if (!res.ok) throw new Error(`SearXNG responded ${res.status}`);
  const json = await res.json();
  return (json.results ?? []).slice(0, 8).map((r) => ({
    title: r.title,
    url: r.url,
    snippet: r.content ?? "",
    domain: new URL(r.url).hostname
  }));
}
async function searchBrave(q) {
  const key = process.env.BRAVE_API_KEY;
  if (!key) throw new Error("BRAVE_API_KEY is not set on the backend");
  const res = await fetch(`https://api.search.brave.com/res/v1/web/search?q=${encodeURIComponent(q)}`, {
    headers: { "X-Subscription-Token": key, accept: "application/json" }
  });
  if (!res.ok) throw new Error(`Brave responded ${res.status}`);
  const json = await res.json();
  return (json.web?.results ?? []).slice(0, 8).map((r) => ({
    title: r.title,
    url: r.url,
    snippet: r.description ?? "",
    domain: new URL(r.url).hostname
  }));
}
async function searchSerper(q) {
  const key = process.env.SERPER_API_KEY;
  if (!key) throw new Error("SERPER_API_KEY is not set on the backend");
  const res = await fetch("https://google.serper.dev/search", {
    method: "POST",
    headers: { "X-API-KEY": key, "content-type": "application/json" },
    body: JSON.stringify({ q })
  });
  if (!res.ok) throw new Error(`Serper responded ${res.status}`);
  const json = await res.json();
  return (json.organic ?? []).slice(0, 8).map((r) => ({
    title: r.title,
    url: r.link,
    snippet: r.snippet ?? "",
    domain: new URL(r.link).hostname
  }));
}
async function searchTavily(q) {
  const key = process.env.TAVILY_API_KEY;
  if (!key) throw new Error("TAVILY_API_KEY is not set on the backend");
  const res = await fetch("https://api.tavily.com/search", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ api_key: key, query: q, max_results: 8 })
  });
  if (!res.ok) throw new Error(`Tavily responded ${res.status}`);
  const json = await res.json();
  return (json.results ?? []).map((r) => ({
    title: r.title,
    url: r.url,
    snippet: r.content ?? "",
    domain: new URL(r.url).hostname
  }));
}
async function searchDdg(q) {
  const res = await fetch(`https://html.duckduckgo.com/html/?q=${encodeURIComponent(q)}`, {
    headers: { "user-agent": "Mozilla/5.0 (Research Engine)" }
  });
  if (!res.ok) throw new Error(`DuckDuckGo responded ${res.status}`);
  const html = await res.text();
  const out = [];
  const re = /<a[^>]+class="result__a"[^>]+href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/g;
  let m;
  while ((m = re.exec(html)) && out.length < 8) {
    const url = decodeURIComponent(m[1].replace(/^.*uddg=/, "").replace(/&rut=.*$/, ""));
    const title = m[2].replace(/<[^>]+>/g, "").trim();
    if (url.startsWith("http")) out.push({ title, url, snippet: "", domain: new URL(url).hostname });
  }
  return out;
}
function searchDemo(q) {
  const domains = ["arxiv.org", "nature.com", "wikipedia.org", "acm.org", "ncbi.nlm.nih.gov"];
  return domains.map((d, i) => ({
    title: `${q} \u2014 result ${i + 1}`,
    url: `https://${d}/${encodeURIComponent(q.toLowerCase().replace(/\s+/g, "-"))}`,
    snippet: `Demo result for "${q}" (configure a real backend in .env).`,
    domain: d
  }));
}
var init_adapters = __esm({
  "src/services/search/adapters.ts"() {
    "use strict";
  }
});

// src/routes/search.ts
var search_exports = {};
__export(search_exports, {
  searchRoutes: () => searchRoutes
});
import { Hono as Hono2 } from "hono";
var searchRoutes;
var init_search = __esm({
  "src/routes/search.ts"() {
    "use strict";
    init_adapters();
    searchRoutes = new Hono2();
    searchRoutes.get("/", async (c) => {
      const q = c.req.query("q");
      if (!q) return c.json({ error: "Missing ?q=" }, 400);
      if (c.req.query("offline") === "1") {
        return c.json({ backend: "demo", results: searchDemo(q) });
      }
      const requested = c.req.query("backend") ?? process.env.SEARCH_BACKEND ?? "searxng";
      const run = async (backend) => {
        switch (backend) {
          case "searxng":
            return searchSearxng(process.env.SEARXNG_URL ?? "http://localhost:8080", q);
          case "brave":
            return searchBrave(q);
          case "serper":
            return searchSerper(q);
          case "tavily":
            return searchTavily(q);
          case "ddg":
            return searchDdg(q);
          default:
            return searchDemo(q);
        }
      };
      try {
        const results = await run(requested);
        if (results.length) return c.json({ backend: requested, results });
      } catch {
      }
      if (requested !== "ddg") {
        try {
          const results = await searchDdg(q);
          if (results.length) return c.json({ backend: "ddg", results });
        } catch {
        }
      }
      return c.json({ backend: "demo", results: searchDemo(q) });
    });
  }
});

// src/routes/secrets.ts
function maskSecrets(text2) {
  let out = String(text2 ?? "");
  for (const re of PATTERNS) out = out.replace(re, "[REDACTED]");
  return out;
}
var PATTERNS;
var init_secrets = __esm({
  "src/routes/secrets.ts"() {
    "use strict";
    PATTERNS = [
      /\bsk-[A-Za-z0-9_-]{16,}\b/g,
      // OpenAI-style
      /\bsk-ant-[A-Za-z0-9_-]{16,}\b/g,
      // Anthropic
      /\bsk-proj-[A-Za-z0-9_-]{16,}\b/g,
      /\bAIza[0-9A-Za-z_-]{30,}\b/g,
      // Google / Gemini
      /\bghp_[A-Za-z0-9]{30,}\b/g,
      // GitHub PAT
      /\bgho_[A-Za-z0-9]{30,}\b/g,
      /\bgithub_pat_[A-Za-z0-9_]{30,}\b/g,
      /\bxox[baprs]-[A-Za-z0-9-]{10,}\b/g,
      // Slack
      /\bAKIA[0-9A-Z]{16}\b/g,
      // AWS
      /\bhf_[A-Za-z0-9]{20,}\b/g,
      // HuggingFace
      /\bnvapi-[A-Za-z0-9_-]{16,}\b/g,
      // NVIDIA NIM
      /\beyJ[A-Za-z0-9_-]{12,}\.[A-Za-z0-9_-]{12,}\.[A-Za-z0-9_-]{6,}\b/g,
      // JWT
      /-----BEGIN [A-Z ]*PRIVATE KEY-----[\s\S]{20,}?-----END [A-Z ]*PRIVATE KEY-----/g,
      /\bkey-[A-Za-z0-9]{20,}\b/g
    ];
  }
});

// src/routes/chat.ts
var chat_exports = {};
__export(chat_exports, {
  chatRoutes: () => chatRoutes
});
import { Hono as Hono3 } from "hono";
import { streamSSE } from "hono/streaming";
function toOpenAIMessages(system, messages2) {
  const out = system ? [{ role: "system", content: system }] : [];
  for (const m of messages2) {
    if (m.role === "tool") {
      out.push({ role: "tool", tool_call_id: m.toolCallId, content: typeof m.content === "string" ? m.content : JSON.stringify(m.content) });
      continue;
    }
    const msg = { role: m.role };
    if (Array.isArray(m.content)) {
      msg.content = m.content.map((p) => p.type === "image" ? { type: "image_url", image_url: { url: p.dataUrl } } : { type: "text", text: p.text });
    } else {
      msg.content = m.content ?? "";
    }
    if (m.toolCalls?.length) {
      msg.tool_calls = m.toolCalls.map((t) => ({ id: t.id, type: "function", function: { name: t.name, arguments: typeof t.arguments === "string" ? t.arguments : JSON.stringify(t.arguments ?? {}) } }));
    }
    out.push(msg);
  }
  return out;
}
function toGeminiContents(messages2) {
  const out = [];
  for (const m of messages2) {
    if (m.role === "tool") {
      out.push({ role: "user", parts: [{ functionResponse: { name: m.name ?? "tool", response: { result: typeof m.content === "string" ? m.content : JSON.stringify(m.content) } } }] });
      continue;
    }
    const role = m.role === "assistant" ? "model" : "user";
    const parts = [];
    if (Array.isArray(m.content)) {
      for (const p of m.content) {
        if (p.type === "image") {
          const { mime, data } = splitDataUrl(p.dataUrl);
          parts.push({ inline_data: { mime_type: mime, data } });
        } else if (p.text) parts.push({ text: p.text });
      }
    } else if (typeof m.content === "string" && m.content) {
      parts.push({ text: m.content });
    }
    if (m.toolCalls?.length) {
      for (const t of m.toolCalls) {
        let args2 = t.arguments;
        if (typeof args2 === "string") {
          try {
            args2 = JSON.parse(args2);
          } catch {
            args2 = { input: args2 };
          }
        }
        parts.push({ functionCall: { name: t.name, args: args2 ?? {} } });
      }
    }
    if (parts.length) out.push({ role, parts });
  }
  return out;
}
function toAnthropicBody(system, messages2) {
  const out = [];
  for (const m of messages2) {
    if (m.role === "tool") {
      out.push({ role: "user", content: [{ type: "tool_result", tool_use_id: m.toolCallId, content: typeof m.content === "string" ? m.content : JSON.stringify(m.content) }] });
      continue;
    }
    const content = [];
    if (Array.isArray(m.content)) {
      for (const p of m.content) {
        if (p.type === "image") {
          const { mime, data } = splitDataUrl(p.dataUrl);
          content.push({ type: "image", source: { type: "base64", media_type: mime, data } });
        } else if (p.text) content.push({ type: "text", text: p.text });
      }
    } else if (typeof m.content === "string" && m.content) {
      content.push({ type: "text", text: m.content });
    }
    if (m.role === "assistant" && m.toolCalls?.length) {
      for (const t of m.toolCalls) {
        let input = t.arguments;
        if (typeof input === "string") {
          try {
            input = JSON.parse(input);
          } catch {
            input = {};
          }
        }
        content.push({ type: "tool_use", id: t.id, name: t.name, input: input ?? {} });
      }
    }
    if (content.length) out.push({ role: m.role === "assistant" ? "assistant" : "user", content });
  }
  const merged = [];
  for (const m of out) {
    const last = merged[merged.length - 1];
    if (last && last.role === m.role) last.content = [...last.content, ...m.content];
    else merged.push(m);
  }
  return { system: system || void 0, messages: merged.filter((m) => m.role === "user" || merged.indexOf(m) > 0) };
}
var chatRoutes, splitDataUrl;
var init_chat = __esm({
  "src/routes/chat.ts"() {
    "use strict";
    init_secrets();
    chatRoutes = new Hono3();
    splitDataUrl = (dataUrl) => {
      const m = /^data:([^;]+);base64,(.*)$/s.exec(dataUrl ?? "");
      return m ? { mime: m[1], data: m[2] } : { mime: "image/png", data: dataUrl ?? "" };
    };
    chatRoutes.post("/", async (c) => {
      const body = await c.req.json();
      const kind = body.kind ?? "openai";
      const model = body.model;
      const key = body.key ?? body.apiKey ?? "";
      const base = String(body.base ?? body.baseUrl ?? "").replace(/\/+$/, "");
      const system = body.system ?? "";
      const messages2 = body.messages ?? [];
      const maxTokens = body.maxTokens ?? 1024;
      const temperature = body.temperature ?? 0.7;
      const tools = Array.isArray(body.tools) && body.tools.length ? body.tools : null;
      if (!model) return c.json({ error: "model is required" }, 400);
      if (!base) return c.json({ error: "base is required" }, 400);
      let url;
      let headers;
      let payload;
      const isNvidia = base.includes("api.nvidia.com") || kind === "nim";
      const browserish = {
        "user-agent": isNvidia ? "NVIDIA-NIM-Client/1.0" : "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
        accept: "text/event-stream"
      };
      if (kind === "anthropic") {
        url = `${base}/messages`;
        headers = {
          ...browserish,
          "content-type": "application/json",
          "x-api-key": key,
          "anthropic-version": "2023-06-01"
        };
        const conv = toAnthropicBody(system, messages2);
        payload = { model, stream: true, max_tokens: maxTokens, temperature, system: conv.system ?? "", messages: conv.messages };
        if (tools) {
          payload.tools = tools.map((t) => ({ name: t.function.name, description: t.function.description ?? "", input_schema: t.function.parameters ?? { type: "object", properties: {} } }));
        }
      } else if (kind === "gemini") {
        url = `${base}/models/${encodeURIComponent(model)}:streamGenerateContent?alt=sse`;
        headers = {
          ...browserish,
          "content-type": "application/json",
          ...key ? { "x-goog-api-key": key } : {}
        };
        payload = {
          contents: toGeminiContents(messages2),
          generationConfig: { temperature, maxOutputTokens: maxTokens }
        };
        if (system) payload.systemInstruction = { parts: [{ text: system }] };
        if (tools) {
          payload.tools = [{
            functionDeclarations: tools.map((t) => ({
              name: t.function.name,
              description: t.function.description ?? "",
              parameters: t.function.parameters ?? { type: "object", properties: {} }
            }))
          }];
        }
      } else {
        url = `${base}/chat/completions`;
        headers = {
          ...browserish,
          "content-type": "application/json",
          ...key ? { authorization: `Bearer ${key}` } : {},
          ...isNvidia && key ? { "x-nvidia-api-key": key } : {}
        };
        payload = {
          model,
          stream: true,
          max_tokens: maxTokens,
          temperature,
          messages: toOpenAIMessages(system, messages2)
        };
        if (tools) {
          payload.tools = tools;
          payload.tool_choice = "auto";
        }
        if (isNvidia && /deepseek|reasoning|qwq|thought|thinking|nemotron/i.test(model)) {
          payload.chat_template_kwargs = { enable_thinking: true, thinking: true };
        }
      }
      const upstream = await fetch(url, {
        method: "POST",
        headers,
        body: JSON.stringify(payload),
        signal: c.req.raw.signal
        // client abort kills the upstream call
      });
      if (!upstream.ok || !upstream.body) {
        const errText = await upstream.text().catch(() => "");
        let msg = `${upstream.status}`;
        try {
          const j = JSON.parse(errText);
          msg = j?.error?.message ?? j?.detail ?? j?.message ?? msg;
        } catch {
        }
        if (upstream.status === 403 && isNvidia) {
          msg += " \u2014 NVIDIA rejected this key for chat. GET /v1/models can still work when inference is not enabled. Check that your NVIDIA organization has Public API Endpoints access, accept the model terms on its catalog page, regenerate the nvapi key, and try a currently chat-capable model. Research Engine already sends NVIDIA-NIM-Client/1.0, Bearer, and X-NVIDIA-API-Key headers.";
        }
        return c.json({ error: maskSecrets(msg) }, upstream.status);
      }
      c.header("Content-Type", "text/event-stream");
      c.header("Cache-Control", "no-cache");
      return streamSSE(c, async (stream) => {
        const reader = upstream.body.getReader();
        const td = new TextDecoder();
        try {
          for (; ; ) {
            const { done, value } = await reader.read();
            if (done) break;
            await stream.write(td.decode(value, { stream: true }));
          }
        } catch {
        }
      });
    });
  }
});

// src/routes/documents.ts
var documents_exports = {};
__export(documents_exports, {
  documentRoutes: () => documentRoutes
});
import { Hono as Hono4 } from "hono";
var documentRoutes;
var init_documents = __esm({
  async "src/routes/documents.ts"() {
    "use strict";
    await init_db();
    documentRoutes = new Hono4();
    documentRoutes.post("/", async (c) => {
      const body = await c.req.json();
      const { id, name, kind = "file", text: text2 = "" } = body;
      if (!id || !name) return c.json({ error: "id and name are required" }, 400);
      db.insertDocument({ id, name, kind, text: text2, addedAt: Date.now() });
      return c.json({ ok: true, id });
    });
    documentRoutes.get("/", (c) => c.json({ documents: db.listDocuments() }));
  }
});

// src/routes/ollama.ts
var ollama_exports = {};
__export(ollama_exports, {
  ollamaRoutes: () => ollamaRoutes
});
import { Hono as Hono5 } from "hono";
var ollamaRoutes;
var init_ollama = __esm({
  "src/routes/ollama.ts"() {
    "use strict";
    ollamaRoutes = new Hono5();
    ollamaRoutes.get("/tags", async (c) => {
      const base = (process.env.OLLAMA_URL ?? "http://localhost:11434").replace(/\/$/, "");
      try {
        const res = await fetch(`${base}/api/tags`);
        if (!res.ok) return c.json({ error: `Ollama responded ${res.status}` }, 502);
        return c.json(await res.json());
      } catch (e) {
        return c.json({ error: `Cannot reach Ollama at ${base}: ${e.message}` }, 502);
      }
    });
  }
});

// src/routes/integrations.ts
var integrations_exports = {};
__export(integrations_exports, {
  integrationRoutes: () => integrationRoutes
});
import { Hono as Hono6 } from "hono";
var integrationRoutes, pending;
var init_integrations = __esm({
  "src/routes/integrations.ts"() {
    "use strict";
    integrationRoutes = new Hono6();
    pending = /* @__PURE__ */ new Map();
    integrationRoutes.post("/oauth/start", async (c) => {
      const { provider, scopes = [] } = await c.req.json();
      const state = Math.random().toString(36).slice(2);
      pending.set(state, { provider, createdAt: Date.now() });
      return c.json({ state, provider, scopes, note: "Authorize via the localhost callback." });
    });
    integrationRoutes.get("/oauth/callback", (c) => {
      const state = c.req.query("state");
      if (!state || !pending.has(state)) return c.json({ error: "Unknown or expired OAuth state" }, 400);
      const info = pending.get(state);
      pending.delete(state);
      return c.json({ ok: true, provider: info.provider, note: "Token handed to the local encrypted vault." });
    });
  }
});

// src/routes/resources.ts
var resources_exports = {};
__export(resources_exports, {
  resourceRoutes: () => resourceRoutes
});
import { existsSync as existsSync3, statSync as statSync3 } from "node:fs";
import { join as join3 } from "node:path";
import { Hono as Hono7 } from "hono";
function resourceRoutes(rt) {
  const r = new Hono7();
  r.get("/resources", (c) => {
    const mem2 = process.memoryUsage();
    const dbFile = rt.dbPath;
    return c.json({
      ok: true,
      process: {
        rssMB: Math.round(mem2.rss / 1048576),
        heapMB: Math.round(mem2.heapUsed / 1048576),
        uptimeSec: Math.round(process.uptime()),
        node: process.version
      },
      dataDir: {
        path: rt.dataDir,
        totalMB: +(dirSize(rt.dataDir) / 1048576).toFixed(1)
      },
      db: {
        ...dbStats(),
        sizeMB: existsSync3(dbFile) ? +(statSync3(dbFile).size / 1048576).toFixed(2) : 0
      },
      cacheMB: +(dirSize(join3(rt.dataDir, "cache")) / 1048576).toFixed(1),
      profile: rt.profile,
      caps: rt.caps,
      profiles: Object.fromEntries(Object.entries(PROFILES).map(([k, v]) => [k, { description: v.description }]))
    });
  });
  r.get("/config", (c) => c.json({
    ok: true,
    port: rt.port,
    dataDir: rt.dataDir,
    profile: rt.profile,
    caps: rt.caps,
    frontendServed: !!rt.frontendDist
  }));
  r.post("/config", async (c) => {
    const body = await c.req.json().catch(() => ({}));
    if (body.profile && body.profile in PROFILES) {
      const profile = body.profile;
      rt.profile = profile;
      rt.caps = PROFILES[profile];
      saveConfig(rt.dataDir, { profile });
      return c.json({ ok: true, profile, caps: rt.caps });
    }
    return c.json({ ok: false, error: "Unknown profile" }, 400);
  });
  return r;
}
var init_resources = __esm({
  async "src/routes/resources.ts"() {
    "use strict";
    await init_db();
    init_runtime();
  }
});

// src/routes/fs.ts
var fs_exports = {};
__export(fs_exports, {
  fsRoutes: () => fsRoutes
});
import { mkdir, readFile, readdir, stat, writeFile } from "node:fs/promises";
import { dirname, join as join4, resolve as resolve2 } from "node:path";
import { Hono as Hono8 } from "hono";
function fsRoutes(rt) {
  const r = new Hono8();
  const root = resolve2(join4(rt.dataDir, "files"));
  const safePath = (rel) => {
    if (!rel || rel.startsWith("/") || rel.includes("..")) return null;
    const abs = resolve2(join4(root, rel));
    return abs.startsWith(root + "/") || abs === root ? abs : null;
  };
  r.get("/fs/read", async (c) => {
    const rel = c.req.query("path") ?? "";
    const abs = safePath(rel);
    if (!abs) return c.text("Path must stay inside the Research Engine files folder.", 400);
    try {
      return c.text(await readFile(abs, "utf8"));
    } catch {
      return c.text("File not found.", 404);
    }
  });
  r.post("/fs/write", async (c) => {
    let body;
    try {
      body = await c.req.json();
    } catch {
      return c.text("Invalid JSON body.", 400);
    }
    const abs = safePath(body.path ?? "");
    if (!abs) return c.text("Path must stay inside the Research Engine files folder.", 400);
    if (typeof body.content !== "string") return c.text("Missing content.", 400);
    if (body.content.length > 2e6) return c.text("Content too large (2 MB limit).", 413);
    await mkdir(dirname(abs), { recursive: true });
    await writeFile(abs, body.content, "utf8");
    return c.json({ ok: true, path: body.path });
  });
  r.get("/fs/read-bin", async (c) => {
    const rel = c.req.query("path") ?? "";
    const abs = safePath(rel);
    if (!abs) return c.text("Path must stay inside the Research Engine files folder.", 400);
    try {
      const buf = await readFile(abs);
      const ext = abs.toLowerCase();
      const type = ext.endsWith(".pdf") ? "application/pdf" : ext.endsWith(".docx") ? "application/vnd.openxmlformats-officedocument.wordprocessingml.document" : "application/octet-stream";
      return c.body(new Uint8Array(buf), 200, { "content-type": type });
    } catch {
      return c.text("File not found.", 404);
    }
  });
  r.get("/fs/list", async (c) => {
    await mkdir(root, { recursive: true });
    let entries = [];
    try {
      const list = await readdir(root, { withFileTypes: true });
      entries = await Promise.all(list.map(async (e) => {
        if (e.name.startsWith(".")) return null;
        const dir = e.isDirectory();
        let size = 0;
        if (!dir) {
          try {
            size = (await stat(join4(root, e.name))).size;
          } catch {
          }
        }
        return { name: e.name, dir, size };
      })).then((a) => a.filter(Boolean));
      entries.sort((x, y) => Number(y.dir) - Number(x.dir) || x.name.localeCompare(y.name));
    } catch {
    }
    return c.json({ root, files: entries });
  });
  r.post("/fs/upload", async (c) => {
    let body;
    try {
      body = await c.req.json();
    } catch {
      return c.text("Invalid JSON body.", 400);
    }
    const name = (body.name ?? "").replace(/[\\/]/g, "_").trim();
    if (!name || name.startsWith(".")) return c.text("Missing file name.", 400);
    if (typeof body.dataBase64 !== "string") return c.text("Missing dataBase64.", 400);
    const buf = Buffer.from(body.dataBase64, "base64");
    if (buf.length > 8 * 1024 * 1024) return c.text("File too large (8 MB limit).", 413);
    const abs = safePath(name);
    if (!abs) return c.text("File name must stay inside the Research Engine files folder.", 400);
    await mkdir(dirname(abs), { recursive: true });
    await writeFile(abs, buf);
    return c.json({ ok: true, path: name, size: buf.length });
  });
  return r;
}
var init_fs = __esm({
  "src/routes/fs.ts"() {
    "use strict";
  }
});

// src/routes/providers.ts
var providers_exports = {};
__export(providers_exports, {
  providerRoutes: () => providerRoutes
});
import { Hono as Hono9 } from "hono";
async function discover(kind, base, key, timeout) {
  const t0 = Date.now();
  try {
    if (kind === "ollama") {
      const res2 = await fetch(`${base}/api/tags`, { signal: AbortSignal.timeout(timeout) });
      if (!res2.ok) return { error: `Ollama responded ${res2.status}`, ms: Date.now() - t0 };
      const json2 = await res2.json();
      return { models: (json2.models ?? []).map((m) => String(m.name)), ms: Date.now() - t0 };
    }
    const headers = {
      // NVIDIA NIM UA-dialect: its gateways 403 generic user-agents.
      "user-agent": base.includes("api.nvidia.com") || kind === "nim" ? "NVIDIA-NIM-Client/1.0" : "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
      accept: "application/json"
    };
    if (kind === "anthropic") {
      headers["x-api-key"] = key;
      headers["anthropic-version"] = "2023-06-01";
    } else if (kind === "gemini") {
      headers["x-goog-api-key"] = key;
    } else if (key) {
      headers.authorization = `Bearer ${key}`;
    }
    const res = await fetch(`${base}/models`, { headers, signal: AbortSignal.timeout(timeout) });
    if (!res.ok) {
      let msg = `Provider responded ${res.status}`;
      try {
        const j = await res.json();
        msg = j?.error?.message ?? j?.detail ?? j?.message ?? msg;
      } catch {
      }
      if (res.status === 403 && (base.includes("api.nvidia.com") || kind === "nim")) {
        msg += " \u2014 NVIDIA may allow model listing while blocking inference. Check Public API Endpoints access, model terms, key status, and current model availability.";
      }
      return { error: maskSecrets(msg), ms: Date.now() - t0 };
    }
    const json = await res.json();
    if (kind === "gemini") {
      const models2 = (json.models ?? []).filter((m) => Array.isArray(m?.supportedGenerationMethods) && m.supportedGenerationMethods.includes("generateContent")).map((m) => String(m.name ?? "").replace(/^models\//, "")).filter(Boolean);
      return { models: models2, ms: Date.now() - t0 };
    }
    const models = (json.data ?? []).map((m) => String(m.id ?? m.name)).filter(Boolean);
    return { models, ms: Date.now() - t0 };
  } catch (e) {
    const msg = e?.name === "TimeoutError" || e?.name === "AbortError" ? `Timed out after ${Math.round(timeout / 1e3)}s` : e?.message ?? "Network error";
    return { error: msg, ms: Date.now() - t0 };
  }
}
function args(c) {
  const kind = c.req.query("kind") ?? "openai";
  const base = (c.req.query("base") ?? "").replace(/\/+$/, "");
  const key = c.req.header("x-re-key") ?? "";
  return { kind, base, key };
}
var providerRoutes, MODELS_TIMEOUT_MS, TEST_TIMEOUT_MS;
var init_providers = __esm({
  "src/routes/providers.ts"() {
    "use strict";
    init_secrets();
    providerRoutes = new Hono9();
    MODELS_TIMEOUT_MS = 8e3;
    TEST_TIMEOUT_MS = 6e3;
    providerRoutes.get("/providers/models", async (c) => {
      const { kind, base, key } = args(c);
      if (!base) return c.json({ error: "base is required" }, 400);
      const out = await discover(kind, base, key, MODELS_TIMEOUT_MS);
      if (out.error) return c.json(out, 502);
      return c.json(out);
    });
    providerRoutes.get("/providers/test", async (c) => {
      const { kind, base, key } = args(c);
      if (!base) return c.json({ error: "base is required" }, 400);
      const out = await discover(kind, base, key, TEST_TIMEOUT_MS);
      if (out.error) return c.json(out, 502);
      return c.json({ ms: out.ms });
    });
  }
});

// src/routes/ide.ts
var ide_exports = {};
__export(ide_exports, {
  ideRoutes: () => ideRoutes
});
import { mkdir as mkdir2, readFile as readFile2, readdir as readdir2, rm, stat as stat2, writeFile as writeFile2, rename } from "node:fs/promises";
import { existsSync as existsSync4 } from "node:fs";
import { join as join5, resolve as resolve3, dirname as dirname2 } from "node:path";
import { spawn, spawnSync } from "node:child_process";
import { randomUUID } from "node:crypto";
import { Hono as Hono10 } from "hono";
function scrubbedEnv() {
  const out = {};
  for (const [k, v] of Object.entries(process.env)) {
    if (/key|token|secret|passw|credential|auth/i.test(k)) continue;
    if (typeof v === "string") out[k] = v;
  }
  return out;
}
function ideRoutes(rt) {
  const r = new Hono10();
  const projectsRoot = resolve3(join5(rt.dataDir, "projects"));
  mkdir2(projectsRoot, { recursive: true }).catch(() => {
  });
  const safeName = (name) => {
    const normalized = String(name ?? "").trim().replace(/\s+/g, " ");
    return /^[\p{L}\p{N}][\p{L}\p{N} _.-]{0,63}$/u.test(normalized) ? normalized : null;
  };
  const projectDir = (name) => {
    const n = safeName(name);
    if (!n) return null;
    const abs = resolve3(join5(projectsRoot, n));
    return abs.startsWith(projectsRoot + "/") ? abs : null;
  };
  const safeRel = (dir, rel) => {
    if (!rel || rel.startsWith("/") || rel.includes("..")) return null;
    const abs = resolve3(join5(dir, rel));
    return abs.startsWith(dir + "/") ? abs : null;
  };
  r.get("/ide/projects", async (c) => {
    await mkdir2(projectsRoot, { recursive: true });
    const out = [];
    for (const e of await readdir2(projectsRoot, { withFileTypes: true })) {
      if (!e.isDirectory() || e.name.startsWith(".")) continue;
      const dir = join5(projectsRoot, e.name);
      let files = 0, size = 0;
      const walk = async (d, depth) => {
        if (depth > 6) return;
        for (const f of await readdir2(d, { withFileTypes: true })) {
          if (f.name === "node_modules" || f.name === ".git" || f.name.startsWith(".")) continue;
          const p = join5(d, f.name);
          if (f.isDirectory()) await walk(p, depth + 1);
          else {
            files++;
            try {
              size += (await stat2(p)).size;
            } catch {
            }
          }
        }
      };
      await walk(dir, 0).catch(() => {
      });
      let mtime = 0;
      try {
        mtime = (await stat2(dir)).mtimeMs;
      } catch {
      }
      out.push({ name: e.name, files, size, mtime, git: existsSync4(join5(dir, ".git")) });
    }
    return c.json({ projects: out.sort((a, b) => b.mtime - a.mtime) });
  });
  r.post("/ide/projects", async (c) => {
    let body;
    try {
      body = await c.req.json();
    } catch {
      return c.json({ error: "Invalid JSON body." }, 400);
    }
    const dir = projectDir(body.name ?? "");
    if (!dir) return c.json({ error: "Project name must be 1-64 chars: letters, numbers, spaces, dash, dot, underscore." }, 400);
    if (existsSync4(dir)) return c.json({ error: "A project with this name already exists." }, 409);
    await mkdir2(dir, { recursive: true });
    for (const [rel, content] of Object.entries(body.files ?? {})) {
      const abs = safeRel(dir, rel);
      if (!abs || typeof content !== "string" || content.length > 5e5) continue;
      await mkdir2(dirname2(abs), { recursive: true });
      await writeFile2(abs, content, "utf8");
    }
    return c.json({ ok: true, name: body.name });
  });
  r.delete("/ide/projects/:name", async (c) => {
    const dir = projectDir(c.req.param("name"));
    if (!dir || !existsSync4(dir)) return c.json({ error: "Project not found." }, 404);
    await rm(dir, { recursive: true, force: true });
    return c.json({ ok: true });
  });
  r.post("/ide/import", async (c) => {
    let body;
    try {
      body = await c.req.json();
    } catch {
      return c.json({ error: "Invalid JSON body." }, 400);
    }
    const dir = projectDir(body.name ?? "");
    if (!dir) return c.json({ error: "Invalid project name." }, 400);
    if (existsSync4(dir)) return c.json({ error: "A project with this name already exists." }, 409);
    const buf = Buffer.from(body.dataBase64 ?? "", "base64");
    if (!buf.length || buf.length > IMPORT_CAP) return c.json({ error: "Archive missing or larger than 24 MB." }, 413);
    const fn = (body.fileName ?? "project.zip").toLowerCase();
    const isZip = fn.endsWith(".zip");
    const isTar = fn.endsWith(".tar.gz") || fn.endsWith(".tgz") || fn.endsWith(".tar");
    if (!isZip && !isTar) return c.json({ error: "Upload a .zip, .tar.gz or .tgz archive." }, 400);
    const tmp = join5(projectsRoot, `.import-${randomUUID()}`);
    await mkdir2(tmp, { recursive: true });
    const archive = join5(tmp, isZip ? "up.zip" : "up.tar.gz");
    try {
      await writeFile2(archive, buf);
      const res = isZip ? spawnSync("unzip", ["-q", "-o", archive, "-d", tmp], { timeout: 6e4 }) : spawnSync("tar", ["-xf", archive, "-C", tmp], { timeout: 6e4 });
      if (res.status !== 0) return c.json({ error: "Could not extract the archive (it may be corrupted or password-protected)." }, 400);
      await rm(archive, { force: true });
      let entries = (await readdir2(tmp)).filter((n) => !n.startsWith("."));
      if (entries.length === 1 && (await stat2(join5(tmp, entries[0]))).isDirectory()) {
        const inner = join5(tmp, entries[0]);
        for (const f of await readdir2(inner)) await rename(join5(inner, f), join5(tmp, f));
        await rm(inner, { force: true });
      }
      await rename(tmp, dir);
      return c.json({ ok: true, name: body.name });
    } catch (e) {
      await rm(tmp, { recursive: true, force: true }).catch(() => {
      });
      return c.json({ error: String(e?.message ?? e) }, 500);
    }
  });
  r.get("/ide/tree", async (c) => {
    const dir = projectDir(c.req.query("project") ?? "");
    if (!dir || !existsSync4(dir)) return c.json({ error: "Project not found." }, 404);
    const SKIP = /* @__PURE__ */ new Set(["node_modules", ".git", "dist", "build", ".next", "__pycache__", ".venv"]);
    const walk = async (d, rel, depth) => {
      if (depth > 8) return [];
      const out = [];
      for (const e of await readdir2(d, { withFileTypes: true })) {
        if (SKIP.has(e.name)) continue;
        const p = join5(d, e.name);
        const rp = rel ? `${rel}/${e.name}` : e.name;
        if (e.isDirectory()) out.push({ name: e.name, path: rp, dir: true, children: await walk(p, rp, depth + 1) });
        else out.push({ name: e.name, path: rp, dir: false });
      }
      return out.sort((a, b) => Number(b.dir) - Number(a.dir) || a.name.localeCompare(b.name));
    };
    return c.json({ tree: await walk(dir, "", 0) });
  });
  r.get("/ide/file", async (c) => {
    const dir = projectDir(c.req.query("project") ?? "");
    const abs = dir ? safeRel(dir, c.req.query("path") ?? "") : null;
    if (!abs) return c.json({ error: "Path must stay inside the project." }, 400);
    try {
      const st = await stat2(abs);
      if (st.size > 1e6) return c.json({ error: "File too large to edit here (1 MB limit)." }, 413);
      return c.json({ content: await readFile2(abs, "utf8") });
    } catch {
      return c.json({ error: "File not found." }, 404);
    }
  });
  r.post("/ide/file", async (c) => {
    let body;
    try {
      body = await c.req.json();
    } catch {
      return c.json({ error: "Invalid JSON body." }, 400);
    }
    const dir = projectDir(body.project ?? "");
    const abs = dir ? safeRel(dir, body.path ?? "") : null;
    if (!abs) return c.json({ error: "Path must stay inside the project." }, 400);
    if (typeof body.content !== "string" || body.content.length > 1e6) return c.json({ error: "Content missing or over 1 MB." }, 413);
    await mkdir2(dirname2(abs), { recursive: true });
    await writeFile2(abs, body.content, "utf8");
    return c.json({ ok: true });
  });
  r.post("/ide/exec", async (c) => {
    let body;
    try {
      body = await c.req.json();
    } catch {
      return c.json({ error: "Invalid JSON body." }, 400);
    }
    const dir = projectDir(body.project ?? "");
    const command = (body.command ?? "").trim();
    if (!dir || !existsSync4(dir)) return c.json({ error: "Project not found." }, 404);
    if (!command || command.length > 2e3) return c.json({ error: "Empty or oversized command." }, 400);
    const denied = DENY.find((re) => re.test(command));
    if (denied) return c.json({ blocked: true, reason: "This command matches a hard safety rule and can never run from Research Engine." }, 200);
    const guarded = NEEDS_CONFIRM.find((re) => re.test(command));
    if (guarded && !body.confirmed) return c.json({ requiresConfirm: true, reason: "This command modifies files, installs packages, or touches git history. Review and approve it." }, 200);
    const timeout = Math.min(body.timeoutMs ?? EXEC_TIMEOUT_MS, EXEC_TIMEOUT_MS);
    const t0 = Date.now();
    const out = await new Promise((res) => {
      const child = spawn("/bin/sh", ["-c", command], { cwd: dir, env: scrubbedEnv(), timeout });
      let stdout = "", stderr = "", timedOut = false;
      const to = setTimeout(() => {
        timedOut = true;
        child.kill("SIGKILL");
      }, timeout);
      child.stdout.on("data", (d) => {
        if (stdout.length < OUTPUT_CAP) stdout += d.toString();
      });
      child.stderr.on("data", (d) => {
        if (stderr.length < OUTPUT_CAP) stderr += d.toString();
      });
      child.on("close", (code) => {
        clearTimeout(to);
        res({ exit: code, stdout, stderr, timedOut });
      });
      child.on("error", (e) => {
        clearTimeout(to);
        res({ exit: -1, stdout, stderr: String(e), timedOut });
      });
    });
    console.log(`[re] ide exec [${body.project}] exit=${out.exit} ${command.slice(0, 100)}`);
    return c.json({ ...out, ms: Date.now() - t0, stdout: out.stdout.slice(0, OUTPUT_CAP), stderr: out.stderr.slice(0, OUTPUT_CAP), truncated: out.stdout.length >= OUTPUT_CAP || out.stderr.length >= OUTPUT_CAP });
  });
  r.get("/ide/git", async (c) => {
    const dir = projectDir(c.req.query("project") ?? "");
    if (!dir || !existsSync4(dir)) return c.json({ error: "Project not found." }, 404);
    const ALLOWED = {
      status: ["status", "--porcelain=v1", "-b"],
      log: ["log", "--oneline", "-30"],
      diff: ["diff", "--stat"],
      branches: ["branch", "-a"],
      remote: ["remote", "-v"]
    };
    const op = c.req.query("op") ?? "status";
    const args2 = ALLOWED[op];
    if (!args2) return c.json({ error: "Unknown git op." }, 400);
    if (!existsSync4(join5(dir, ".git"))) return c.json({ norepo: true });
    const res = spawnSync("git", args2, { cwd: dir, env: scrubbedEnv(), timeout: 15e3, maxBuffer: 2 * 1024 * 1024 });
    return c.json({ exit: res.status, stdout: (res.stdout ?? "").toString().slice(0, OUTPUT_CAP), stderr: (res.stderr ?? "").toString().slice(0, 4e3) });
  });
  r.post("/ide/git", async (c) => {
    let body;
    try {
      body = await c.req.json();
    } catch {
      return c.json({ error: "Invalid JSON body." }, 400);
    }
    const dir = projectDir(body.project ?? "");
    if (!dir || !existsSync4(dir)) return c.json({ error: "Project not found." }, 404);
    const run = (args2) => {
      const res = spawnSync("git", args2, { cwd: dir, env: scrubbedEnv(), timeout: 15e3, maxBuffer: 2 * 1024 * 1024 });
      return { exit: res.status, stdout: (res.stdout ?? "").toString().slice(0, OUTPUT_CAP), stderr: (res.stderr ?? "").toString().slice(0, 4e3) };
    };
    if (body.op === "init") return c.json(run(["init"]));
    if (!existsSync4(join5(dir, ".git"))) return c.json({ error: "Not a git repository." }, 400);
    if (body.op === "add") return c.json(run(["add", "-A"]));
    if (body.op === "commit") {
      const msg = (body.message ?? "").trim().slice(0, 500);
      if (!msg) return c.json({ error: "Commit message required." }, 400);
      if (!body.confirmed) return c.json({ requiresConfirm: true, reason: "Commit staged changes to local git history." });
      run(["add", "-A"]);
      const res = spawnSync("git", [
        "-c",
        "user.name=Research Engine",
        "-c",
        "user.email=research-engine@local",
        "commit",
        "-m",
        msg
      ], { cwd: dir, env: scrubbedEnv(), timeout: 15e3, maxBuffer: 2 * 1024 * 1024 });
      return c.json({ exit: res.status, stdout: (res.stdout ?? "").toString().slice(0, OUTPUT_CAP), stderr: (res.stderr ?? "").toString().slice(0, 4e3) });
    }
    return c.json({ error: "Unknown git op." }, 400);
  });
  return r;
}
var EXEC_TIMEOUT_MS, OUTPUT_CAP, IMPORT_CAP, DENY, NEEDS_CONFIRM;
var init_ide = __esm({
  "src/routes/ide.ts"() {
    "use strict";
    EXEC_TIMEOUT_MS = 6e4;
    OUTPUT_CAP = 2e5;
    IMPORT_CAP = 24 * 1024 * 1024;
    DENY = [
      /\brm\s+(-[a-z]*\s+)*(-[a-z]*\s+)*\/(\s|$)/,
      // rm -rf /
      /\brm\s+-[a-z]*r[a-z]*\s+~\/?\s*($|;|&|\|)/,
      // rm -rf ~
      /\bsudo\b/,
      /\bsu\s+-/,
      /doas\b/,
      /\bmkfs\b/,
      /\bdd\s+if=/,
      /\bfdisk\b/,
      /\bparted\b/,
      /:\(\)\s*\{\s*:\|:&\s*\}\s*;\s*:/,
      // fork bomb
      /\bshutdown\b/,
      /\breboot\b/,
      /\bhalt\b/,
      /\bpoweroff\b/,
      /\binit\s+0/,
      /\bchmod\s+(-R\s+)?777\s+\//,
      /\bchown\s+-R\s+[^\s]+\s+\//,
      /\/dev\/(sd[a-z]|nvme|disk)/,
      /\b(curl|wget)\b[^\n|]*\|\s*(sudo\s+)?(ba)?sh/,
      // pipe-to-shell
      /\beval\s+.*\b(curl|wget)\b/,
      /\bbase64\s+(-d|--decode)[^\n]*\|\s*(ba)?sh/,
      /\bcrontab\b/,
      /\bat\s+-f/,
      /\bsystemctl\b/,
      /\blaunchctl\b/,
      /\bkill\s+(-9\s+)?1\b/,
      /\bkillall\b/,
      /\bnpm\s+publish\b/,
      /\bcargo\s+publish\b/,
      /\btwine\s+upload\b/,
      /\bgit\s+push\s+(--force\b|.*--force\b|-f\b)/,
      /\biptables\b/,
      /\bufw\b/,
      /\bifconfig\b.*\bdown\b/,
      /\broute\s+(del|add)/,
      /\buseradd\b/,
      /\buserdel\b/,
      /\bpasswd\b/,
      /\bvisudo\b/,
      /\bformat\s+[a-z]:/i,
      /\bdel\s+\/[sfq]+\s+[a-z]:\\/i,
      /\brmdir\s+\/s/i,
      /\breg\s+(delete|add)\b/i,
      /\bnet\s+user\b/i,
      />~?\/(etc|usr|bin|boot|proc|sys)\//,
      /\bssh\b.*-[iLDR]\b/,
      /\bscp\b/,
      /\brsync\b/,
      /\bnc\b.*-[elp]/,
      /\bnetcat\b/,
      /\btelnetd\b/,
      /\bminer\b/i,
      /xmrig/i
    ];
    NEEDS_CONFIRM = [
      /\brm\b/,
      /\bmv\b/,
      /\bgit\s+(push|reset|clean|checkout\s+--|restore)\b/,
      /\b(npm|yarn|pnpm|bun)\s+(install|add|remove|update|run\s+build)\b/,
      /\bpip3?\s+install\b/,
      /\bdocker\b/,
      /\bkubectl\b/,
      /\bgit\s+commit\b/,
      /\bmkdir\b/,
      /\btouch\b/,
      /\bchmod\b/,
      /\bnpx\b/,
      /\bmake\b/
    ];
  }
});

// src/routes/connectors.ts
var connectors_exports = {};
__export(connectors_exports, {
  connectorRoutes: () => connectorRoutes
});
import { mkdir as mkdir3, readFile as readFile3, readdir as readdir3, rm as rm2, writeFile as writeFile3 } from "node:fs/promises";
import { join as join6, resolve as resolve4 } from "node:path";
import { randomUUID as randomUUID2 } from "node:crypto";
import { Hono as Hono11 } from "hono";
function connectorRoutes(rt) {
  const r = new Hono11();
  const root = resolve4(join6(rt.dataDir, "connectors"));
  const boxDir = (box) => join6(root, box);
  const isBox = (b) => BOXES.includes(b);
  const listItems = async (box) => {
    await mkdir3(boxDir(box), { recursive: true });
    const out = [];
    for (const f of await readdir3(boxDir(box))) {
      if (!f.endsWith(".json")) continue;
      try {
        out.push(JSON.parse(await readFile3(join6(boxDir(box), f), "utf8")));
      } catch {
      }
    }
    return out.sort((a, b) => (b.addedAt ?? b.date ?? 0) - (a.addedAt ?? a.date ?? 0));
  };
  r.get("/connectors/list", async (c) => {
    const box = c.req.query("box") ?? "";
    if (!isBox(box)) return c.json({ error: "Unknown connector box." }, 400);
    const items = await listItems(box);
    return c.json({ box, items: items.map(({ dataBase64, body, notes, ...rest }) => ({ ...rest, preview: (body ?? notes ?? "").slice(0, 160) })) });
  });
  r.get("/connectors/item", async (c) => {
    const box = c.req.query("box") ?? "";
    const id = (c.req.query("id") ?? "").replace(/[^a-zA-Z0-9_-]/g, "");
    if (!isBox(box) || !id) return c.json({ error: "Bad request." }, 400);
    try {
      const item = JSON.parse(await readFile3(join6(boxDir(box), `${id}.json`), "utf8"));
      if (box !== "drive") delete item.dataBase64;
      return c.json({ item });
    } catch {
      return c.json({ error: "Item not found." }, 404);
    }
  });
  r.get("/connectors/search", async (c) => {
    const q = (c.req.query("q") ?? "").toLowerCase();
    const box = c.req.query("box") ?? "";
    const boxes = isBox(box) ? [box] : ["drive", "mail", "calendar"];
    const hits = [];
    for (const b of boxes) {
      for (const item of await listItems(b)) {
        const hay = JSON.stringify({ ...item, dataBase64: void 0 }).toLowerCase();
        if (!q || hay.includes(q)) hits.push({ box: b, id: item.id, title: item.name ?? item.subject ?? item.title, snippet: (item.body ?? item.notes ?? item.text ?? "").slice(0, 200), date: item.date ?? item.addedAt });
      }
    }
    return c.json({ q, hits: hits.slice(0, 40) });
  });
  r.post("/connectors/add", async (c) => {
    let body;
    try {
      body = await c.req.json();
    } catch {
      return c.json({ error: "Invalid JSON body." }, 400);
    }
    const box = body.box;
    if (!isBox(box)) return c.json({ error: "Unknown connector box." }, 400);
    const id = randomUUID2().slice(0, 8);
    let item;
    if (box === "drive" || box === "files") {
      const buf = Buffer.from(body.dataBase64 ?? "", "base64");
      if (buf.length > CAPS[box]) return c.json({ error: "File larger than 8 MB." }, 413);
      if (!buf.length && !String(body.text ?? "").trim()) return c.json({ error: "Provide a file or some text." }, 400);
      item = { id, name: String(body.name ?? "file").slice(0, 200), mime: body.mime ?? (buf.length ? "application/octet-stream" : "text/plain"), text: body.text ?? null, dataBase64: buf.length ? body.dataBase64 : null, addedAt: Date.now() };
    } else if (box === "mail") {
      item = { id, from: body.from ?? "", to: body.to ?? "", subject: String(body.subject ?? "").slice(0, 300), body: String(body.body ?? "").slice(0, CAPS.mail), date: body.date ?? (/* @__PURE__ */ new Date()).toISOString(), read: false, addedAt: Date.now() };
    } else {
      item = { id, title: String(body.title ?? "").slice(0, 300), date: body.date ?? "", time: body.time ?? "", location: body.location ?? "", notes: String(body.notes ?? "").slice(0, CAPS.calendar), attendees: body.attendees ?? [], addedAt: Date.now() };
    }
    await mkdir3(boxDir(box), { recursive: true });
    await writeFile3(join6(boxDir(box), `${id}.json`), JSON.stringify(item));
    return c.json({ ok: true, id });
  });
  r.delete("/connectors/item", async (c) => {
    const box = c.req.query("box") ?? "";
    const id = (c.req.query("id") ?? "").replace(/[^a-zA-Z0-9_-]/g, "");
    if (!isBox(box) || !id) return c.json({ error: "Bad request." }, 400);
    await rm2(join6(boxDir(box), `${id}.json`), { force: true });
    return c.json({ ok: true });
  });
  return r;
}
var BOXES, CAPS;
var init_connectors = __esm({
  "src/routes/connectors.ts"() {
    "use strict";
    BOXES = ["drive", "mail", "calendar", "files"];
    CAPS = { drive: 8 * 1024 * 1024, mail: 512 * 1024, calendar: 256 * 1024, files: 8 * 1024 * 1024 };
  }
});

// src/routes/mcp.ts
var mcp_exports = {};
__export(mcp_exports, {
  mcpRoutes: () => mcpRoutes
});
import { spawn as spawn2 } from "node:child_process";
import { Hono as Hono12 } from "hono";
function scrubServer(s) {
  const command = String(s?.command ?? "").trim();
  if (!command || /[;&|`$]/.test(command)) throw new Error("Invalid MCP command");
  const args2 = Array.isArray(s?.args) ? s.args.map(String).slice(0, 24) : [];
  const env = {};
  if (s?.env && typeof s.env === "object") {
    for (const [k, v] of Object.entries(s.env)) {
      if (/^[A-Za-z_][A-Za-z0-9_]*$/.test(k) && typeof v === "string") env[k] = v;
    }
  }
  return { command, args: args2, env };
}
function mcpRoutes() {
  const r = new Hono12();
  r.post("/mcp/tools", async (c) => {
    let body;
    try {
      body = await c.req.json();
    } catch {
      return c.json({ error: "Invalid JSON body." }, 400);
    }
    const out = [];
    for (const s of body.servers ?? []) {
      let session = null;
      try {
        const { command, args: args2, env } = scrubServer(s);
        session = new McpSession(command, args2, env);
        await session.init();
        const res = await session.request("tools/list", {}, HANDSHAKE_TIMEOUT_MS);
        out.push({ serverId: s.id, serverName: s.name ?? s.id, ok: true, tools: (res?.tools ?? []).map((t) => ({ name: t.name, description: t.description ?? "", inputSchema: t.inputSchema ?? {} })) });
      } catch (e) {
        out.push({ serverId: s.id, serverName: s.name ?? s.id, ok: false, error: String(e?.message ?? e), tools: [] });
      } finally {
        session?.kill();
      }
    }
    return c.json({ servers: out });
  });
  r.post("/mcp/call", async (c) => {
    let body;
    try {
      body = await c.req.json();
    } catch {
      return c.json({ error: "Invalid JSON body." }, 400);
    }
    let session = null;
    try {
      const { command, args: args2, env } = scrubServer(body.server);
      session = new McpSession(command, args2, env);
      await session.init();
      const res = await session.request("tools/call", { name: body.name, arguments: body.arguments ?? {} });
      const text2 = (res?.content ?? []).map((p) => p?.text ?? "").join("\n").slice(0, 1e5);
      return c.json({ ok: !res?.isError, text: text2, isError: !!res?.isError });
    } catch (e) {
      return c.json({ ok: false, isError: true, text: `MCP call failed: ${String(e?.message ?? e)}` }, 200);
    } finally {
      session?.kill();
    }
  });
  return r;
}
var PROTOCOL_VERSION, HANDSHAKE_TIMEOUT_MS, CALL_TIMEOUT_MS, McpSession;
var init_mcp = __esm({
  "src/routes/mcp.ts"() {
    "use strict";
    PROTOCOL_VERSION = "2024-11-05";
    HANDSHAKE_TIMEOUT_MS = 12e3;
    CALL_TIMEOUT_MS = 3e4;
    McpSession = class {
      child;
      buf = "";
      nextId = 1;
      pending = /* @__PURE__ */ new Map();
      dead = false;
      constructor(command, args2, env) {
        this.child = spawn2(command, args2, {
          stdio: ["pipe", "pipe", "pipe"],
          env: { PATH: process.env.PATH ?? "/usr/bin:/bin", HOME: process.env.HOME ?? "", ...env }
        });
        this.child.stdout.on("data", (d) => this.onData(d.toString()));
        this.child.stderr.on("data", () => {
        });
        this.child.on("exit", () => {
          this.dead = true;
          for (const p of this.pending.values()) p.reject(new Error("MCP server exited"));
        });
        this.child.on("error", (e) => {
          this.dead = true;
          for (const p of this.pending.values()) p.reject(e);
        });
      }
      onData(chunk) {
        this.buf += chunk;
        let idx;
        while ((idx = this.buf.indexOf("\n")) >= 0) {
          const line = this.buf.slice(0, idx).trim();
          this.buf = this.buf.slice(idx + 1);
          if (!line) continue;
          try {
            const msg = JSON.parse(line);
            if (msg.id != null && this.pending.has(msg.id)) {
              const p = this.pending.get(msg.id);
              this.pending.delete(msg.id);
              if (msg.error) p.reject(new Error(msg.error?.message ?? "MCP error"));
              else p.resolve(msg.result);
            }
          } catch {
          }
        }
      }
      notify(method, params) {
        if (this.dead) return;
        this.child.stdin.write(JSON.stringify({ jsonrpc: "2.0", method, params }) + "\n");
      }
      request(method, params, timeoutMs = CALL_TIMEOUT_MS) {
        if (this.dead) return Promise.reject(new Error("MCP server not running"));
        const id = this.nextId++;
        return new Promise((resolve5, reject) => {
          const to = setTimeout(() => {
            this.pending.delete(id);
            reject(new Error(`Timed out after ${Math.round(timeoutMs / 1e3)}s`));
          }, timeoutMs);
          this.pending.set(id, {
            resolve: (v) => {
              clearTimeout(to);
              resolve5(v);
            },
            reject: (e) => {
              clearTimeout(to);
              reject(e);
            }
          });
          this.child.stdin.write(JSON.stringify({ jsonrpc: "2.0", id, method, params }) + "\n");
        });
      }
      async init() {
        const caps = await this.request("initialize", {
          protocolVersion: PROTOCOL_VERSION,
          capabilities: {},
          clientInfo: { name: "research-engine", version: "0.15" }
        }, HANDSHAKE_TIMEOUT_MS);
        this.notify("notifications/initialized");
        return caps;
      }
      kill() {
        try {
          this.child.kill("SIGKILL");
        } catch {
        }
      }
    };
  }
});

// src/index.ts
init_runtime();
import { serve } from "@hono/node-server";
import { Hono as Hono13 } from "hono";
import { cors } from "hono/cors";
import { logger } from "hono/logger";

// src/static.ts
import { createReadStream, existsSync as existsSync2, statSync as statSync2 } from "node:fs";
import { Readable } from "node:stream";
import { extname, join as join2, normalize } from "node:path";
var MIME = {
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".mjs": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".json": "application/json",
  ".svg": "image/svg+xml",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".webp": "image/webp",
  ".ico": "image/x-icon",
  ".woff": "font/woff",
  ".woff2": "font/woff2",
  ".ttf": "font/ttf",
  ".map": "application/json",
  ".txt": "text/plain; charset=utf-8",
  ".webmanifest": "application/manifest+json"
};
function staticHandler(root) {
  const indexHtml = join2(root, "index.html");
  return async (c) => {
    const url = new URL(c.req.url);
    let rel = decodeURIComponent(url.pathname).replace(/^\/+/, "");
    rel = normalize(rel).replace(/^(\.\.[/\\])+/, "");
    const file = rel ? join2(root, rel) : indexHtml;
    const target = existsSync2(file) && statSync2(file).isFile() ? file : indexHtml;
    if (!existsSync2(target)) return c.notFound();
    const isIndex = target === indexHtml;
    const headers = {
      "content-type": MIME[extname(target).toLowerCase()] ?? "application/octet-stream",
      "content-length": String(statSync2(target).size)
    };
    if (isIndex) headers["cache-control"] = "no-cache";
    else if (rel.startsWith("assets/")) headers["cache-control"] = "public, max-age=31536000, immutable";
    const rs = createReadStream(target);
    return new Response(Readable.toWeb(rs), { status: 200, headers });
  };
}

// src/index.ts
async function main() {
  const rt = await resolveRuntime(process.argv.slice(2));
  const { healthRoutes: healthRoutes2 } = await init_health().then(() => health_exports);
  const { searchRoutes: searchRoutes2 } = await Promise.resolve().then(() => (init_search(), search_exports));
  const { chatRoutes: chatRoutes2 } = await Promise.resolve().then(() => (init_chat(), chat_exports));
  const { documentRoutes: documentRoutes2 } = await init_documents().then(() => documents_exports);
  const { ollamaRoutes: ollamaRoutes2 } = await Promise.resolve().then(() => (init_ollama(), ollama_exports));
  const { integrationRoutes: integrationRoutes2 } = await Promise.resolve().then(() => (init_integrations(), integrations_exports));
  const { resourceRoutes: resourceRoutes2 } = await init_resources().then(() => resources_exports);
  const { fsRoutes: fsRoutes2 } = await Promise.resolve().then(() => (init_fs(), fs_exports));
  const { providerRoutes: providerRoutes2 } = await Promise.resolve().then(() => (init_providers(), providers_exports));
  const { ideRoutes: ideRoutes2 } = await Promise.resolve().then(() => (init_ide(), ide_exports));
  const { connectorRoutes: connectorRoutes2 } = await Promise.resolve().then(() => (init_connectors(), connectors_exports));
  const { mcpRoutes: mcpRoutes2 } = await Promise.resolve().then(() => (init_mcp(), mcp_exports));
  const app = new Hono13();
  app.use("*", cors());
  app.use("*", logger((msg) => console.log(`[re] ${msg}`)));
  app.route("/api", healthRoutes2);
  app.route("/api", resourceRoutes2(rt));
  app.route("/api", fsRoutes2(rt));
  app.route("/api", ideRoutes2(rt));
  app.route("/api", connectorRoutes2(rt));
  app.route("/api", mcpRoutes2());
  app.route("/api/search", searchRoutes2);
  app.route("/api/chat", chatRoutes2);
  app.route("/api/documents", documentRoutes2);
  app.route("/api/ollama", ollamaRoutes2);
  app.route("/api/integrations", integrationRoutes2);
  app.route("/api", providerRoutes2);
  app.onError((err, c) => {
    return c.json({ error: err.message }, 500);
  });
  if (rt.frontendDist) {
    const handler = staticHandler(rt.frontendDist);
    app.get("*", handler);
  }
  serve({ fetch: app.fetch, port: rt.port, hostname: rt.host }, (info) => {
    console.log(`Research Engine listening on http://${rt.host}:${info.port}`);
    console.log(`  data dir : ${rt.dataDir}`);
    console.log(`  profile  : ${rt.profile} (${rt.caps.floodWorkers} flood worker${rt.caps.floodWorkers > 1 ? "s" : ""}, ${rt.caps.concurrentStreams} concurrent stream${rt.caps.concurrentStreams > 1 ? "s" : ""})`);
    console.log(`  frontend : ${rt.frontendDist ?? "not found \u2014 API only (run `npm run build` in frontend/ for single-process mode)"}`);
    console.log(`  database : ${rt.dbPath}`);
    if (rt.rememberedPort) console.log(`  note     : preferred port was busy \u2014 using ${info.port} (remembered in config.json)`);
  });
}
main().catch((e) => {
  console.error("[re] fatal:", e);
  process.exit(1);
});
