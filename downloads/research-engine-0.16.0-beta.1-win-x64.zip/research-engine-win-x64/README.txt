Research Engine — portable build (win-x64)

Requires Node.js on this machine (https://nodejs.org — LTS recommended;
Node 22.5+ gives built-in persistent storage, older Node runs session-only).

Run:
  research-engine.cmd serve --port 3847

Then open http://127.0.0.1:3847

Data directory: %USERPROFILE%\.research-engine (override with RESEARCH_ENGINE_DATA_DIR)
Profiles: research-engine.cmd serve --profile eco|balanced|performance
