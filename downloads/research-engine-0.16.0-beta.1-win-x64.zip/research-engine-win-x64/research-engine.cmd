@echo off
node "%~dp0server\index.js" serve --frontend-dist "%~dp0frontend-dist" %*
