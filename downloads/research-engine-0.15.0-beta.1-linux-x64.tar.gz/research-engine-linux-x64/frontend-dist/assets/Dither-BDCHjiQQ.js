import{r as a,aI as l,j as o}from"./index-BcS3-tfJ.js";import{C as c,V as n,u as f}from"./react-three-fiber.esm-C8koWjZS.js";const m=`
varying vec2 vUv;
void main() {
  vUv = uv;
  gl_Position = vec4(position.xy, 0.0, 1.0);
}
`,y=`
precision highp float;
varying vec2 vUv;
uniform float uTime;
uniform vec3 uColorA;
uniform vec3 uColorB;
uniform vec3 uColorC;
uniform float uIntensity;

// Compact ordered 8x8 Bayer matrix (classic recursive construction)
float bayer2(vec2 a) {
  a = floor(a);
  return fract(a.x * 0.5 + a.y * a.y * 0.75);
}
float bayer4(vec2 a) { return bayer2(0.5 * a) * 0.25 + bayer2(a); }
float bayer8(vec2 a) { return bayer4(0.5 * a) * 0.25 + bayer2(a); }

void main() {
  float t = uTime * 0.35;
  vec2 uv = vUv;
  float wave =
    sin(uv.x * 7.0 + t) * 0.35 +
    sin(uv.y * 5.0 - t * 0.8) * 0.3 +
    sin((uv.x + uv.y) * 9.0 + t * 0.5) * 0.2;
  float v = smoothstep(-0.8, 0.8, wave + (uv.y - 0.5) * 0.6);

  float b = bayer8(gl_FragCoord.xy) - 0.5;
  float levels = 3.0;
  float q = clamp(floor(v * levels + b) / (levels - 1.0), 0.0, 1.0);

  vec3 col = q < 0.5
    ? mix(uColorA, uColorB, smoothstep(0.0, 0.5, q))
    : mix(uColorB, uColorC, smoothstep(0.5, 1.0, q));

  gl_FragColor = vec4(col, uIntensity);
}
`;function p({a:e,b:t,c:s,intensity:i}){const r=a.useRef(null),u=a.useMemo(()=>({uTime:{value:0},uColorA:{value:new n(...e)},uColorB:{value:new n(...t)},uColorC:{value:new n(...s)},uIntensity:{value:i}}),[e.join(","),t.join(","),s.join(","),i]);return f((x,v)=>{r.current&&(r.current.uniforms.uTime.value+=v)}),o.jsxs("mesh",{children:[o.jsx("planeGeometry",{args:[2,2]}),o.jsx("shaderMaterial",{ref:r,vertexShader:m,fragmentShader:y,uniforms:u,transparent:!0,depthTest:!1,depthWrite:!1})]})}function g({theme:e,intensity:t=.5}){const s=a.useMemo(()=>e.bg,[e]),i=a.useMemo(()=>l(e.bg,e.primary,e.isLight?.4:.35),[e]),r=a.useMemo(()=>l(e.bg,e.secondary,e.isLight?.32:.28),[e]);return o.jsx("div",{className:"absolute inset-0","aria-hidden":"true",children:o.jsx(c,{gl:{antialias:!1,alpha:!0,powerPreference:"low-power"},camera:{position:[0,0,1]},dpr:[1,1.25],style:{position:"absolute",inset:0},children:o.jsx(p,{a:s,b:i,c:r,intensity:Math.min(1,t+.3)})})})}export{g as default};
