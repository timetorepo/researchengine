var __defProp = Object.defineProperty;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// src/runtime.ts
import { existsSync, mkdirSync, readFileSync, writeFileSync, statSync, readdirSync } from "node:fs";
import { join, resolve } from "node:path";
import { homedir } from "node:os";
import { createServer } from "node:net";
function parseFlags(argv) {
  const f = { serve: argv[0] !== "serve" ? true : true };
  const args2 = argv.filter((a) => a !== "serve");
  for (let i = 0; i < args2.length; i++) {
    const a = args2[i];
    const val = () => args2[++i];
    if (a === "--port") f.port = Number(val());
    else if (a === "--host") f.host = val();
    else if (a === "--data-dir") f.dataDir = val();
    else if (a === "--profile") {
      const p = val();
      if (p in PROFILES) f.profile = p;
    } else if (a === "--frontend-dist") f.frontendDist = val();
    else if (a === "--help" || a === "-h") {
      console.log(`Research Engine \u2014 single-process server

Usage: research-engine serve [options]
  --port <n>          HTTP port (default 3847; auto-picks next free if busy)
  --host <addr>       Bind address (default 127.0.0.1)
  --data-dir <path>   Data directory (default ~/.research-engine)
  --profile <p>       eco | balanced | performance (default balanced)
  --frontend-dist <p> Path to built frontend (default ../frontend/dist)

Environment: RE_PORT, RE_HOST, RESEARCH_ENGINE_DATA_DIR, RE_PROFILE, FRONTEND_DIST`);
      process.exit(0);
    }
  }
  return f;
}
function configPath(dataDir) {
  return join(dataDir, "config.json");
}
function loadConfig(dataDir) {
  try {
    return JSON.parse(readFileSync(configPath(dataDir), "utf8"));
  } catch {
    return {};
  }
}
function saveConfig(dataDir, patch) {
  const merged = { ...loadConfig(dataDir), ...patch };
  writeFileSync(configPath(dataDir), JSON.stringify(merged, null, 2));
  return merged;
}
function ensureDataDir(dataDir) {
  for (const sub of ["", "media", "notebooks", "cache"]) {
    mkdirSync(join(dataDir, sub), { recursive: true });
  }
  if (!existsSync(configPath(dataDir))) writeFileSync(configPath(dataDir), "{}\n");
}
function dirSize(dir) {
  try {
    let total = 0;
    for (const entry of readdirSync(dir, { withFileTypes: true })) {
      const p = join(dir, entry.name);
      if (entry.isDirectory()) total += dirSize(p);
      else if (entry.isFile()) total += statSync(p).size;
    }
    return total;
  } catch {
    return 0;
  }
}
function portFree(port, host) {
  return new Promise((res) => {
    const srv = createServer();
    srv.once("error", () => res(false));
    srv.listen({ port, host, exclusive: true }, () => {
      srv.close(() => res(true));
    });
  });
}
async function pickPort(preferred, host) {
  for (let i = 0; i < 20; i++) {
    if (await portFree(preferred + i, host)) return preferred + i;
  }
  return preferred;
}
async function resolveRuntime(argv) {
  const flags = parseFlags(argv);
  const dataDir = resolve(flags.dataDir ?? process.env.RESEARCH_ENGINE_DATA_DIR ?? join(homedir(), ".research-engine"));
  ensureDataDir(dataDir);
  const saved = loadConfig(dataDir);
  const host = flags.host ?? process.env.RE_HOST ?? "127.0.0.1";
  const envPort = Number(process.env.RE_PORT ?? process.env.PORT ?? "");
  const isDev = import.meta.url.includes("/src/");
  const preferredPort = flags.port ?? (envPort || (isDev ? 8787 : saved.port || 3847));
  const port = await pickPort(preferredPort, host);
  const rememberedPort = port !== preferredPort;
  const profileRaw = flags.profile ?? process.env.RE_PROFILE ?? saved.profile ?? "balanced";
  const profile = profileRaw in PROFILES ? profileRaw : "balanced";
  const candidates = [
    flags.frontendDist,
    process.env.FRONTEND_DIST,
    resolve(import.meta.dirname, "../../frontend/dist"),
    resolve(process.cwd(), "frontend/dist")
  ].filter(Boolean);
  const frontendDist = candidates.find((d) => existsSync(join(d, "index.html"))) ?? null;
  const dbPath2 = process.env.DB_PATH ?? join(dataDir, "db.sqlite");
  process.env.DB_PATH = dbPath2;
  if (rememberedPort && !isDev) saveConfig(dataDir, { port });
  return { port, host, dataDir, profile, caps: PROFILES[profile], frontendDist, dbPath: dbPath2, rememberedPort };
}
var PROFILES;
var init_runtime = __esm({
  "src/runtime.ts"() {
    "use strict";
    PROFILES = {
      eco: {
        floodWorkers: 1,
        searchResults: 5,
        concurrentStreams: 1,
        backgroundIndexing: false,
        description: "1 concurrent stream, smaller retrieval, no background work. Best on \u22648 GB RAM."
      },
      balanced: {
        floodWorkers: 2,
        searchResults: 7,
        concurrentStreams: 2,
        backgroundIndexing: true,
        description: "Normal multi-tab use. Background indexing allowed."
      },
      performance: {
        floodWorkers: 4,
        searchResults: 9,
        concurrentStreams: 4,
        backgroundIndexing: true,
        description: "Parallel agents, faster preloading, larger caches."
      }
    };
  }
});

// src/db/schema.ts
var schema_exports = {};
__export(schema_exports, {
  chats: () => chats,
  citations: () => citations,
  documents: () => documents,
  messages: () => messages,
  skills: () => skills
});
import { sqliteTable, text, integer } from "drizzle-orm/sqlite-core";
var chats, messages, documents, skills, citations;
var init_schema = __esm({
  "src/db/schema.ts"() {
    "use strict";
    chats = sqliteTable("chats", {
      id: text("id").primaryKey(),
      title: text("title").notNull(),
      spaceId: text("space_id"),
      createdAt: integer("created_at").notNull(),
      updatedAt: integer("updated_at").notNull()
    });
    messages = sqliteTable("messages", {
      id: text("id").primaryKey(),
      chatId: text("chat_id").notNull(),
      role: text("role").notNull(),
      content: text("content").notNull(),
      model: text("model"),
      createdAt: integer("created_at").notNull()
    });
    documents = sqliteTable("documents", {
      id: text("id").primaryKey(),
      name: text("name").notNull(),
      kind: text("kind").notNull(),
      text: text("text").notNull(),
      addedAt: integer("added_at").notNull()
    });
    skills = sqliteTable("skills", {
      id: text("id").primaryKey(),
      name: text("name").notNull(),
      json: text("json").notNull()
    });
    citations = sqliteTable("citations", {
      id: text("id").primaryKey(),
      title: text("title").notNull(),
      url: text("url").notNull(),
      collection: text("collection"),
      savedAt: integer("saved_at").notNull()
    });
  }
});

// src/db/index.ts
function dbStats() {
  return sqlite ? { engine, file: process.env.DB_PATH ?? "./research-engine.db" } : { engine: "memory" };
}
var MIGRATION, sqlite, engine, dbPath, mem, db;
var init_db = __esm({
  async "src/db/index.ts"() {
    "use strict";
    init_schema();
    MIGRATION = `
CREATE TABLE IF NOT EXISTS chats (id TEXT PRIMARY KEY, title TEXT, space_id TEXT, created_at INTEGER, updated_at INTEGER);
CREATE TABLE IF NOT EXISTS messages (id TEXT PRIMARY KEY, chat_id TEXT, role TEXT, content TEXT, model TEXT, created_at INTEGER);
CREATE TABLE IF NOT EXISTS documents (id TEXT PRIMARY KEY, name TEXT, kind TEXT, text TEXT, added_at INTEGER);
CREATE TABLE IF NOT EXISTS skills (id TEXT PRIMARY KEY, name TEXT, json TEXT);
CREATE TABLE IF NOT EXISTS citations (id TEXT PRIMARY KEY, title TEXT, url TEXT, collection TEXT, saved_at INTEGER);
`;
    sqlite = null;
    engine = "memory";
    dbPath = process.env.DB_PATH ?? "./research-engine.db";
    try {
      const Database = (await import("better-sqlite3")).default;
      sqlite = new Database(dbPath);
      sqlite.pragma("journal_mode = WAL");
      sqlite.exec(MIGRATION);
      engine = "sqlite (better-sqlite3)";
    } catch {
      try {
        const { DatabaseSync } = await import("node:sqlite");
        sqlite = new DatabaseSync(dbPath);
        sqlite.exec("PRAGMA journal_mode = WAL");
        sqlite.exec(MIGRATION);
        engine = "sqlite (node:sqlite)";
      } catch (e2) {
        console.warn("[re] no SQLite driver available \u2014 using in-memory fallback (data will not survive a restart). (" + e2.message + ")");
      }
    }
    mem = {
      chats: /* @__PURE__ */ new Map(),
      documents: /* @__PURE__ */ new Map()
    };
    db = {
      schema: schema_exports,
      insertChat(chat) {
        if (sqlite) sqlite.prepare("INSERT OR REPLACE INTO chats VALUES (?,?,?,?,?)").run(chat.id, chat.title, chat.spaceId ?? null, chat.createdAt, chat.updatedAt);
        else mem.chats.set(chat.id, chat);
      },
      insertDocument(doc) {
        if (sqlite) sqlite.prepare("INSERT OR REPLACE INTO documents VALUES (?,?,?,?,?)").run(doc.id, doc.name, doc.kind, doc.text, doc.addedAt);
        else mem.documents.set(doc.id, doc);
      },
      listDocuments() {
        if (sqlite) return sqlite.prepare("SELECT id, name, kind, added_at as addedAt FROM documents ORDER BY added_at DESC").all();
        return [...mem.documents.values()];
      }
    };
  }
});

// src/routes/health.ts
var health_exports = {};
__export(health_exports, {
  healthRoutes: () => healthRoutes
});
import { Hono } from "hono";
var healthRoutes;
var init_health = __esm({
  async "src/routes/health.ts"() {
    "use strict";
    await init_db();
    healthRoutes = new Hono();
    healthRoutes.get(
      "/health",
      (c) => c.json({ ok: true, service: "research-engine-backend", time: (/* @__PURE__ */ new Date()).toISOString(), db: dbStats() })
    );
  }
});

// src/services/search/adapters.ts
async function searchSearxng(base, q) {
  const res = await fetch(`${base.replace(/\/$/, "")}/search?q=${encodeURIComponent(q)}&format=json`);
  if (!res.ok) throw new Error(`SearXNG responded ${res.status}`);
  const json = await res.json();
  return (json.results ?? []).slice(0, 8).map((r) => ({
    title: r.title,
    url: r.url,
    snippet: r.content ?? "",
    domain: new URL(r.url).hostname
  }));
}
async function searchBrave(q) {
  const key = process.env.BRAVE_API_KEY;
  if (!key) throw new Error("BRAVE_API_KEY is not set on the backend");
  const res = await fetch(`https://api.search.brave.com/res/v1/web/search?q=${encodeURIComponent(q)}`, {
    headers: { "X-Subscription-Token": key, accept: "application/json" }
  });
  if (!res.ok) throw new Error(`Brave responded ${res.status}`);
  const json = await res.json();
  return (json.web?.results ?? []).slice(0, 8).map((r) => ({
    title: r.title,
    url: r.url,
    snippet: r.description ?? "",
    domain: new URL(r.url).hostname
  }));
}
async function searchSerper(q) {
  const key = process.env.SERPER_API_KEY;
  if (!key) throw new Error("SERPER_API_KEY is not set on the backend");
  const res = await fetch("https://google.serper.dev/search", {
    method: "POST",
    headers: { "X-API-KEY": key, "content-type": "application/json" },
    body: JSON.stringify({ q })
  });
  if (!res.ok) throw new Error(`Serper responded ${res.status}`);
  const json = await res.json();
  return (json.organic ?? []).slice(0, 8).map((r) => ({
    title: r.title,
    url: r.link,
    snippet: r.snippet ?? "",
    domain: new URL(r.link).hostname
  }));
}
async function searchTavily(q) {
  const key = process.env.TAVILY_API_KEY;
  if (!key) throw new Error("TAVILY_API_KEY is not set on the backend");
  const res = await fetch("https://api.tavily.com/search", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ api_key: key, query: q, max_results: 8 })
  });
  if (!res.ok) throw new Error(`Tavily responded ${res.status}`);
  const json = await res.json();
  return (json.results ?? []).map((r) => ({
    title: r.title,
    url: r.url,
    snippet: r.content ?? "",
    domain: new URL(r.url).hostname
  }));
}
async function searchDdg(q) {
  const res = await fetch(`https://html.duckduckgo.com/html/?q=${encodeURIComponent(q)}`, {
    headers: { "user-agent": "Mozilla/5.0 (Research Engine)" }
  });
  if (!res.ok) throw new Error(`DuckDuckGo responded ${res.status}`);
  const html = await res.text();
  const out = [];
  const re = /<a[^>]+class="result__a"[^>]+href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/g;
  let m;
  while ((m = re.exec(html)) && out.length < 8) {
    const url = decodeURIComponent(m[1].replace(/^.*uddg=/, "").replace(/&rut=.*$/, ""));
    const title = m[2].replace(/<[^>]+>/g, "").trim();
    if (url.startsWith("http")) out.push({ title, url, snippet: "", domain: new URL(url).hostname });
  }
  return out;
}
function searchDemo(q) {
  const domains = ["arxiv.org", "nature.com", "wikipedia.org", "acm.org", "ncbi.nlm.nih.gov"];
  return domains.map((d, i) => ({
    title: `${q} \u2014 result ${i + 1}`,
    url: `https://${d}/${encodeURIComponent(q.toLowerCase().replace(/\s+/g, "-"))}`,
    snippet: `Demo result for "${q}" (configure a real backend in .env).`,
    domain: d
  }));
}
var init_adapters = __esm({
  "src/services/search/adapters.ts"() {
    "use strict";
  }
});

// src/routes/search.ts
var search_exports = {};
__export(search_exports, {
  searchRoutes: () => searchRoutes
});
import { Hono as Hono2 } from "hono";
var searchRoutes;
var init_search = __esm({
  "src/routes/search.ts"() {
    "use strict";
    init_adapters();
    searchRoutes = new Hono2();
    searchRoutes.get("/", async (c) => {
      const q = c.req.query("q");
      if (!q) return c.json({ error: "Missing ?q=" }, 400);
      const requested = c.req.query("backend") ?? process.env.SEARCH_BACKEND ?? "searxng";
      const run = async (backend) => {
        switch (backend) {
          case "searxng":
            return searchSearxng(process.env.SEARXNG_URL ?? "http://localhost:8080", q);
          case "brave":
            return searchBrave(q);
          case "serper":
            return searchSerper(q);
          case "tavily":
            return searchTavily(q);
          case "ddg":
            return searchDdg(q);
          default:
            return searchDemo(q);
        }
      };
      try {
        const results = await run(requested);
        if (results.length) return c.json({ backend: requested, results });
      } catch {
      }
      if (requested !== "ddg") {
        try {
          const results = await searchDdg(q);
          if (results.length) return c.json({ backend: "ddg", results });
        } catch {
        }
      }
      return c.json({ backend: "demo", results: searchDemo(q) });
    });
  }
});

// src/routes/chat.ts
var chat_exports = {};
__export(chat_exports, {
  chatRoutes: () => chatRoutes
});
import { Hono as Hono3 } from "hono";
import { streamSSE } from "hono/streaming";
var chatRoutes;
var init_chat = __esm({
  "src/routes/chat.ts"() {
    "use strict";
    chatRoutes = new Hono3();
    chatRoutes.post("/", async (c) => {
      const body = await c.req.json();
      const kind = body.kind ?? "openai";
      const model = body.model;
      const key = body.key ?? body.apiKey ?? "";
      const base = String(body.base ?? body.baseUrl ?? "").replace(/\/+$/, "");
      const system = body.system ?? "";
      const messages2 = body.messages ?? [];
      const maxTokens = body.maxTokens ?? 1024;
      const temperature = body.temperature ?? 0.7;
      if (!model) return c.json({ error: "model is required" }, 400);
      if (!base) return c.json({ error: "base is required" }, 400);
      let url;
      let headers;
      let payload;
      const browserish = {
        "user-agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
        accept: "text/event-stream"
      };
      if (kind === "anthropic") {
        url = `${base}/messages`;
        headers = {
          ...browserish,
          "content-type": "application/json",
          "x-api-key": key,
          "anthropic-version": "2023-06-01"
        };
        payload = { model, stream: true, system, max_tokens: maxTokens, temperature, messages: messages2 };
      } else {
        url = `${base}/chat/completions`;
        headers = { ...browserish, "content-type": "application/json", ...key ? { authorization: `Bearer ${key}` } : {} };
        payload = {
          model,
          stream: true,
          max_tokens: maxTokens,
          temperature,
          messages: system ? [{ role: "system", content: system }, ...messages2] : messages2
        };
      }
      const upstream = await fetch(url, {
        method: "POST",
        headers,
        body: JSON.stringify(payload),
        signal: c.req.raw.signal
        // client abort kills the upstream call
      });
      if (!upstream.ok || !upstream.body) {
        const errText = await upstream.text().catch(() => "");
        let msg = `${upstream.status}`;
        try {
          msg = JSON.parse(errText)?.error?.message ?? msg;
        } catch {
        }
        return c.json({ error: msg }, upstream.status);
      }
      c.header("Content-Type", "text/event-stream");
      c.header("Cache-Control", "no-cache");
      return streamSSE(c, async (stream) => {
        const reader = upstream.body.getReader();
        const td = new TextDecoder();
        try {
          for (; ; ) {
            const { done, value } = await reader.read();
            if (done) break;
            await stream.write(td.decode(value, { stream: true }));
          }
        } catch {
        }
      });
    });
  }
});

// src/routes/documents.ts
var documents_exports = {};
__export(documents_exports, {
  documentRoutes: () => documentRoutes
});
import { Hono as Hono4 } from "hono";
var documentRoutes;
var init_documents = __esm({
  async "src/routes/documents.ts"() {
    "use strict";
    await init_db();
    documentRoutes = new Hono4();
    documentRoutes.post("/", async (c) => {
      const body = await c.req.json();
      const { id, name, kind = "file", text: text2 = "" } = body;
      if (!id || !name) return c.json({ error: "id and name are required" }, 400);
      db.insertDocument({ id, name, kind, text: text2, addedAt: Date.now() });
      return c.json({ ok: true, id });
    });
    documentRoutes.get("/", (c) => c.json({ documents: db.listDocuments() }));
  }
});

// src/routes/ollama.ts
var ollama_exports = {};
__export(ollama_exports, {
  ollamaRoutes: () => ollamaRoutes
});
import { Hono as Hono5 } from "hono";
var ollamaRoutes;
var init_ollama = __esm({
  "src/routes/ollama.ts"() {
    "use strict";
    ollamaRoutes = new Hono5();
    ollamaRoutes.get("/tags", async (c) => {
      const base = (process.env.OLLAMA_URL ?? "http://localhost:11434").replace(/\/$/, "");
      try {
        const res = await fetch(`${base}/api/tags`);
        if (!res.ok) return c.json({ error: `Ollama responded ${res.status}` }, 502);
        return c.json(await res.json());
      } catch (e) {
        return c.json({ error: `Cannot reach Ollama at ${base}: ${e.message}` }, 502);
      }
    });
  }
});

// src/routes/integrations.ts
var integrations_exports = {};
__export(integrations_exports, {
  integrationRoutes: () => integrationRoutes
});
import { Hono as Hono6 } from "hono";
var integrationRoutes, pending;
var init_integrations = __esm({
  "src/routes/integrations.ts"() {
    "use strict";
    integrationRoutes = new Hono6();
    pending = /* @__PURE__ */ new Map();
    integrationRoutes.post("/oauth/start", async (c) => {
      const { provider, scopes = [] } = await c.req.json();
      const state = Math.random().toString(36).slice(2);
      pending.set(state, { provider, createdAt: Date.now() });
      return c.json({ state, provider, scopes, note: "Authorize via the localhost callback." });
    });
    integrationRoutes.get("/oauth/callback", (c) => {
      const state = c.req.query("state");
      if (!state || !pending.has(state)) return c.json({ error: "Unknown or expired OAuth state" }, 400);
      const info = pending.get(state);
      pending.delete(state);
      return c.json({ ok: true, provider: info.provider, note: "Token handed to the local encrypted vault." });
    });
  }
});

// src/routes/resources.ts
var resources_exports = {};
__export(resources_exports, {
  resourceRoutes: () => resourceRoutes
});
import { existsSync as existsSync3, statSync as statSync3 } from "node:fs";
import { join as join3 } from "node:path";
import { Hono as Hono7 } from "hono";
function resourceRoutes(rt) {
  const r = new Hono7();
  r.get("/resources", (c) => {
    const mem2 = process.memoryUsage();
    const dbFile = rt.dbPath;
    return c.json({
      ok: true,
      process: {
        rssMB: Math.round(mem2.rss / 1048576),
        heapMB: Math.round(mem2.heapUsed / 1048576),
        uptimeSec: Math.round(process.uptime()),
        node: process.version
      },
      dataDir: {
        path: rt.dataDir,
        totalMB: +(dirSize(rt.dataDir) / 1048576).toFixed(1)
      },
      db: {
        ...dbStats(),
        sizeMB: existsSync3(dbFile) ? +(statSync3(dbFile).size / 1048576).toFixed(2) : 0
      },
      cacheMB: +(dirSize(join3(rt.dataDir, "cache")) / 1048576).toFixed(1),
      profile: rt.profile,
      caps: rt.caps,
      profiles: Object.fromEntries(Object.entries(PROFILES).map(([k, v]) => [k, { description: v.description }]))
    });
  });
  r.get("/config", (c) => c.json({
    ok: true,
    port: rt.port,
    dataDir: rt.dataDir,
    profile: rt.profile,
    caps: rt.caps,
    frontendServed: !!rt.frontendDist
  }));
  r.post("/config", async (c) => {
    const body = await c.req.json().catch(() => ({}));
    if (body.profile && body.profile in PROFILES) {
      const profile = body.profile;
      rt.profile = profile;
      rt.caps = PROFILES[profile];
      saveConfig(rt.dataDir, { profile });
      return c.json({ ok: true, profile, caps: rt.caps });
    }
    return c.json({ ok: false, error: "Unknown profile" }, 400);
  });
  return r;
}
var init_resources = __esm({
  async "src/routes/resources.ts"() {
    "use strict";
    await init_db();
    init_runtime();
  }
});

// src/routes/fs.ts
var fs_exports = {};
__export(fs_exports, {
  fsRoutes: () => fsRoutes
});
import { mkdir, readFile, writeFile } from "node:fs/promises";
import { dirname, join as join4, resolve as resolve2 } from "node:path";
import { Hono as Hono8 } from "hono";
function fsRoutes(rt) {
  const r = new Hono8();
  const root = resolve2(join4(rt.dataDir, "files"));
  const safePath = (rel) => {
    if (!rel || rel.startsWith("/") || rel.includes("..")) return null;
    const abs = resolve2(join4(root, rel));
    return abs.startsWith(root + "/") || abs === root ? abs : null;
  };
  r.get("/fs/read", async (c) => {
    const rel = c.req.query("path") ?? "";
    const abs = safePath(rel);
    if (!abs) return c.text("Path must stay inside the Research Engine files folder.", 400);
    try {
      return c.text(await readFile(abs, "utf8"));
    } catch {
      return c.text("File not found.", 404);
    }
  });
  r.post("/fs/write", async (c) => {
    let body;
    try {
      body = await c.req.json();
    } catch {
      return c.text("Invalid JSON body.", 400);
    }
    const abs = safePath(body.path ?? "");
    if (!abs) return c.text("Path must stay inside the Research Engine files folder.", 400);
    if (typeof body.content !== "string") return c.text("Missing content.", 400);
    if (body.content.length > 2e6) return c.text("Content too large (2 MB limit).", 413);
    await mkdir(dirname(abs), { recursive: true });
    await writeFile(abs, body.content, "utf8");
    return c.json({ ok: true, path: body.path });
  });
  return r;
}
var init_fs = __esm({
  "src/routes/fs.ts"() {
    "use strict";
  }
});

// src/routes/providers.ts
var providers_exports = {};
__export(providers_exports, {
  providerRoutes: () => providerRoutes
});
import { Hono as Hono9 } from "hono";
async function discover(kind, base, key, timeout) {
  const t0 = Date.now();
  try {
    if (kind === "ollama") {
      const res2 = await fetch(`${base}/api/tags`, { signal: AbortSignal.timeout(timeout) });
      if (!res2.ok) return { error: `Ollama responded ${res2.status}`, ms: Date.now() - t0 };
      const json2 = await res2.json();
      return { models: (json2.models ?? []).map((m) => String(m.name)), ms: Date.now() - t0 };
    }
    const headers = {
      "user-agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
      accept: "application/json"
    };
    if (kind === "anthropic") {
      headers["x-api-key"] = key;
      headers["anthropic-version"] = "2023-06-01";
    } else if (key) {
      headers.authorization = `Bearer ${key}`;
    }
    const res = await fetch(`${base}/models`, { headers, signal: AbortSignal.timeout(timeout) });
    if (!res.ok) {
      let msg = `Provider responded ${res.status}`;
      try {
        const j = await res.json();
        msg = j?.error?.message ?? j?.message ?? msg;
      } catch {
      }
      return { error: msg, ms: Date.now() - t0 };
    }
    const json = await res.json();
    const models = (json.data ?? []).map((m) => String(m.id ?? m.name)).filter(Boolean);
    return { models, ms: Date.now() - t0 };
  } catch (e) {
    const msg = e?.name === "TimeoutError" || e?.name === "AbortError" ? `Timed out after ${Math.round(timeout / 1e3)}s` : e?.message ?? "Network error";
    return { error: msg, ms: Date.now() - t0 };
  }
}
function args(c) {
  const kind = c.req.query("kind") ?? "openai";
  const base = (c.req.query("base") ?? "").replace(/\/+$/, "");
  const key = c.req.header("x-re-key") ?? "";
  return { kind, base, key };
}
var providerRoutes, MODELS_TIMEOUT_MS, TEST_TIMEOUT_MS;
var init_providers = __esm({
  "src/routes/providers.ts"() {
    "use strict";
    providerRoutes = new Hono9();
    MODELS_TIMEOUT_MS = 8e3;
    TEST_TIMEOUT_MS = 6e3;
    providerRoutes.get("/providers/models", async (c) => {
      const { kind, base, key } = args(c);
      if (!base) return c.json({ error: "base is required" }, 400);
      const out = await discover(kind, base, key, MODELS_TIMEOUT_MS);
      if (out.error) return c.json(out, 502);
      return c.json(out);
    });
    providerRoutes.get("/providers/test", async (c) => {
      const { kind, base, key } = args(c);
      if (!base) return c.json({ error: "base is required" }, 400);
      const out = await discover(kind, base, key, TEST_TIMEOUT_MS);
      if (out.error) return c.json(out, 502);
      return c.json({ ms: out.ms });
    });
  }
});

// src/index.ts
init_runtime();
import { serve } from "@hono/node-server";
import { Hono as Hono10 } from "hono";
import { cors } from "hono/cors";
import { logger } from "hono/logger";

// src/static.ts
import { createReadStream, existsSync as existsSync2, statSync as statSync2 } from "node:fs";
import { Readable } from "node:stream";
import { extname, join as join2, normalize } from "node:path";
var MIME = {
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".mjs": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".json": "application/json",
  ".svg": "image/svg+xml",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".webp": "image/webp",
  ".ico": "image/x-icon",
  ".woff": "font/woff",
  ".woff2": "font/woff2",
  ".ttf": "font/ttf",
  ".map": "application/json",
  ".txt": "text/plain; charset=utf-8",
  ".webmanifest": "application/manifest+json"
};
function staticHandler(root) {
  const indexHtml = join2(root, "index.html");
  return async (c) => {
    const url = new URL(c.req.url);
    let rel = decodeURIComponent(url.pathname).replace(/^\/+/, "");
    rel = normalize(rel).replace(/^(\.\.[/\\])+/, "");
    const file = rel ? join2(root, rel) : indexHtml;
    const target = existsSync2(file) && statSync2(file).isFile() ? file : indexHtml;
    if (!existsSync2(target)) return c.notFound();
    const isIndex = target === indexHtml;
    const headers = {
      "content-type": MIME[extname(target).toLowerCase()] ?? "application/octet-stream",
      "content-length": String(statSync2(target).size)
    };
    if (isIndex) headers["cache-control"] = "no-cache";
    else if (rel.startsWith("assets/")) headers["cache-control"] = "public, max-age=31536000, immutable";
    const rs = createReadStream(target);
    return new Response(Readable.toWeb(rs), { status: 200, headers });
  };
}

// src/index.ts
async function main() {
  const rt = await resolveRuntime(process.argv.slice(2));
  const { healthRoutes: healthRoutes2 } = await init_health().then(() => health_exports);
  const { searchRoutes: searchRoutes2 } = await Promise.resolve().then(() => (init_search(), search_exports));
  const { chatRoutes: chatRoutes2 } = await Promise.resolve().then(() => (init_chat(), chat_exports));
  const { documentRoutes: documentRoutes2 } = await init_documents().then(() => documents_exports);
  const { ollamaRoutes: ollamaRoutes2 } = await Promise.resolve().then(() => (init_ollama(), ollama_exports));
  const { integrationRoutes: integrationRoutes2 } = await Promise.resolve().then(() => (init_integrations(), integrations_exports));
  const { resourceRoutes: resourceRoutes2 } = await init_resources().then(() => resources_exports);
  const { fsRoutes: fsRoutes2 } = await Promise.resolve().then(() => (init_fs(), fs_exports));
  const { providerRoutes: providerRoutes2 } = await Promise.resolve().then(() => (init_providers(), providers_exports));
  const app = new Hono10();
  app.use("*", cors());
  app.use("*", logger((msg) => console.log(`[re] ${msg}`)));
  app.route("/api", healthRoutes2);
  app.route("/api", resourceRoutes2(rt));
  app.route("/api", fsRoutes2(rt));
  app.route("/api/search", searchRoutes2);
  app.route("/api/chat", chatRoutes2);
  app.route("/api/documents", documentRoutes2);
  app.route("/api/ollama", ollamaRoutes2);
  app.route("/api/integrations", integrationRoutes2);
  app.route("/api", providerRoutes2);
  app.onError((err, c) => {
    return c.json({ error: err.message }, 500);
  });
  if (rt.frontendDist) {
    const handler = staticHandler(rt.frontendDist);
    app.get("*", handler);
  }
  serve({ fetch: app.fetch, port: rt.port, hostname: rt.host }, (info) => {
    console.log(`Research Engine listening on http://${rt.host}:${info.port}`);
    console.log(`  data dir : ${rt.dataDir}`);
    console.log(`  profile  : ${rt.profile} (${rt.caps.floodWorkers} flood worker${rt.caps.floodWorkers > 1 ? "s" : ""}, ${rt.caps.concurrentStreams} concurrent stream${rt.caps.concurrentStreams > 1 ? "s" : ""})`);
    console.log(`  frontend : ${rt.frontendDist ?? "not found \u2014 API only (run `npm run build` in frontend/ for single-process mode)"}`);
    console.log(`  database : ${rt.dbPath}`);
    if (rt.rememberedPort) console.log(`  note     : preferred port was busy \u2014 using ${info.port} (remembered in config.json)`);
  });
}
main().catch((e) => {
  console.error("[re] fatal:", e);
  process.exit(1);
});
